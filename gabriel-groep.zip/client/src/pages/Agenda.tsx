import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isToday, addMonths, subMonths, startOfWeek, endOfWeek, isWithinInterval, startOfDay, endOfDay } from "date-fns";
import { nl } from "date-fns/locale";
import { ChevronLeft, ChevronRight, Calendar, MapPin, Users } from "lucide-react";
import SpeltakBadge from "@/components/SpeltakBadge";
import { EVENT_TYPE_LABELS } from "@/lib/constants";
import PublicLayout from "@/components/PublicLayout";

const SPELTAK_FILTER_OPTIONS = [
  { key: "all", label: "Alle Speltakken" },
  { key: "dolfijnen", label: "Dolfijnen" },
  { key: "verkenners", label: "Verkenners" },
  { key: "wilde_vaart", label: "Wilde Vaart" },
];

export default function Agenda() {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedSpeltak, setSelectedSpeltak] = useState("all");
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);

  const { data: events } = trpc.events.listPublic.useQuery({
    from: startOfMonth(currentMonth),
    to: endOfMonth(currentMonth),
  });

  const filteredEvents = events?.filter((e) => {
    if (selectedSpeltak === "all") return true;
    return e.speltak === selectedSpeltak || e.speltak === "all";
  }) ?? [];

  const selectedDayEvents = selectedDate
    ? filteredEvents.filter((e) => {
        const eventStart = startOfDay(new Date(e.startDate));
        const eventEnd = e.endDate ? endOfDay(new Date(e.endDate)) : endOfDay(new Date(e.startDate));
        const selectedDay = startOfDay(selectedDate);
        return isWithinInterval(selectedDay, { start: eventStart, end: eventEnd });
      })
    : filteredEvents;

  // Calendar grid
  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const calStart = startOfWeek(monthStart, { weekStartsOn: 1 });
  const calEnd = endOfWeek(monthEnd, { weekStartsOn: 1 });
  const days = eachDayOfInterval({ start: calStart, end: calEnd });

  const getEventsForDay = (day: Date) =>
    filteredEvents.filter((e) => {
      const eventStart = startOfDay(new Date(e.startDate));
      const eventEnd = e.endDate ? endOfDay(new Date(e.endDate)) : endOfDay(new Date(e.startDate));
      const checkDay = startOfDay(day);
      return isWithinInterval(checkDay, { start: eventStart, end: eventEnd });
    });

  return (
    <PublicLayout>
      {/* Hero */}
      <section className="relative pt-32 pb-16 bg-primary overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-white transform translate-x-1/3 -translate-y-1/3" />
        </div>
        <div className="relative container">
          <Badge className="bg-white/20 text-white border-white/30 mb-5">Agenda</Badge>
          <h1 className="font-display text-5xl font-bold text-white mb-4">Activiteiten</h1>
          <p className="text-white/80 text-xl max-w-xl">
            Bekijk alle aankomende activiteiten en evenementen van Gabriël Groep.
          </p>
        </div>
      </section>

      <section className="py-12 bg-background">
        <div className="container">
          {/* Filters */}
          <div className="flex flex-wrap gap-2 mb-8">
            {SPELTAK_FILTER_OPTIONS.map((opt) => (
              <Button
                key={opt.key}
                variant={selectedSpeltak === opt.key ? "default" : "outline"}
                size="sm"
                onClick={() => { setSelectedSpeltak(opt.key); setSelectedDate(null); }}
              >
                {opt.label}
              </Button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Calendar */}
            <div className="lg:col-span-2">
              <Card className="border border-border">
                <CardContent className="p-5">
                  {/* Month navigation */}
                  <div className="flex items-center justify-between mb-5">
                    <Button variant="ghost" size="icon" onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}>
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                    <h2 className="font-display text-xl font-bold text-foreground capitalize">
                      {format(currentMonth, "MMMM yyyy", { locale: nl })}
                    </h2>
                    <Button variant="ghost" size="icon" onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}>
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>

                  {/* Day headers */}
                  <div className="grid grid-cols-7 mb-2">
                    {["Ma", "Di", "Wo", "Do", "Vr", "Za", "Zo"].map((d) => (
                      <div key={d} className="text-center text-xs font-semibold text-muted-foreground py-2">
                        {d}
                      </div>
                    ))}
                  </div>

                  {/* Days grid */}
                  <div className="grid grid-cols-7 gap-1">
                    {days.map((day) => {
                      const dayEvents = getEventsForDay(day);
                      const isCurrentMonth = day.getMonth() === currentMonth.getMonth();
                      const isSelected = selectedDate && isSameDay(day, selectedDate);
                      const today = isToday(day);

                      return (
                        <button
                          key={day.toISOString()}
                          onClick={() => setSelectedDate(isSelected ? null : day)}
                          className={`relative p-1.5 rounded-lg text-center transition-all min-h-[52px] ${
                            !isCurrentMonth ? "opacity-30" : ""
                          } ${
                            isSelected
                              ? "bg-primary text-primary-foreground"
                              : today
                              ? "bg-accent/20 text-foreground"
                              : "hover:bg-muted"
                          }`}
                        >
                          <span className={`text-sm font-medium block ${
                            today && !isSelected ? "text-primary font-bold" : ""
                          }`}>
                            {format(day, "d")}
                          </span>
                          {dayEvents.length > 0 && (
                            <div className="flex justify-center gap-0.5 mt-1 flex-wrap">
                              {dayEvents.slice(0, 3).map((e, i) => (
                                <div
                                  key={i}
                                  className={`w-1.5 h-1.5 rounded-full ${
                                    isSelected ? "bg-white/70" : "bg-primary"
                                  }`}
                                />
                              ))}
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Event List */}
            <div>
              <h3 className="font-display text-lg font-bold text-foreground mb-4">
                {selectedDate
                  ? format(selectedDate, "d MMMM", { locale: nl })
                  : "Alle activiteiten"}
              </h3>

              {selectedDayEvents.length === 0 ? (
                <div className="text-center py-10 text-muted-foreground">
                  <Calendar className="w-8 h-8 mx-auto mb-3 opacity-40" />
                  <p className="text-sm">Geen activiteiten</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
                  {selectedDayEvents.map((event) => (
                    <Card key={event.id} className="border border-border card-hover">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <h4 className="font-semibold text-foreground text-sm">{event.title}</h4>
                            <p className="text-xs text-muted-foreground mt-0.5">
                              {format(new Date(event.startDate), "d MMM · HH:mm", { locale: nl })}
                              {event.endDate && new Date(event.endDate).toDateString() !== new Date(event.startDate).toDateString()
                                ? ` – ${format(new Date(event.endDate), "d MMM HH:mm", { locale: nl })}`
                                : event.endDate ? ` – ${format(new Date(event.endDate), "HH:mm", { locale: nl })}`
                                : ""}
                            </p>
                          </div>
                          <SpeltakBadge speltak={event.speltak} size="sm" />
                        </div>
                        {event.location && (
                          <div className="flex items-center gap-1.5 text-muted-foreground text-xs">
                            <MapPin className="w-3 h-3" />
                            {event.location}
                          </div>
                        )}
                        {event.maxParticipants && (
                          <div className="flex items-center gap-1.5 text-muted-foreground text-xs mt-1">
                            <Users className="w-3 h-3" />
                            Max. {event.maxParticipants} deelnemers
                          </div>
                        )}
                        {event.description && (
                          <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{event.description}</p>
                        )}
                        <div className="mt-2">
                          <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">
                            {EVENT_TYPE_LABELS[event.type] ?? event.type}
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
