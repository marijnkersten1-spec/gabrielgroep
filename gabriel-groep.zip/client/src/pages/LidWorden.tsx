import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { CheckCircle2, ArrowRight, ArrowLeft, Loader2 } from "lucide-react";
import { SPELTAK_AGES } from "@/lib/constants";
import PublicLayout from "@/components/PublicLayout";

const steps = [
  { title: "Kind", desc: "Gegevens van het kind" },
  { title: "Ouder", desc: "Uw contactgegevens" },
  { title: "Speltak", desc: "Kies een groep" },
  { title: "Bevestiging", desc: "Controleer en verstuur" },
];

export default function LidWorden() {
  const [step, setStep] = useState(0);
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form state — plain state instead of react-hook-form to avoid validation blocking
  const [childName, setChildName] = useState("");
  const [childBirthDate, setChildBirthDate] = useState("");
  const [parentName, setParentName] = useState("");
  const [parentEmail, setParentEmail] = useState("");
  const [parentPhone, setParentPhone] = useState("");
  const [address, setAddress] = useState("");
  const [speltak, setSpeltak] = useState<"dolfijnen" | "verkenners" | "wilde_vaart" | "">("");
  const [message, setMessage] = useState("");
  const [gdprConsent, setGdprConsent] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const submitMutation = trpc.join.submit.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      setIsSubmitting(false);
    },
    onError: (err) => {
      setIsSubmitting(false);
      toast.error("Er is een fout opgetreden: " + err.message);
    },
  });

  const validateStep = (currentStep: number): boolean => {
    const newErrors: Record<string, string> = {};

    if (currentStep === 0) {
      if (!childName.trim() || childName.trim().length < 2) {
        newErrors.childName = "Vul de naam van het kind in (minimaal 2 tekens)";
      }
      if (!childBirthDate) {
        newErrors.childBirthDate = "Vul de geboortedatum in";
      }
    }

    if (currentStep === 1) {
      if (!parentName.trim() || parentName.trim().length < 2) {
        newErrors.parentName = "Vul uw naam in (minimaal 2 tekens)";
      }
      if (!parentEmail.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(parentEmail)) {
        newErrors.parentEmail = "Vul een geldig e-mailadres in";
      }
    }

    if (currentStep === 3) {
      if (!gdprConsent) {
        newErrors.gdprConsent = "U moet akkoord gaan met de privacyverklaring";
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(step)) {
      setStep((s) => s + 1);
    }
  };

  const handleSubmit = async () => {
    if (!validateStep(3)) return;

    setIsSubmitting(true);
    submitMutation.mutate({
      childName: childName.trim(),
      childBirthDate,
      parentName: parentName.trim(),
      parentEmail: parentEmail.trim(),
      parentPhone: parentPhone.trim() || undefined,
      address: address.trim() || undefined,
      speltak: speltak || undefined,
      message: message.trim() || undefined,
      gdprConsent: true,
    });
  };

  // ── Confirmation screen ────────────────────────────────────────────────────
  if (submitted) {
    return (
      <PublicLayout>
        <div className="min-h-screen flex items-center justify-center bg-muted/30 pt-20 pb-20">
          <div className="text-center max-w-lg mx-auto px-6">
            <div className="w-24 h-24 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-8 shadow-lg">
              <CheckCircle2 className="w-12 h-12 text-green-600" />
            </div>
            <h2 className="font-display text-4xl font-bold text-foreground mb-4">
              Aanmelding Ontvangen!
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed mb-4">
              Bedankt voor uw aanmelding van <strong>{childName}</strong>. We nemen zo snel mogelijk contact op met <strong>{parentEmail}</strong> om de inschrijving te bevestigen.
            </p>
            <p className="text-muted-foreground mb-10">
              Welkom bij Gabriël Groep Zeeverkenners!
            </p>
            <a href="/">
              <Button size="lg" className="px-10">
                Terug naar Home
              </Button>
            </a>
          </div>
        </div>
      </PublicLayout>
    );
  }

  return (
    <PublicLayout>
      {/* Hero */}
      <section className="relative pt-32 pb-16 bg-primary overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-white transform translate-x-1/3 -translate-y-1/3" />
        </div>
        <div className="relative container">
          <Badge className="bg-white/20 text-white border-white/30 mb-5">Aanmelden</Badge>
          <h1 className="font-display text-5xl font-bold text-white mb-4">Lid Worden</h1>
          <p className="text-white/80 text-xl max-w-xl">
            Meld uw kind aan bij Gabriël Groep en begin het avontuur op het water.
          </p>
        </div>
      </section>

      {/* Form */}
      <section className="py-16 bg-background">
        <div className="container max-w-3xl">
          {/* Progress */}
          <div className="flex items-center justify-between mb-10">
            {steps.map((s, i) => (
              <div key={i} className="flex items-center flex-1">
                <div className="flex flex-col items-center">
                  <div
                    className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold transition-colors ${
                      i < step
                        ? "bg-green-500 text-white"
                        : i === step
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {i < step ? "✓" : i + 1}
                  </div>
                  <div className="hidden sm:block mt-1.5 text-center">
                    <div
                      className={`text-xs font-medium ${
                        i === step ? "text-primary" : "text-muted-foreground"
                      }`}
                    >
                      {s.title}
                    </div>
                  </div>
                </div>
                {i < steps.length - 1 && (
                  <div
                    className={`flex-1 h-0.5 mx-3 transition-colors ${
                      i < step ? "bg-green-500" : "bg-border"
                    }`}
                  />
                )}
              </div>
            ))}
          </div>

          <Card className="border border-border shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="font-display text-2xl">{steps[step].title}</CardTitle>
              <p className="text-muted-foreground text-sm">{steps[step].desc}</p>
            </CardHeader>
            <CardContent className="space-y-5">
              {/* Step 0: Child info */}
              {step === 0 && (
                <>
                  <div>
                    <Label htmlFor="childName">Naam kind *</Label>
                    <Input
                      id="childName"
                      value={childName}
                      onChange={(e) => setChildName(e.target.value)}
                      placeholder="Voornaam Achternaam"
                      className="mt-1.5"
                    />
                    {errors.childName && (
                      <p className="text-destructive text-xs mt-1">{errors.childName}</p>
                    )}
                  </div>
                  <div>
                    <Label htmlFor="childBirthDate">Geboortedatum kind *</Label>
                    <Input
                      id="childBirthDate"
                      type="date"
                      value={childBirthDate}
                      onChange={(e) => setChildBirthDate(e.target.value)}
                      className="mt-1.5"
                    />
                    {errors.childBirthDate && (
                      <p className="text-destructive text-xs mt-1">{errors.childBirthDate}</p>
                    )}
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground">
                      <strong>Leeftijdsgroepen:</strong> Dolfijnen (7–10), Verkenners (11–15),
                      Wilde Vaart (16–18)
                    </p>
                  </div>
                </>
              )}

              {/* Step 1: Parent info */}
              {step === 1 && (
                <>
                  <div>
                    <Label htmlFor="parentName">Naam ouder/verzorger *</Label>
                    <Input
                      id="parentName"
                      value={parentName}
                      onChange={(e) => setParentName(e.target.value)}
                      placeholder="Voornaam Achternaam"
                      className="mt-1.5"
                    />
                    {errors.parentName && (
                      <p className="text-destructive text-xs mt-1">{errors.parentName}</p>
                    )}
                  </div>
                  <div>
                    <Label htmlFor="parentEmail">E-mailadres *</Label>
                    <Input
                      id="parentEmail"
                      type="email"
                      value={parentEmail}
                      onChange={(e) => setParentEmail(e.target.value)}
                      placeholder="naam@voorbeeld.nl"
                      className="mt-1.5"
                    />
                    {errors.parentEmail && (
                      <p className="text-destructive text-xs mt-1">{errors.parentEmail}</p>
                    )}
                  </div>
                  <div>
                    <Label htmlFor="parentPhone">Telefoonnummer</Label>
                    <Input
                      id="parentPhone"
                      value={parentPhone}
                      onChange={(e) => setParentPhone(e.target.value)}
                      placeholder="+31 6 12 34 56 78"
                      className="mt-1.5"
                    />
                  </div>
                  <div>
                    <Label htmlFor="address">Adres</Label>
                    <Input
                      id="address"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="Straat 1, 1234 AB Stad"
                      className="mt-1.5"
                    />
                  </div>
                </>
              )}

              {/* Step 2: Speltak */}
              {step === 2 && (
                <>
                  <div>
                    <Label>Voorkeur speltak</Label>
                    <p className="text-muted-foreground text-xs mb-3">
                      Optioneel — we adviseren op basis van leeftijd
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      {[
                        { key: "dolfijnen" as const, name: "Dolfijnen", emoji: "🐬" },
                        { key: "verkenners" as const, name: "Verkenners", emoji: "🧭" },
                        { key: "wilde_vaart" as const, name: "Wilde Vaart", emoji: "⚓" },
                      ].map((s) => (
                        <button
                          key={s.key}
                          type="button"
                          onClick={() => setSpeltak(s.key)}
                          className={`p-4 rounded-xl border-2 text-center transition-all ${
                            speltak === s.key
                              ? "border-primary bg-primary/5"
                              : "border-border hover:border-primary/40"
                          }`}
                        >
                          <div className="text-3xl mb-2">{s.emoji}</div>
                          <div className="font-semibold text-sm text-foreground">{s.name}</div>
                          <div className="text-xs text-muted-foreground">{SPELTAK_AGES[s.key]}</div>
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="message">Aanvullende informatie</Label>
                    <Textarea
                      id="message"
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Bijzonderheden, vragen of opmerkingen..."
                      className="mt-1.5 resize-none"
                      rows={4}
                    />
                  </div>
                </>
              )}

              {/* Step 3: Confirmation */}
              {step === 3 && (
                <>
                  <div className="space-y-3">
                    <div className="p-4 bg-muted/50 rounded-lg">
                      <h4 className="font-semibold text-sm text-foreground mb-2">Gegevens Kind</h4>
                      <p className="text-sm text-muted-foreground">
                        {childName} — {childBirthDate}
                      </p>
                    </div>
                    <div className="p-4 bg-muted/50 rounded-lg">
                      <h4 className="font-semibold text-sm text-foreground mb-2">Gegevens Ouder</h4>
                      <p className="text-sm text-muted-foreground">{parentName}</p>
                      <p className="text-sm text-muted-foreground">{parentEmail}</p>
                      {parentPhone && (
                        <p className="text-sm text-muted-foreground">{parentPhone}</p>
                      )}
                    </div>
                    {speltak && (
                      <div className="p-4 bg-muted/50 rounded-lg">
                        <h4 className="font-semibold text-sm text-foreground mb-2">
                          Speltak Voorkeur
                        </h4>
                        <p className="text-sm text-muted-foreground capitalize">
                          {speltak === "wilde_vaart" ? "Wilde Vaart" : speltak}
                        </p>
                      </div>
                    )}
                    {message && (
                      <div className="p-4 bg-muted/50 rounded-lg">
                        <h4 className="font-semibold text-sm text-foreground mb-2">Opmerking</h4>
                        <p className="text-sm text-muted-foreground">{message}</p>
                      </div>
                    )}
                  </div>

                  <div className="flex items-start gap-3 p-4 border border-border rounded-lg">
                    <Checkbox
                      id="gdprConsent"
                      checked={gdprConsent}
                      onCheckedChange={(checked) => {
                        setGdprConsent(checked === true);
                        if (checked) setErrors((e) => ({ ...e, gdprConsent: "" }));
                      }}
                    />
                    <div>
                      <Label htmlFor="gdprConsent" className="text-sm font-medium cursor-pointer">
                        Ik ga akkoord met de privacyverklaring *
                      </Label>
                      <p className="text-xs text-muted-foreground mt-1">
                        Uw gegevens worden verwerkt conform de AVG/GDPR. Zie onze{" "}
                        <a href="/over-ons" className="text-primary underline">
                          privacyverklaring
                        </a>
                        .
                      </p>
                      {errors.gdprConsent && (
                        <p className="text-destructive text-xs mt-1">{errors.gdprConsent}</p>
                      )}
                    </div>
                  </div>
                </>
              )}

              {/* Navigation */}
              <div className="flex justify-between pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setStep((s) => Math.max(0, s - 1))}
                  disabled={step === 0 || isSubmitting}
                >
                  <ArrowLeft className="w-4 h-4 mr-1" /> Vorige
                </Button>

                {step < steps.length - 1 ? (
                  <Button type="button" onClick={handleNext}>
                    Volgende <ArrowRight className="w-4 h-4 ml-1" />
                  </Button>
                ) : (
                  <Button
                    type="button"
                    onClick={handleSubmit}
                    disabled={isSubmitting}
                    className="min-w-[120px]"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Versturen...
                      </>
                    ) : (
                      "Aanmelden"
                    )}
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </PublicLayout>
  );
}
