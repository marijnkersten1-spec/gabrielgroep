import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import { Images, X, ChevronLeft, ChevronRight, ZoomIn } from "lucide-react";
import SpeltakBadge from "@/components/SpeltakBadge";
import PublicLayout from "@/components/PublicLayout";
import AdminPhotoUpload from "@/components/AdminPhotoUpload";

export default function Fotos() {
  const [selectedAlbum, setSelectedAlbum] = useState<number | null>(null);
  const [lightboxPhoto, setLightboxPhoto] = useState<{ url: string; title?: string | null } | null>(null);
  const [lightboxIndex, setLightboxIndex] = useState(0);

  const { data: albums, isLoading: albumsLoading, refetch: refetchAlbums } = trpc.photos.listPublicAlbums.useQuery();
  const { data: photos, refetch: refetchPhotos } = trpc.photos.getPhotos.useQuery(
    { albumId: selectedAlbum! },
    { enabled: selectedAlbum !== null }
  );

  const openLightbox = (photo: { url: string; title?: string | null }, index: number) => {
    setLightboxPhoto(photo);
    setLightboxIndex(index);
  };

  const closeLightbox = () => setLightboxPhoto(null);

  const prevPhoto = () => {
    if (!photos) return;
    const newIdx = (lightboxIndex - 1 + photos.length) % photos.length;
    setLightboxIndex(newIdx);
    setLightboxPhoto(photos[newIdx]);
  };

  const nextPhoto = () => {
    if (!photos) return;
    const newIdx = (lightboxIndex + 1) % photos.length;
    setLightboxIndex(newIdx);
    setLightboxPhoto(photos[newIdx]);
  };

  return (
    <PublicLayout>
      {/* Hero */}
      <section className="relative pt-32 pb-16 bg-primary overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-white transform translate-x-1/3 -translate-y-1/3" />
        </div>
        <div className="relative container">
          <Badge className="bg-white/20 text-white border-white/30 mb-5">Foto's</Badge>
          <h1 className="font-display text-5xl font-bold text-white mb-4">Fotogalerij</h1>
          <p className="text-white/80 text-xl max-w-xl">
            Herinneringen aan onze avonturen op het water en in de natuur.
          </p>
        </div>
      </section>

      <section className="py-12 bg-background">
        <div className="container">
          {selectedAlbum ? (
            <>
              {/* Album view */}
              <div className="flex items-center justify-between gap-4 mb-8">
                <div className="flex items-center gap-4">
                  <Button variant="outline" size="sm" onClick={() => setSelectedAlbum(null)}>
                    <ChevronLeft className="w-4 h-4 mr-1" /> Terug naar albums
                  </Button>
                  {albums?.find((a) => a.id === selectedAlbum) && (
                    <div>
                      <h2 className="font-display text-2xl font-bold text-foreground">
                        {albums.find((a) => a.id === selectedAlbum)?.title}
                      </h2>
                    </div>
                  )}
                </div>
                {selectedAlbum && (
                  <AdminPhotoUpload
                    albumId={selectedAlbum}
                    albumTitle={albums?.find((a) => a.id === selectedAlbum)?.title || "Album"}
                    onUploadSuccess={() => refetchPhotos()}
                  />
                )}
              </div>

              {!photos?.length ? (
                <div className="text-center py-20 text-muted-foreground">
                  <Images className="w-10 h-10 mx-auto mb-3 opacity-40" />
                  <p>Dit album is nog leeg.</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                  {photos.map((photo, i) => (
                    <button
                      key={photo.id}
                      onClick={() => openLightbox(photo, i)}
                      className="relative group aspect-square rounded-xl overflow-hidden border border-border"
                    >
                      <img
                        src={photo.url}
                        alt={photo.title ?? "Foto"}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                        <ZoomIn className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </>
          ) : (
            <>
              {/* Album grid */}
              {albumsLoading ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-56 rounded-xl bg-muted animate-pulse" />
                  ))}
                </div>
              ) : !albums?.length ? (
                <div className="text-center py-20 text-muted-foreground">
                  <Images className="w-10 h-10 mx-auto mb-3 opacity-40" />
                  <h3 className="font-display text-xl font-bold text-foreground mb-2">Geen albums</h3>
                  <p>Er zijn nog geen fotoalbums gepubliceerd.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {albums.map((album) => (
                    <Card
                      key={album.id}
                      className="card-hover overflow-hidden border border-border cursor-pointer"
                      onClick={() => setSelectedAlbum(album.id)}
                    >
                      <div className="h-48 bg-muted flex items-center justify-center">
                        <Images className="w-10 h-10 text-muted-foreground/40" />
                      </div>
                      <CardContent className="p-5">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-semibold text-foreground">{album.title}</h3>
                          {album.speltak && <SpeltakBadge speltak={album.speltak} size="sm" />}
                        </div>
                        {album.description && (
                          <p className="text-muted-foreground text-sm line-clamp-2">{album.description}</p>
                        )}
                        <p className="text-xs text-muted-foreground mt-2">
                          {format(new Date(album.createdAt), "d MMMM yyyy", { locale: nl })}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </section>

      {/* Lightbox */}
      <Dialog open={!!lightboxPhoto} onOpenChange={() => closeLightbox()}>
        <DialogContent className="max-w-4xl p-0 bg-black border-none">
          <div className="relative">
            <button
              onClick={closeLightbox}
              className="absolute top-3 right-3 z-10 w-8 h-8 rounded-full bg-black/50 flex items-center justify-center text-white hover:bg-black/70 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
            {photos && photos.length > 1 && (
              <>
                <button
                  onClick={prevPhoto}
                  className="absolute left-3 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full bg-black/50 flex items-center justify-center text-white hover:bg-black/70 transition-colors"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={nextPhoto}
                  className="absolute right-3 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full bg-black/50 flex items-center justify-center text-white hover:bg-black/70 transition-colors"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </>
            )}
            {lightboxPhoto && (
              <img
                src={lightboxPhoto.url}
                alt={lightboxPhoto.title ?? "Foto"}
                className="w-full max-h-[80vh] object-contain"
              />
            )}
            {lightboxPhoto?.title && (
              <div className="p-4 text-center text-white/80 text-sm">{lightboxPhoto.title}</div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </PublicLayout>
  );
}
