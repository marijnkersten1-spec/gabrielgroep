import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { CDN, SPELTAK_AGES, SPELTAK_DESCRIPTIONS } from "@/lib/constants";
import {
  Anchor, Calendar, Users, Shield, ChevronRight, Waves, Compass, Star,
  ArrowRight, MapPin, Phone, Mail
} from "lucide-react";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import PublicLayout from "@/components/PublicLayout";

const speltakken = [
  {
    key: "dolfijnen",
    name: "Dolfijnen",
    emoji: "🐬",
    color: "from-blue-400 to-cyan-500",
    bg: "bg-blue-50",
    border: "border-blue-200",
    textColor: "text-blue-700",
  },
  {
    key: "verkenners",
    name: "Verkenners",
    emoji: "🧭",
    color: "from-green-500 to-emerald-600",
    bg: "bg-green-50",
    border: "border-green-200",
    textColor: "text-green-700",
  },
  {
    key: "wilde_vaart",
    name: "Wilde Vaart",
    emoji: "⚓",
    color: "from-orange-400 to-red-500",
    bg: "bg-orange-50",
    border: "border-orange-200",
    textColor: "text-orange-700",
  },
];

const features = [
  {
    icon: Waves,
    title: "Zeilen & Varen",
    desc: "Leer zeilen op de Maas en omliggende wateren in een veilige, begeleide omgeving.",
  },
  {
    icon: Compass,
    title: "Avontuur & Natuur",
    desc: "Kampen, tochten en buitenactiviteiten die karakter vormen en vriendschappen smeden.",
  },
  {
    icon: Users,
    title: "Gemeenschap",
    desc: "Maak deel uit van een warme groep met kinderen van 7 tot 18 jaar en betrokken staf.",
  },
  {
    icon: Shield,
    title: "Veiligheid Eerst",
    desc: "Alle activiteiten worden begeleid door gecertificeerde vrijwilligers met EHBO-training.",
  },
];

export default function Home() {
  const [fromDate] = useState(() => new Date());
  const { data: upcomingEvents } = trpc.events.listPublic.useQuery({ from: fromDate });
  const { data: latestNews } = trpc.news.listPublic.useQuery();

  const nextEvents = upcomingEvents?.slice(0, 3) ?? [];
  const recentNews = latestNews?.slice(0, 3) ?? [];

  return (
    <PublicLayout>
      {/* ── Hero ─────────────────────────────────────────────────────────── */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${CDN.heroSailing})` }}
        />
        <div className="absolute inset-0 hero-overlay" />

        <div className="relative container pt-24 pb-20">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm border border-white/25 rounded-full px-4 py-1.5 mb-6">
              <Anchor className="w-3.5 h-3.5 text-accent" />
              <span className="text-white/90 text-xs font-medium">Zeeverkenners · Middelaar, Nederland</span>
            </div>

            <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight text-balance">
              Avontuur op{" "}
              <span className="text-gold-gradient">het water</span>
            </h1>

            <p className="text-white/80 text-lg md:text-xl leading-relaxed mb-10 max-w-xl">
              Gabriël Groep is een waterscoutinggroep voor jeugd van 7 tot 18 jaar. Zeilen, kamperen en vriendschappen voor het leven.
            </p>

            <div className="flex flex-wrap gap-4">
              <Link href="/lid-worden">
                <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 font-semibold px-8">
                  Word Lid
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
              <Link href="/over-ons">
                <Button size="lg" variant="outline" className="border-white/50 text-white hover:bg-white/10 backdrop-blur-sm">
                  Meer Informatie
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 animate-bounce">
          <div className="w-px h-8 bg-white/40" style={{width: '0px', height: '0px', opacity: '0'}} />
          <div className="w-1.5 h-1.5 rounded-full bg-white/60" style={{borderRadius: '0px', width: '0px', height: '0px', opacity: '0'}} />
        </div>
      </section>

      {/* ── Stats strip ──────────────────────────────────────────────────── */}
      <section className="bg-primary py-10">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {[
              { value: "50+", label: "Actieve Leden" },
              { value: "3", label: "Speltakken" },
              { value: "60+", label: "Jaar Ervaring" },
              { value: "100%", label: "Vrijwilligers" },
            ].map((stat) => (
              <div key={stat.label}>
                <div className="font-display text-3xl font-bold text-accent">{stat.value}</div>
                <div className="text-white/70 text-sm mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Speltakken ───────────────────────────────────────────────────── */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="text-center mb-14">
            <Badge variant="outline" className="mb-4 text-primary border-primary/30">Onze Groepen</Badge>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
              Drie Speltakken
            </h2>
            <p className="text-muted-foreground text-lg max-w-xl mx-auto">
              Elke leeftijdsgroep heeft zijn eigen programma, activiteiten en avonturen op het water.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {speltakken.map((speltak) => (
              <Card key={speltak.key} className={`card-hover border-2 ${speltak.border} overflow-hidden`}>
                <div className={`h-2 bg-gradient-to-r ${speltak.color}`} />
                <CardContent className="p-7">
                  <div className={`w-14 h-14 rounded-2xl ${speltak.bg} flex items-center justify-center text-2xl mb-5`}>
                    {speltak.emoji}
                  </div>
                  <h3 className={`font-display text-2xl font-bold mb-1 ${speltak.textColor}`}>
                    {speltak.name}
                  </h3>
                  <p className="text-xs font-medium text-muted-foreground mb-3">
                    {SPELTAK_AGES[speltak.key]}
                  </p>
                  <p className="text-muted-foreground text-sm leading-relaxed mb-5">
                    {SPELTAK_DESCRIPTIONS[speltak.key]}
                  </p>
                  <Link href="/over-ons">
                    <Button variant="ghost" size="sm" className={`${speltak.textColor} p-0 h-auto font-medium`}>
                      Meer lezen <ChevronRight className="w-4 h-4 ml-1" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* ── Features ─────────────────────────────────────────────────────── */}
      <section className="py-20 bg-muted/40">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <Badge variant="outline" className="mb-4 text-primary border-primary/30">Waarom Gabriël Groep</Badge>
              <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-6">
                Meer dan alleen zeilen
              </h2>
              <p className="text-muted-foreground text-lg leading-relaxed mb-8">
                Bij Gabriël Groep leren kinderen niet alleen zeilen — ze ontwikkelen verantwoordelijkheidsgevoel, teamwork en zelfvertrouwen in een veilige en inspirerende omgeving.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {features.map((f) => (
                  <div key={f.title} className="flex gap-4">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                      <f.icon className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground text-sm mb-1">{f.title}</h4>
                      <p className="text-muted-foreground text-xs leading-relaxed">{f.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <div className="rounded-2xl overflow-hidden shadow-xl">
                <img
                  src={CDN.scoutSailing}
                  alt="Scouts zeilen op het water"
                  className="w-full h-80 object-cover"
                />
              </div>
              <div className="absolute -bottom-5 -left-5 bg-white rounded-xl shadow-lg p-4 border border-border">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center">
                    <Star className="w-5 h-5 text-accent" />
                  </div>
                  <div>
                    <div className="font-semibold text-sm text-foreground">Erkende Scoutinggroep</div>
                    <div className="text-xs text-muted-foreground">Scouting Nederland lid</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Upcoming Events ──────────────────────────────────────────────── */}
      {nextEvents.length > 0 && (
        <section className="py-20 bg-background">
          <div className="container">
            <div className="flex items-center justify-between mb-10">
              <div>
                <Badge variant="outline" className="mb-3 text-primary border-primary/30">Agenda</Badge>
                <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground">
                  Aankomende Activiteiten
                </h2>
              </div>
              <Link href="/agenda">
                <Button variant="outline" className="hidden md:flex">
                  Alle activiteiten <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {nextEvents.map((event) => (
                <Card key={event.id} className="card-hover border border-border">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-3">
                      <div className="w-12 h-12 rounded-xl bg-primary/10 flex flex-col items-center justify-center">
                        <span className="text-primary font-bold text-sm leading-none">
                          {format(new Date(event.startDate), "d", { locale: nl })}
                        </span>
                        <span className="text-primary/70 text-xs uppercase">
                          {format(new Date(event.startDate), "MMM", { locale: nl })}
                        </span>
                      </div>
                      <span className={`text-xs px-2.5 py-1 rounded-full font-medium badge-${event.speltak === "wilde_vaart" ? "wilde-vaart" : event.speltak}`}>
                        {event.speltak === "all" ? "Iedereen" : event.speltak === "wilde_vaart" ? "Wilde Vaart" : event.speltak.charAt(0).toUpperCase() + event.speltak.slice(1)}
                      </span>
                    </div>
                    <h3 className="font-semibold text-foreground mb-1">{event.title}</h3>
                    {event.location && (
                      <div className="flex items-center gap-1.5 text-muted-foreground text-xs">
                        <MapPin className="w-3 h-3" />
                        {event.location}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="mt-6 text-center md:hidden">
              <Link href="/agenda">
                <Button variant="outline">Alle activiteiten bekijken</Button>
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* ── Latest News ──────────────────────────────────────────────────── */}
      {recentNews.length > 0 && (
        <section className="py-20 bg-muted/40">
          <div className="container">
            <div className="flex items-center justify-between mb-10">
              <div>
                <Badge variant="outline" className="mb-3 text-primary border-primary/30">Nieuws</Badge>
                <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground">
                  Laatste Nieuws
                </h2>
              </div>
              <Link href="/nieuws">
                <Button variant="outline" className="hidden md:flex">
                  Alle berichten <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {recentNews.map((item) => (
                <Card key={item.id} className="card-hover overflow-hidden border border-border">
                  {item.coverImageUrl && (
                    <div className="h-44 overflow-hidden">
                      <img src={item.coverImageUrl} alt={item.title} className="w-full h-full object-cover" />
                    </div>
                  )}
                  <CardContent className="p-5">
                    <p className="text-xs text-muted-foreground mb-2">
                      {item.publishedAt ? format(new Date(item.publishedAt), "d MMMM yyyy", { locale: nl }) : ""}
                    </p>
                    <h3 className="font-semibold text-foreground mb-2 line-clamp-2">{item.title}</h3>
                    {item.excerpt && (
                      <p className="text-muted-foreground text-sm line-clamp-2">{item.excerpt}</p>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ── CTA ──────────────────────────────────────────────────────────── */}
      <section className="py-20 bg-primary relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-white transform translate-x-1/2 -translate-y-1/2" />
          <div className="absolute bottom-0 left-0 w-64 h-64 rounded-full bg-white transform -translate-x-1/2 translate-y-1/2" />
        </div>
        <div className="relative container text-center">
          <h2 className="font-display text-4xl md:text-5xl font-bold text-white mb-5">
            Klaar voor het avontuur?
          </h2>
          <p className="text-white/75 text-lg mb-10 max-w-xl mx-auto">
            Meld je kind aan bij Gabriël Groep en ontdek de magie van zeilen, scouting en vriendschappen voor het leven.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/lid-worden">
              <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 font-semibold px-10">
                Aanmelden
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
            <Link href="/contact">
              <Button size="lg" variant="outline" className="border-white/40 text-white hover:bg-white/10">
                Neem Contact Op
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
