import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isToday, addMonths, subMonths, startOfWeek, endOfWeek, isBefore, isAfter, getMonth, getYear } from "date-fns";
import { nl } from "date-fns/locale";
import { ChevronLeft, ChevronRight, Calendar, MapPin, Users } from "lucide-react";
import SpeltakBadge from "@/components/SpeltakBadge";
import { EVENT_TYPE_LABELS } from "@/lib/constants";
import PublicLayout from "@/components/PublicLayout";
import AdminPhotoUpload from "@/components/AdminPhotoUpload";

const VERHUUR_ALBUMS = {
  RUIMTE_1: 1,
  RUIMTE_2: 2,
};

export default function Verhuur() {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  const { data: events } = trpc.events.listPublic.useQuery({
    from: startOfMonth(currentMonth),
    to: endOfMonth(currentMonth),
  });

  const { data: ruimte1Photos, refetch: refetchRuimte1 } = trpc.photos.getPhotos.useQuery({ albumId: VERHUUR_ALBUMS.RUIMTE_1 });
  const { data: ruimte2Photos, refetch: refetchRuimte2 } = trpc.photos.getPhotos.useQuery({ albumId: VERHUUR_ALBUMS.RUIMTE_2 });

  const rentalEvents = events?.filter((e) => e.type === "rental") ?? [];

  // Check if a day falls within an event's range (including multi-day events)
  const eventCoversDay = (event: any, day: Date): boolean => {
    const start = new Date(event.startDate);
    const end = event.endDate ? new Date(event.endDate) : start;
    // Normalize to date-only comparison
    const dayStart = new Date(day.getFullYear(), day.getMonth(), day.getDate());
    const evStart = new Date(start.getFullYear(), start.getMonth(), start.getDate());
    const evEnd = new Date(end.getFullYear(), end.getMonth(), end.getDate());
    return dayStart >= evStart && dayStart <= evEnd;
  };

  const selectedDayEvents = selectedDate
    ? rentalEvents.filter((e) => eventCoversDay(e, selectedDate))
    : rentalEvents;

  // Calendar grid
  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const calStart = startOfWeek(monthStart, { weekStartsOn: 1 });
  const calEnd = endOfWeek(monthEnd, { weekStartsOn: 1 });
  const days = eachDayOfInterval({ start: calStart, end: calEnd });

  const getEventsForDay = (day: Date) =>
    rentalEvents.filter((e) => eventCoversDay(e, day));

  return (
    <PublicLayout>
      {/* Hero */}
      <section className="relative pt-32 pb-16 bg-primary overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-white transform translate-x-1/3 -translate-y-1/3" />
        </div>
        <div className="relative container">
          <Badge className="bg-white/20 text-white border-white/30 mb-5">Verhuur</Badge>
          <h1 className="font-display text-5xl font-bold text-white mb-4">Ruimteverhuur</h1>
          <p className="text-white/80 text-xl max-w-xl">
            Huur onze ruimtes voor vergaderingen, workshops of evenementen.
          </p>
        </div>
      </section>

      {/* Calendar & Events */}
      <section className="py-16 bg-background">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Calendar */}
            <div className="lg:col-span-1">
              <Card className="border border-border">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="font-display font-bold text-foreground">
                      {format(currentMonth, "MMMM yyyy", { locale: nl })}
                    </h3>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
                      >
                        <ChevronLeft className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
                      >
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Weekday headers */}
                  <div className="grid grid-cols-7 gap-1 mb-2">
                    {["Ma", "Di", "Wo", "Do", "Vr", "Za", "Zo"].map((day) => (
                      <div key={day} className="text-center text-xs font-semibold text-muted-foreground py-2">
                        {day}
                      </div>
                    ))}
                  </div>

                  {/* Calendar days */}
                  <div className="grid grid-cols-7 gap-1">
                    {days.map((day) => {
                      const dayEvents = getEventsForDay(day);
                      const isSelected = selectedDate && isSameDay(day, selectedDate);
                      const isCurrentMonth = getMonth(day) === getMonth(currentMonth) && getYear(day) === getYear(currentMonth);

                      return (
                        <button
                          key={day.toString()}
                          onClick={() => setSelectedDate(day)}
                          className={`relative p-2 text-xs rounded-lg transition-colors flex flex-col items-center gap-0.5 ${
                            isSelected
                              ? "bg-primary text-primary-foreground"
                              : isToday(day)
                              ? "bg-muted text-foreground border border-border"
                              : isCurrentMonth
                              ? "text-foreground hover:bg-muted"
                              : "text-muted-foreground"
                          }`}
                        >
                          <span className={dayEvents.length > 0 && !isSelected ? "font-semibold" : ""}>
                            {format(day, "d")}
                          </span>
                          {dayEvents.length > 0 && (
                            <span
                              className={`w-1.5 h-1.5 rounded-full ${isSelected ? "bg-white" : "bg-primary"}`}
                            />
                          )}
                        </button>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Events List */}
            <div className="lg:col-span-2">
              <div className="space-y-4">
                {selectedDayEvents.length === 0 ? (
                  <div className="text-center py-12">
                    <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="font-display text-lg font-bold text-foreground mb-2">
                      {selectedDate ? "Geen verhuuringen" : "Selecteer een datum"}
                    </h3>
                    <p className="text-muted-foreground">
                      {selectedDate
                        ? "Er zijn geen verhuuringen op deze datum."
                        : "Klik op een datum in de kalender om verhuuringen te zien."}
                    </p>
                  </div>
                ) : (
                  selectedDayEvents.map((event) => (
                    <Card key={event.id} className="card-hover border border-border overflow-hidden">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h3 className="font-display font-bold text-foreground text-lg mb-1">
                              {event.title}
                            </h3>
                            <p className="text-sm text-muted-foreground">
                              {format(new Date(event.startDate), "d MMMM yyyy HH:mm", { locale: nl })}
                              {event.endDate && ` - ${format(new Date(event.endDate), "HH:mm", { locale: nl })}`}
                            </p>
                          </div>
                          {event.type && (
                            <Badge variant="secondary">{EVENT_TYPE_LABELS[event.type as keyof typeof EVENT_TYPE_LABELS] || event.type}</Badge>
                          )}
                        </div>

                        {event.description && (
                          <p className="text-muted-foreground text-sm mb-4 leading-relaxed">
                            {event.description}
                          </p>
                        )}

                        <div className="flex flex-wrap gap-4 text-sm">
                          {event.location && (
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <MapPin className="w-4 h-4" />
                              {event.location}
                            </div>
                          )}
                          {event.maxParticipants && (
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <Users className="w-4 h-4" />
                              Max {event.maxParticipants} deelnemers
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Room 1 Photos */}
      <section className="py-16 bg-muted/30">
        <div className="container">
          <div className="mb-12 flex items-center justify-between">
            <div>
              <h2 className="font-display text-4xl font-bold text-foreground mb-2">Ruimte 1</h2>
              <p className="text-muted-foreground text-lg">Foto's van onze eerste ruimte</p>
            </div>
            <AdminPhotoUpload
              albumId={VERHUUR_ALBUMS.RUIMTE_1}
              albumTitle="Ruimte 1"
              onUploadSuccess={() => refetchRuimte1()}
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {ruimte1Photos && ruimte1Photos.length > 0 ? (
              ruimte1Photos.map((photo: any) => (
                <div key={photo.id} className="aspect-video bg-muted rounded-lg overflow-hidden group cursor-pointer">
                  <img
                    src={photo.url}
                    alt={photo.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                </div>
              ))
            ) : (
              <div className="col-span-full text-center py-12 text-muted-foreground">
                <p>Nog geen foto's geupload</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Room 2 Photos */}
      <section className="py-16 bg-background">
        <div className="container">
          <div className="mb-12 flex items-center justify-between">
            <div>
              <h2 className="font-display text-4xl font-bold text-foreground mb-2">Ruimte 2</h2>
              <p className="text-muted-foreground text-lg">Foto's van onze tweede ruimte</p>
            </div>
            <AdminPhotoUpload
              albumId={VERHUUR_ALBUMS.RUIMTE_2}
              albumTitle="Ruimte 2"
              onUploadSuccess={() => refetchRuimte2()}
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {ruimte2Photos && ruimte2Photos.length > 0 ? (
              ruimte2Photos.map((photo: any) => (
                <div key={photo.id} className="aspect-video bg-muted rounded-lg overflow-hidden group cursor-pointer">
                  <img
                    src={photo.url}
                    alt={photo.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                </div>
              ))
            ) : (
              <div className="col-span-full text-center py-12 text-muted-foreground">
                <p>Nog geen foto's geupload</p>
              </div>
            )}
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
