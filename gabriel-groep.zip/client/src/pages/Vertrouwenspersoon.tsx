import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Phone, Shield, Heart, Lock } from "lucide-react";
import PublicLayout from "@/components/PublicLayout";

export default function Vertrouwenspersoon() {
  return (
    <PublicLayout>
      {/* Hero */}
      <section className="relative pt-32 pb-16 bg-primary overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-white transform translate-x-1/3 -translate-y-1/3" />
          <div className="absolute bottom-0 left-0 w-64 h-64 rounded-full bg-white transform -translate-x-1/3 translate-y-1/3" />
        </div>
        <div className="relative container">
          <Badge className="bg-white/20 text-white border-white/30 mb-5">Veiligheid & Vertrouwen</Badge>
          <h1 className="font-display text-5xl font-bold text-white mb-4">Vertrouwenspersoon</h1>
          <p className="text-white/80 text-xl max-w-xl">
            Bij Gabriël Groep nemen we de veiligheid en het welzijn van al onze leden serieus.
          </p>
        </div>
      </section>

      {/* Intro */}
      <section className="py-16 bg-background">
        <div className="container max-w-4xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <Card className="border border-border text-center">
              <CardContent className="p-6">
                <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-display font-bold text-foreground mb-2">Extern & Onafhankelijk</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Een externe vertrouwenspersoon biedt een veilig en onafhankelijk perspectief buiten de vereniging.
                </p>
              </CardContent>
            </Card>
            <Card className="border border-border text-center">
              <CardContent className="p-6">
                <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Lock className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-display font-bold text-foreground mb-2">Vertrouwelijk</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Alles wat je deelt blijft vertrouwelijk. Je kunt vrijuit spreken zonder zorgen.
                </p>
              </CardContent>
            </Card>
            <Card className="border border-border text-center">
              <CardContent className="p-6">
                <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Heart className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-display font-bold text-foreground mb-2">Altijd Bereikbaar</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Heb je ergens mee gezeten? Neem gerust contact op. Je hoeft er niet alleen voor te staan.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Person card */}
      <section className="py-16 bg-muted/30">
        <div className="container max-w-4xl">
          <h2 className="font-display text-4xl font-bold text-foreground mb-12 text-center">
            Onze Vertrouwenspersoon
          </h2>

          <Card className="border border-border overflow-hidden">
            <CardContent className="p-0">
              <div className="grid grid-cols-1 md:grid-cols-2">
                {/* Photo */}
                <div className="relative bg-muted overflow-hidden min-h-[400px] md:min-h-[500px]">
                  <img
                    src="https://d2xsxph8kpxj0f.cloudfront.net/310519663467900671/auFutdbkCM7YzmFQQVZLdc/salomo_mul_c435696a.jpeg"
                    alt="Salomo Mul"
                    className="w-full h-full object-cover object-top absolute inset-0"
                  />
                </div>

                {/* Info */}
                <div className="p-8 md:p-10 flex flex-col justify-center">
                  <Badge className="w-fit mb-4 bg-primary/10 text-primary border-primary/20">
                    Extern Vertrouwenspersoon
                  </Badge>
                  <h3 className="font-display text-3xl font-bold text-foreground mb-6">
                    Salomo Mul
                  </h3>

                  <div className="space-y-4 text-muted-foreground leading-relaxed">
                    <p>
                      Salomo is voor onze vereniging het externe vertrouwenspersoon. Hij is in het verleden lid geweest bij onze vereniging, kent de cultuur maar biedt een veilig extern perspectief op het moment dat je vragen hebt.
                    </p>
                    <p>
                      Salomo komt oorspronkelijk uit Groesbeek maar woont al enige tijd samen met zijn verloofde in Malden.
                    </p>
                    <p>
                      Mocht je ergens mee zitten wat je niet intern bij de schipper of het bestuur kan melden, contacteer dan Salomo.
                    </p>
                  </div>

                  <div className="mt-8 pt-6 border-t border-border">
                    <p className="text-sm text-muted-foreground mb-3 font-medium uppercase tracking-wide">
                      Contact
                    </p>
                    <a
                      href="tel:0642661981"
                      className="inline-flex items-center gap-3 text-primary hover:text-primary/80 transition-colors font-semibold text-lg"
                    >
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Phone className="w-5 h-5" />
                      </div>
                      06 42661981
                    </a>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* When to contact */}
      <section className="py-16 bg-background">
        <div className="container max-w-3xl text-center">
          <h2 className="font-display text-3xl font-bold text-foreground mb-6">
            Wanneer neem je contact op?
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed mb-8">
            Je kunt contact opnemen met de vertrouwenspersoon als je je ergens onveilig voelt, als je getuige bent van ongewenst gedrag, of als je gewoon ergens over wilt praten wat je niet intern kwijt kunt. Er is geen drempel te hoog — elke vraag is welkom.
          </p>
          <div className="bg-primary/5 border border-primary/20 rounded-2xl p-6 text-left">
            <p className="text-foreground font-medium mb-2">Voorbeelden van situaties:</p>
            <ul className="space-y-2 text-muted-foreground text-sm">
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                Ongewenste omgangsvormen of pesterijen binnen de groep
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                Situaties waarbij je je niet veilig voelt
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                Vragen over gedrag van leiding of andere leden
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                Alles wat je niet intern kwijt kunt maar wel kwijt wilt
              </li>
            </ul>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
