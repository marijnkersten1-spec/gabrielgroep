import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import { Newspaper } from "lucide-react";
import SpeltakBadge from "@/components/SpeltakBadge";
import PublicLayout from "@/components/PublicLayout";

export default function Nieuws() {
  const { data: newsItems, isLoading } = trpc.news.listPublic.useQuery();

  return (
    <PublicLayout>
      {/* Hero */}
      <section className="relative pt-32 pb-16 bg-primary overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-white transform translate-x-1/3 -translate-y-1/3" />
        </div>
        <div className="relative container">
          <Badge className="bg-white/20 text-white border-white/30 mb-5">Nieuws</Badge>
          <h1 className="font-display text-5xl font-bold text-white mb-4">Laatste Nieuws</h1>
          <p className="text-white/80 text-xl max-w-xl">
            Blijf op de hoogte van activiteiten, evenementen en nieuws van Gabriël Groep.
          </p>
        </div>
      </section>

      {/* News Grid */}
      <section className="py-16 bg-background">
        <div className="container">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="h-64 rounded-xl bg-muted animate-pulse" />
              ))}
            </div>
          ) : !newsItems?.length ? (
            <div className="text-center py-20">
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
                <Newspaper className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="font-display text-xl font-bold text-foreground mb-2">Geen nieuws gevonden</h3>
              <p className="text-muted-foreground">Er zijn momenteel geen nieuwsberichten gepubliceerd.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {newsItems.map((item, i) => (
                <Card key={item.id} className={`card-hover overflow-hidden border border-border ${i === 0 ? "md:col-span-2 lg:col-span-2" : ""}`}>
                  {item.coverImageUrl && (
                    <div className={`overflow-hidden ${i === 0 ? "h-56" : "h-44"}`}>
                      <img
                        src={item.coverImageUrl}
                        alt={item.title}
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                  )}
                  <CardContent className="p-5">
                    <div className="flex items-center gap-2 mb-3">
                      {item.speltak && item.speltak !== "all" && (
                        <SpeltakBadge speltak={item.speltak} size="sm" />
                      )}
                      <span className="text-xs text-muted-foreground">
                        {item.publishedAt
                          ? format(new Date(item.publishedAt), "d MMMM yyyy", { locale: nl })
                          : ""}
                      </span>
                    </div>
                    <h3 className={`font-display font-bold text-foreground mb-2 ${i === 0 ? "text-2xl" : "text-lg"}`}>
                      {item.title}
                    </h3>
                    {item.excerpt && (
                      <p className="text-muted-foreground text-sm leading-relaxed line-clamp-3">
                        {item.excerpt}
                      </p>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>
    </PublicLayout>
  );
}
