import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import { Plus, Newspaper, Edit, Trash2, Eye, EyeOff } from "lucide-react";
import SpeltakBadge from "@/components/SpeltakBadge";

export default function AdminNieuws() {
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({
    title: "", excerpt: "", content: "", coverImageUrl: "",
    speltak: "all" as any, isPublished: false,
  });

  const { data: newsItems, refetch } = trpc.news.listAll.useQuery();

  const createMutation = trpc.news.create.useMutation({
    onSuccess: () => { toast.success("Nieuwsbericht aangemaakt"); refetch(); setShowCreate(false); resetForm(); },
    onError: (err: any) => toast.error(err.message),
  });

  const deleteMutation = trpc.news.delete.useMutation({
    onSuccess: () => { toast.success("Bericht verwijderd"); refetch(); },
    onError: (err: any) => toast.error(err.message),
  });

  const publishMutation = trpc.news.update.useMutation({
    onSuccess: () => { toast.success("Status bijgewerkt"); refetch(); },
    onError: (err: any) => toast.error(err.message),
  });

  const resetForm = () => setForm({
    title: "", excerpt: "", content: "", coverImageUrl: "", speltak: "all", isPublished: false,
  });

  const handleCreate = () => {
    if (!form.title) { toast.error("Vul een titel in"); return; }
    const slug = form.title.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "") + "-" + Date.now();
    createMutation.mutate({
      title: form.title,
      slug,
      excerpt: form.excerpt || undefined,
      content: form.content || "Inhoud volgt.",
      coverImageUrl: form.coverImageUrl || undefined,
      speltak: form.speltak,
      isPublished: form.isPublished,
    });
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground mb-1">Nieuws Beheer</h1>
          <p className="text-muted-foreground">{newsItems?.length ?? 0} berichten totaal</p>
        </div>
        <Button onClick={() => setShowCreate(true)}>
          <Plus className="w-4 h-4 mr-2" /> Nieuw Bericht
        </Button>
      </div>

      {!newsItems?.length ? (
        <div className="text-center py-16 text-muted-foreground">
          <Newspaper className="w-10 h-10 mx-auto mb-3 opacity-40" />
          <p>Nog geen nieuwsberichten</p>
        </div>
      ) : (
        <div className="space-y-3">
          {newsItems.map((item) => (
            <Card key={item.id} className="border border-border">
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  {item.coverImageUrl && (
                    <div className="w-20 h-16 rounded-lg overflow-hidden shrink-0">
                      <img src={item.coverImageUrl} alt={item.title} className="w-full h-full object-cover" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-foreground text-sm">{item.title}</h3>
                      {item.speltak && item.speltak !== "all" && (
                        <SpeltakBadge speltak={item.speltak} size="sm" />
                      )}
                      <Badge variant={item.isPublished ? "default" : "outline"} className="text-xs">
                        {item.isPublished ? "Gepubliceerd" : "Concept"}
                      </Badge>
                    </div>
                    {item.excerpt && (
                      <p className="text-xs text-muted-foreground line-clamp-2">{item.excerpt}</p>
                    )}
                    <p className="text-xs text-muted-foreground mt-1">
                      {item.publishedAt
                        ? format(new Date(item.publishedAt), "d MMMM yyyy", { locale: nl })
                        : format(new Date(item.createdAt), "d MMMM yyyy", { locale: nl })}
                    </p>
                  </div>
                  <div className="flex gap-2 shrink-0">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => publishMutation.mutate({ id: item.id, isPublished: !item.isPublished })}
                      title={item.isPublished ? "Depubliceren" : "Publiceren"}
                    >
                      {item.isPublished ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteMutation.mutate({ id: item.id })}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Create Dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Nieuw Nieuwsbericht</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Titel *</Label>
              <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="mt-1.5" />
            </div>
            <div>
              <Label>Speltak</Label>
              <Select value={form.speltak} onValueChange={(v) => setForm({ ...form, speltak: v })}>
                <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Iedereen</SelectItem>
                  <SelectItem value="dolfijnen">Dolfijnen</SelectItem>
                  <SelectItem value="verkenners">Verkenners</SelectItem>
                  <SelectItem value="wilde_vaart">Wilde Vaart</SelectItem>
                  <SelectItem value="staf">Staf</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Samenvatting</Label>
              <Textarea value={form.excerpt} onChange={(e) => setForm({ ...form, excerpt: e.target.value })} className="mt-1.5 resize-none" rows={2} />
            </div>
            <div>
              <Label>Inhoud</Label>
              <Textarea value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} className="mt-1.5 resize-none" rows={5} />
            </div>
            <div>
              <Label>Afbeelding URL</Label>
              <Input value={form.coverImageUrl} onChange={(e) => setForm({ ...form, coverImageUrl: e.target.value })} placeholder="https://..." className="mt-1.5" />
            </div>
            <div className="flex items-center gap-3">
              <Switch checked={form.isPublished} onCheckedChange={(v) => setForm({ ...form, isPublished: v })} />
              <Label>Direct publiceren</Label>
            </div>
            <div className="flex gap-3 pt-2">
              <Button variant="outline" className="flex-1" onClick={() => setShowCreate(false)}>Annuleren</Button>
              <Button className="flex-1" onClick={handleCreate} disabled={createMutation.isPending}>
                {createMutation.isPending ? "Aanmaken..." : "Aanmaken"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
