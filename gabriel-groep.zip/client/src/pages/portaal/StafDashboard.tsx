import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import { Users, Calendar, Wrench, ArrowRight, CheckCircle2, Clock, FileCheck } from "lucide-react";
import SpeltakBadge from "@/components/SpeltakBadge";

export default function StafDashboard() {
  const { data: members } = trpc.members.list.useQuery();
  const { data: events } = trpc.events.list.useQuery({});
  const { data: equipment } = trpc.equipment.list.useQuery();
  const { data: joinRequests = [] } = trpc.join.list.useQuery();
  const pendingApprovals = joinRequests.filter((r: any) => r.status === "pending").length;

  const upcomingEvents = events?.filter((e) => new Date(e.startDate) >= new Date()).slice(0, 5) ?? [];
  const totalMembers = members?.length ?? 0;
  const totalEvents = upcomingEvents.length;
  const maintenanceItems = equipment?.filter((e) => e.status === "maintenance").length ?? 0;

  const speltakCounts = {
    dolfijnen: members?.filter((m) => m.speltak === "dolfijnen").length ?? 0,
    verkenners: members?.filter((m) => m.speltak === "verkenners").length ?? 0,
    wilde_vaart: members?.filter((m) => m.speltak === "wilde_vaart").length ?? 0,
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold text-foreground mb-1">Staf Dashboard</h1>
        <p className="text-muted-foreground">{format(new Date(), "EEEE d MMMM yyyy", { locale: nl })}</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: "Totaal Leden", value: totalMembers, icon: Users, color: "text-blue-600 bg-blue-50", href: "/portaal/staf/leden" },
          { label: "Aankomende Activiteiten", value: totalEvents, icon: Calendar, color: "text-green-600 bg-green-50", href: "/portaal/staf/activiteiten" },
          { label: "Onderhoud Vereist", value: maintenanceItems, icon: Wrench, color: "text-orange-600 bg-orange-50", href: "/portaal/staf/inventaris" },
          { label: "Aanmeldingen", value: pendingApprovals, icon: FileCheck, color: pendingApprovals > 0 ? "text-red-600 bg-red-50" : "text-purple-600 bg-purple-50", href: "/portaal/staf/aanmeldingen" },
        ].map((stat) => (
          <Link key={stat.label} href={stat.href}>
            <Card className="border border-border hover:shadow-sm transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <div className={`w-9 h-9 rounded-xl ${stat.color} flex items-center justify-center mb-3`}>
                  <stat.icon className="w-4.5 h-4.5" />
                </div>
                <div className="font-display text-2xl font-bold text-foreground">{stat.value}</div>
                <div className="text-muted-foreground text-xs mt-0.5">{stat.label}</div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Speltak breakdown */}
        <Card className="border border-border">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="font-display text-lg">Leden per Speltak</CardTitle>
              <Link href="/portaal/staf/leden">
                <Button variant="ghost" size="sm" className="text-primary">
                  Beheren <ArrowRight className="w-3 h-3 ml-1" />
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {Object.entries(speltakCounts).map(([speltak, count]) => (
              <div key={speltak} className="flex items-center gap-3">
                <SpeltakBadge speltak={speltak} />
                <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary rounded-full transition-all"
                    style={{ width: totalMembers > 0 ? `${(count / totalMembers) * 100}%` : "0%" }}
                  />
                </div>
                <span className="text-sm font-medium text-foreground w-6 text-right">{count}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Upcoming events */}
        <Card className="border border-border">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="font-display text-lg">Aankomende Activiteiten</CardTitle>
              <Link href="/portaal/staf/activiteiten">
                <Button variant="ghost" size="sm" className="text-primary">
                  Beheren <ArrowRight className="w-3 h-3 ml-1" />
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {upcomingEvents.length === 0 ? (
              <p className="text-muted-foreground text-sm text-center py-4">Geen aankomende activiteiten</p>
            ) : (
              upcomingEvents.map((event) => (
                <div key={event.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted/40">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex flex-col items-center justify-center shrink-0">
                    <span className="text-primary font-bold text-xs leading-none">
                      {format(new Date(event.startDate), "d")}
                    </span>
                    <span className="text-primary/70 text-xs uppercase">
                      {format(new Date(event.startDate), "MMM", { locale: nl })}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm text-foreground truncate">{event.title}</div>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      {format(new Date(event.startDate), "HH:mm", { locale: nl })}
                    </div>
                  </div>
                  <SpeltakBadge speltak={event.speltak} size="sm" />
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
