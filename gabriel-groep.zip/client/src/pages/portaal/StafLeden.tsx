import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Search, Users, Mail, Phone, Edit } from "lucide-react";
import SpeltakBadge from "@/components/SpeltakBadge";
import { SPELTAK_LABELS } from "@/lib/constants";

export default function StafLeden() {
  const [search, setSearch] = useState("");
  const [speltakFilter, setSpeltakFilter] = useState("all");
  const [editingMember, setEditingMember] = useState<any | null>(null);

  const { data: members, isLoading, refetch } = trpc.members.list.useQuery();

  const updateMutation = trpc.members.update.useMutation({
    onSuccess: () => { toast.success("Lid bijgewerkt"); refetch(); setEditingMember(null); },
    onError: (err: any) => toast.error(err.message),
  });

  const filtered = members?.filter((m) => {
    const matchSearch = (m.name ?? "").toLowerCase().includes(search.toLowerCase()) ||
      (m.email ?? "").toLowerCase().includes(search.toLowerCase());
    const matchSpeltak = speltakFilter === "all" || m.speltak === speltakFilter;
    return matchSearch && matchSpeltak;
  }) ?? [];

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground mb-1">Leden</h1>
          <p className="text-muted-foreground">{members?.length ?? 0} leden in totaal</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Zoek op naam of e-mail..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          {["all", "dolfijnen", "verkenners", "wilde_vaart", "staf"].map((s) => (
            <Button
              key={s}
              variant={speltakFilter === s ? "default" : "outline"}
              size="sm"
              onClick={() => setSpeltakFilter(s)}
            >
              {s === "all" ? "Alle" : SPELTAK_LABELS[s]}
            </Button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="h-16 rounded-xl bg-muted animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <Users className="w-10 h-10 mx-auto mb-3 opacity-40" />
          <p>Geen leden gevonden</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((member) => (
            <Card key={member.id} className="border border-border hover:shadow-sm transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <Avatar className="w-10 h-10">
                    <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                      {(member.name ?? "?").charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="font-medium text-foreground text-sm">{member.name ?? "Onbekend"}</span>
                      {member.speltak && <SpeltakBadge speltak={member.speltak} size="sm" />}
                      {member.role === "admin" && (
                        <Badge variant="outline" className="text-xs border-red-300 text-red-600">Admin</Badge>
                      )}
                      {member.role === "staff" && (
                        <Badge variant="outline" className="text-xs border-blue-300 text-blue-600">Staf</Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      {member.email && (
                        <span className="flex items-center gap-1">
                          <Mail className="w-3 h-3" /> {member.email}
                        </span>
                      )}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setEditingMember(member)}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Edit Member Dialog */}
      <Dialog open={!!editingMember} onOpenChange={() => setEditingMember(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Lid Bewerken</DialogTitle>
          </DialogHeader>
          {editingMember && (
            <div className="space-y-4">
              <div>
                <Label>Speltak</Label>
                <Select
                  defaultValue={editingMember.speltak ?? ""}
                  onValueChange={(val) => setEditingMember({ ...editingMember, speltak: val })}
                >
                  <SelectTrigger className="mt-1.5">
                    <SelectValue placeholder="Kies speltak" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dolfijnen">Dolfijnen</SelectItem>
                    <SelectItem value="verkenners">Verkenners</SelectItem>
                    <SelectItem value="wilde_vaart">Wilde Vaart</SelectItem>
                    <SelectItem value="staf">Staf</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Rol</Label>
                <Select
                  defaultValue={editingMember.role ?? "user"}
                  onValueChange={(val) => setEditingMember({ ...editingMember, role: val })}
                >
                  <SelectTrigger className="mt-1.5">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="user">Lid</SelectItem>
                    <SelectItem value="staff">Staf</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-3 pt-2">
                <Button variant="outline" className="flex-1" onClick={() => setEditingMember(null)}>
                  Annuleren
                </Button>
                <Button
                  className="flex-1"
                  disabled={updateMutation.isPending}
                  onClick={() => updateMutation.mutate({
                    id: editingMember.id,
                    speltak: editingMember.speltak,
                    role: editingMember.role,
                  })}
                >
                  Opslaan
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
