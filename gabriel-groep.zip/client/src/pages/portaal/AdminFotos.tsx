import { useState, useRef } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Plus, Trash2, Pencil, Upload, FolderOpen, Image, ChevronLeft, Eye, EyeOff, Loader2, X } from "lucide-react";
import PortaalLayout from "@/components/PortaalLayout";

const SPELTAK_OPTIONS = [
  { value: "all", label: "Alle groepen" },
  { value: "dolfijnen", label: "Dolfijnen" },
  { value: "verkenners", label: "Verkenners" },
  { value: "wilde_vaart", label: "Wilde Vaart" },
  { value: "staf", label: "Staf" },
];

export default function AdminFotos() {
  const utils = trpc.useUtils();

  const [view, setView] = useState<"albums" | "photos">("albums");
  const [selectedAlbum, setSelectedAlbum] = useState<any>(null);

  const [createAlbumOpen, setCreateAlbumOpen] = useState(false);
  const [editAlbumOpen, setEditAlbumOpen] = useState(false);
  const [editPhotoOpen, setEditPhotoOpen] = useState(false);
  const [deleteAlbumConfirm, setDeleteAlbumConfirm] = useState<number | null>(null);
  const [deletePhotoConfirm, setDeletePhotoConfirm] = useState<number | null>(null);
  const [uploadOpen, setUploadOpen] = useState(false);

  const [albumForm, setAlbumForm] = useState({ title: "", description: "", isPublic: true, speltak: "all" });
  const [editAlbumForm, setEditAlbumForm] = useState({ id: 0, title: "", description: "", isPublic: true, speltak: "all" });
  const [editPhotoForm, setEditPhotoForm] = useState({ id: 0, title: "" });
  const [uploadFiles, setUploadFiles] = useState<File[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: albums = [], isLoading: albumsLoading } = trpc.photos.listAllAlbums.useQuery();
  const { data: photos = [], isLoading: photosLoading } = trpc.photos.getPhotos.useQuery(
    { albumId: selectedAlbum?.id ?? 0 },
    { enabled: !!selectedAlbum }
  );

  const createAlbumMutation = trpc.photos.createAlbum.useMutation({
    onSuccess: () => {
      utils.photos.listAllAlbums.invalidate();
      setCreateAlbumOpen(false);
      setAlbumForm({ title: "", description: "", isPublic: true, speltak: "all" });
      toast.success("Album aangemaakt!");
    },
    onError: (err) => toast.error("Fout: " + err.message),
  });

  const updateAlbumMutation = trpc.photos.updateAlbum.useMutation({
    onSuccess: () => {
      utils.photos.listAllAlbums.invalidate();
      setSelectedAlbum((prev: any) =>
        prev ? { ...prev, title: editAlbumForm.title, description: editAlbumForm.description, isPublic: editAlbumForm.isPublic, speltak: editAlbumForm.speltak } : prev
      );
      setEditAlbumOpen(false);
      toast.success("Album bijgewerkt!");
    },
    onError: (err) => toast.error("Fout: " + err.message),
  });

  const deleteAlbumMutation = trpc.photos.deleteAlbum.useMutation({
    onSuccess: () => {
      utils.photos.listAllAlbums.invalidate();
      if (selectedAlbum?.id === deleteAlbumConfirm) {
        setView("albums");
        setSelectedAlbum(null);
      }
      setDeleteAlbumConfirm(null);
      toast.success("Album verwijderd!");
    },
    onError: (err) => toast.error("Fout: " + err.message),
  });

  const updatePhotoMutation = trpc.photos.updatePhoto.useMutation({
    onSuccess: () => {
      utils.photos.getPhotos.invalidate({ albumId: selectedAlbum?.id });
      setEditPhotoOpen(false);
      toast.success("Foto bijgewerkt!");
    },
    onError: (err) => toast.error("Fout: " + err.message),
  });

  const deletePhotoMutation = trpc.photos.deletePhoto.useMutation({
    onSuccess: () => {
      utils.photos.getPhotos.invalidate({ albumId: selectedAlbum?.id });
      setDeletePhotoConfirm(null);
      toast.success("Foto verwijderd!");
    },
    onError: (err) => toast.error("Fout: " + err.message),
  });

  const uploadPhotoMutation = trpc.photos.uploadPhoto.useMutation({
    onError: (err) => toast.error("Upload fout: " + err.message),
  });

  const handleUpload = async () => {
    if (!uploadFiles.length || !selectedAlbum) return;
    setIsUploading(true);
    let successCount = 0;
    for (const file of uploadFiles) {
      try {
        const base64 = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve((reader.result as string).split(",")[1]);
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });
        await uploadPhotoMutation.mutateAsync({
          albumId: selectedAlbum.id,
          title: file.name.replace(/\.[^/.]+$/, ""),
          fileData: base64,
          fileName: file.name,
          mimeType: file.type,
          isPublic: selectedAlbum.isPublic,
        });
        successCount++;
      } catch {
        toast.error(`Fout bij uploaden van ${file.name}`);
      }
    }
    utils.photos.getPhotos.invalidate({ albumId: selectedAlbum.id });
    setIsUploading(false);
    setUploadFiles([]);
    setUploadOpen(false);
    if (successCount > 0) toast.success(`${successCount} foto's geupload!`);
  };

  const openAlbum = (album: any) => {
    setSelectedAlbum(album);
    setView("photos");
  };

  const openEditAlbum = (album: any, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setEditAlbumForm({
      id: album.id,
      title: album.title,
      description: album.description ?? "",
      isPublic: album.isPublic,
      speltak: album.speltak ?? "all",
    });
    setEditAlbumOpen(true);
  };

  const openEditPhoto = (photo: any) => {
    setEditPhotoForm({ id: photo.id, title: photo.title ?? "" });
    setEditPhotoOpen(true);
  };

  return (
    <PortaalLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            {view === "photos" && (
              <Button variant="ghost" size="sm" onClick={() => { setView("albums"); setSelectedAlbum(null); }}>
                <ChevronLeft className="w-4 h-4 mr-1" /> Albums
              </Button>
            )}
            <div>
              <h1 className="font-display text-3xl font-bold text-foreground">
                {view === "albums" ? "Foto Albums" : selectedAlbum?.title}
              </h1>
              <p className="text-muted-foreground text-sm mt-0.5">
                {view === "albums"
                  ? `${albums.length} album${albums.length !== 1 ? "s" : ""}`
                  : `${photos.length} foto's`}
              </p>
            </div>
          </div>
          {view === "albums" ? (
            <Button onClick={() => setCreateAlbumOpen(true)}>
              <Plus className="w-4 h-4 mr-2" /> Nieuw Album
            </Button>
          ) : (
            <Button onClick={() => setUploadOpen(true)}>
              <Upload className="w-4 h-4 mr-2" /> Foto's Uploaden
            </Button>
          )}
        </div>

        {/* Albums grid */}
        {view === "albums" && (
          <>
            {albumsLoading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
              </div>
            ) : albums.length === 0 ? (
              <Card className="border border-border">
                <CardContent className="p-16 text-center">
                  <FolderOpen className="w-14 h-14 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-display text-xl font-bold text-foreground mb-2">Geen albums</h3>
                  <p className="text-muted-foreground mb-6">Maak je eerste album aan om foto's te organiseren.</p>
                  <Button onClick={() => setCreateAlbumOpen(true)}>
                    <Plus className="w-4 h-4 mr-2" /> Nieuw Album
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {albums.map((album: any) => (
                  <Card
                    key={album.id}
                    className="border border-border hover:border-primary/50 transition-all cursor-pointer group overflow-hidden"
                    onClick={() => openAlbum(album)}
                  >
                    <div className="h-36 bg-muted flex items-center justify-center relative overflow-hidden">
                      <Image className="w-10 h-10 text-muted-foreground/30" />
                    </div>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-foreground truncate">{album.title}</h3>
                          {album.description && (
                            <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{album.description}</p>
                          )}
                          <div className="flex items-center gap-2 mt-2 flex-wrap">
                            <Badge variant="outline" className="text-xs">
                              {SPELTAK_OPTIONS.find((s) => s.value === album.speltak)?.label ?? album.speltak}
                            </Badge>
                            {!album.isPublic && (
                              <Badge variant="secondary" className="text-xs">
                                <EyeOff className="w-3 h-3 mr-1" /> Prive
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                          <Button
                            variant="ghost" size="icon" className="h-8 w-8"
                            onClick={(e) => openEditAlbum(album, e)}
                            title="Bewerken"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </Button>
                          <Button
                            variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive"
                            onClick={(e) => { e.stopPropagation(); setDeleteAlbumConfirm(album.id); }}
                            title="Verwijderen"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </>
        )}

        {/* Photos grid */}
        {view === "photos" && (
          <>
            <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-xl border border-border flex-wrap">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-semibold text-foreground">{selectedAlbum?.title}</span>
                  {!selectedAlbum?.isPublic && (
                    <Badge variant="secondary" className="text-xs">
                      <EyeOff className="w-3 h-3 mr-1" /> Prive
                    </Badge>
                  )}
                </div>
                {selectedAlbum?.description && (
                  <p className="text-sm text-muted-foreground mt-0.5">{selectedAlbum.description}</p>
                )}
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => openEditAlbum(selectedAlbum)}>
                  <Pencil className="w-3.5 h-3.5 mr-1.5" /> Bewerken
                </Button>
                <Button
                  variant="outline" size="sm"
                  className="text-destructive hover:text-destructive border-destructive/30 hover:border-destructive"
                  onClick={() => setDeleteAlbumConfirm(selectedAlbum?.id)}
                >
                  <Trash2 className="w-3.5 h-3.5 mr-1.5" /> Verwijderen
                </Button>
              </div>
            </div>

            {photosLoading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
              </div>
            ) : photos.length === 0 ? (
              <Card className="border border-border">
                <CardContent className="p-16 text-center">
                  <Image className="w-14 h-14 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-display text-xl font-bold text-foreground mb-2">Geen fotos</h3>
                  <p className="text-muted-foreground mb-6">Upload de eerste fotos voor dit album.</p>
                  <Button onClick={() => setUploadOpen(true)}>
                    <Upload className="w-4 h-4 mr-2" /> Fotos Uploaden
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                {photos.map((photo: any) => (
                  <div key={photo.id} className="group relative rounded-xl overflow-hidden border border-border bg-muted aspect-square">
                    <img src={photo.url} alt={photo.title ?? "Foto"} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/50 transition-all flex flex-col justify-between p-3 opacity-0 group-hover:opacity-100">
                      <div className="flex justify-end gap-1.5">
                        <button
                          className="w-8 h-8 rounded-full bg-white/90 flex items-center justify-center hover:bg-white transition-colors"
                          onClick={() => openEditPhoto(photo)}
                          title="Naam aanpassen"
                        >
                          <Pencil className="w-3.5 h-3.5 text-foreground" />
                        </button>
                        <button
                          className="w-8 h-8 rounded-full bg-white/90 flex items-center justify-center hover:bg-red-50 transition-colors"
                          onClick={() => setDeletePhotoConfirm(photo.id)}
                          title="Verwijderen"
                        >
                          <Trash2 className="w-3.5 h-3.5 text-destructive" />
                        </button>
                      </div>
                      {photo.title && (
                        <div className="bg-black/60 rounded-lg px-2 py-1">
                          <p className="text-white text-xs truncate">{photo.title}</p>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>

      {/* Create Album Dialog */}
      <Dialog open={createAlbumOpen} onOpenChange={setCreateAlbumOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Nieuw Album Aanmaken</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label>Album naam *</Label>
              <Input
                value={albumForm.title}
                onChange={(e) => setAlbumForm((f) => ({ ...f, title: e.target.value }))}
                placeholder="bijv. Zomerkamp 2025"
                className="mt-1.5"
              />
            </div>
            <div>
              <Label>Beschrijving</Label>
              <Textarea
                value={albumForm.description}
                onChange={(e) => setAlbumForm((f) => ({ ...f, description: e.target.value }))}
                placeholder="Optionele beschrijving..."
                className="mt-1.5 resize-none"
                rows={3}
              />
            </div>
            <div>
              <Label>Speltak</Label>
              <Select value={albumForm.speltak} onValueChange={(v) => setAlbumForm((f) => ({ ...f, speltak: v }))}>
                <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {SPELTAK_OPTIONS.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-3">
              <Switch
                checked={albumForm.isPublic}
                onCheckedChange={(v) => setAlbumForm((f) => ({ ...f, isPublic: v }))}
              />
              <Label className="cursor-pointer flex items-center gap-1.5">
                {albumForm.isPublic
                  ? <><Eye className="w-4 h-4" /> Openbaar</>
                  : <><EyeOff className="w-4 h-4" /> Prive</>}
              </Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateAlbumOpen(false)}>Annuleren</Button>
            <Button
              onClick={() => createAlbumMutation.mutate({
                title: albumForm.title,
                description: albumForm.description || undefined,
                isPublic: albumForm.isPublic,
                speltak: albumForm.speltak as any,
              })}
              disabled={!albumForm.title.trim() || createAlbumMutation.isPending}
            >
              {createAlbumMutation.isPending && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
              Aanmaken
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Album Dialog */}
      <Dialog open={editAlbumOpen} onOpenChange={setEditAlbumOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Album Bewerken</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label>Album naam *</Label>
              <Input
                value={editAlbumForm.title}
                onChange={(e) => setEditAlbumForm((f) => ({ ...f, title: e.target.value }))}
                className="mt-1.5"
              />
            </div>
            <div>
              <Label>Beschrijving</Label>
              <Textarea
                value={editAlbumForm.description}
                onChange={(e) => setEditAlbumForm((f) => ({ ...f, description: e.target.value }))}
                className="mt-1.5 resize-none"
                rows={3}
              />
            </div>
            <div>
              <Label>Speltak</Label>
              <Select value={editAlbumForm.speltak} onValueChange={(v) => setEditAlbumForm((f) => ({ ...f, speltak: v }))}>
                <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {SPELTAK_OPTIONS.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-3">
              <Switch
                checked={editAlbumForm.isPublic}
                onCheckedChange={(v) => setEditAlbumForm((f) => ({ ...f, isPublic: v }))}
              />
              <Label className="cursor-pointer flex items-center gap-1.5">
                {editAlbumForm.isPublic
                  ? <><Eye className="w-4 h-4" /> Openbaar</>
                  : <><EyeOff className="w-4 h-4" /> Prive</>}
              </Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditAlbumOpen(false)}>Annuleren</Button>
            <Button
              onClick={() => updateAlbumMutation.mutate({
                id: editAlbumForm.id,
                title: editAlbumForm.title,
                description: editAlbumForm.description || undefined,
                isPublic: editAlbumForm.isPublic,
                speltak: editAlbumForm.speltak as any,
              })}
              disabled={!editAlbumForm.title.trim() || updateAlbumMutation.isPending}
            >
              {updateAlbumMutation.isPending && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
              Opslaan
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Photo Dialog */}
      <Dialog open={editPhotoOpen} onOpenChange={setEditPhotoOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Foto Naam Aanpassen</DialogTitle></DialogHeader>
          <div className="py-2">
            <Label>Naam</Label>
            <Input
              value={editPhotoForm.title}
              onChange={(e) => setEditPhotoForm((f) => ({ ...f, title: e.target.value }))}
              placeholder="Naam van de foto"
              className="mt-1.5"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditPhotoOpen(false)}>Annuleren</Button>
            <Button
              onClick={() => updatePhotoMutation.mutate({ id: editPhotoForm.id, title: editPhotoForm.title })}
              disabled={updatePhotoMutation.isPending}
            >
              {updatePhotoMutation.isPending && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
              Opslaan
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Upload Photos Dialog */}
      <Dialog
        open={uploadOpen}
        onOpenChange={(o) => { if (!isUploading) { setUploadOpen(o); if (!o) setUploadFiles([]); } }}
      >
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Fotos Uploaden naar {selectedAlbum?.title}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div
              className="border-2 border-dashed border-border rounded-xl p-8 text-center cursor-pointer hover:border-primary/50 transition-colors"
              onClick={() => fileInputRef.current?.click()}
            >
              <Upload className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
              <p className="text-sm font-medium text-foreground">Klik om fotos te selecteren</p>
              <p className="text-xs text-muted-foreground mt-1">JPG, PNG, WEBP - meerdere tegelijk mogelijk</p>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={(e) => setUploadFiles(Array.from(e.target.files ?? []))}
              />
            </div>
            {uploadFiles.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm font-medium text-foreground">
                  {uploadFiles.length} bestand{uploadFiles.length > 1 ? "en" : ""} geselecteerd:
                </p>
                <div className="max-h-40 overflow-y-auto space-y-1">
                  {uploadFiles.map((f, i) => (
                    <div key={i} className="flex items-center justify-between text-sm bg-muted/50 rounded-lg px-3 py-1.5">
                      <span className="truncate text-foreground">{f.name}</span>
                      <button
                        onClick={() => setUploadFiles((prev) => prev.filter((_, j) => j !== i))}
                        className="ml-2 text-muted-foreground hover:text-destructive"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => { setUploadOpen(false); setUploadFiles([]); }}
              disabled={isUploading}
            >
              Annuleren
            </Button>
            <Button onClick={handleUpload} disabled={!uploadFiles.length || isUploading}>
              {isUploading
                ? <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Uploaden...</>
                : <><Upload className="w-4 h-4 mr-2" /> Uploaden</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Album Confirm */}
      <AlertDialog open={deleteAlbumConfirm !== null} onOpenChange={(o) => { if (!o) setDeleteAlbumConfirm(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Album verwijderen?</AlertDialogTitle>
            <AlertDialogDescription>
              Dit verwijdert het album en alle fotos erin. Deze actie kan niet ongedaan worden gemaakt.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuleren</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive hover:bg-destructive/90"
              onClick={() => deleteAlbumConfirm !== null && deleteAlbumMutation.mutate({ id: deleteAlbumConfirm })}
            >
              Verwijderen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Photo Confirm */}
      <AlertDialog open={deletePhotoConfirm !== null} onOpenChange={(o) => { if (!o) setDeletePhotoConfirm(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Foto verwijderen?</AlertDialogTitle>
            <AlertDialogDescription>
              Deze foto wordt permanent verwijderd. Dit kan niet ongedaan worden gemaakt.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuleren</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive hover:bg-destructive/90"
              onClick={() => deletePhotoConfirm !== null && deletePhotoMutation.mutate({ id: deletePhotoConfirm })}
            >
              Verwijderen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </PortaalLayout>
  );
}
