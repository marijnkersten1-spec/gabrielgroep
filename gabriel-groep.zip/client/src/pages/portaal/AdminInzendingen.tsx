import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import { Mail, User, Phone, MapPin, Search, Trash2, Eye } from "lucide-react";
import PortaalLayout from "@/components/PortaalLayout";

export default function AdminInzendingen() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState<"all" | "join" | "contact">("all");
  const [selectedItem, setSelectedItem] = useState<any>(null);

  const { data: joinSubmissions = [] } = trpc.join.list.useQuery();
  const { data: contactSubmissions = [] } = trpc.contact.list.useQuery();

  const joinSubmissionsWithType = (joinSubmissions || []).map((item: any) => ({ ...item, type: "join" as const }));
  const contactSubmissionsWithType = (contactSubmissions || []).map((item: any) => ({ ...item, type: "contact" as const }));

  // Combine and filter submissions
  const allSubmissions = [...joinSubmissionsWithType, ...contactSubmissionsWithType];

  const filteredSubmissions = allSubmissions
    .filter((item) => filterType === "all" || item.type === filterType)
    .filter((item) => {
      const searchLower = searchTerm.toLowerCase();
      if (item.type === "join") {
        return (
          item.childName?.toLowerCase().includes(searchLower) ||
          item.parentName?.toLowerCase().includes(searchLower) ||
          item.parentEmail?.toLowerCase().includes(searchLower)
        );
      } else {
        return (
          item.name?.toLowerCase().includes(searchLower) ||
          item.email?.toLowerCase().includes(searchLower) ||
          item.message?.toLowerCase().includes(searchLower)
        );
      }
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const deleteSubmission = (id: number, type: "join" | "contact") => {
    // Note: Delete functionality would need to be added to the backend
    // For now, we just close the dialog
    setSelectedItem(null);
  };

  return (
    <PortaalLayout>
      <div className="space-y-6">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground mb-2">
            Inzendingen
          </h1>
          <p className="text-muted-foreground">
            Beheer alle aanmeldingen en contactformulieren
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Zoeken op naam, email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={filterType} onValueChange={(v: any) => setFilterType(v)}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="Filter op type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Alle inzendingen</SelectItem>
              <SelectItem value="join">Aanmeldingen</SelectItem>
              <SelectItem value="contact">Contactformulieren</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="border border-border">
            <CardContent className="p-6">
              <div className="text-sm text-muted-foreground mb-1">Totaal inzendingen</div>
              <div className="text-3xl font-bold text-foreground">{allSubmissions.length}</div>
            </CardContent>
          </Card>
          <Card className="border border-border">
            <CardContent className="p-6">
              <div className="text-sm text-muted-foreground mb-1">Aanmeldingen</div>
              <div className="text-3xl font-bold text-foreground">{joinSubmissions.length}</div>
            </CardContent>
          </Card>
          <Card className="border border-border">
            <CardContent className="p-6">
              <div className="text-sm text-muted-foreground mb-1">Contactformulieren</div>
              <div className="text-3xl font-bold text-foreground">{contactSubmissions.length}</div>
            </CardContent>
          </Card>
        </div>

        {/* Submissions List */}
        <div className="space-y-4">
          {filteredSubmissions.length === 0 ? (
            <Card className="border border-border">
              <CardContent className="p-12 text-center">
                <Mail className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="font-display text-lg font-bold text-foreground mb-2">
                  Geen inzendingen gevonden
                </h3>
                <p className="text-muted-foreground">
                  {searchTerm || filterType !== "all"
                    ? "Probeer andere zoektermen of filters"
                    : "Er zijn nog geen inzendingen"}
                </p>
              </CardContent>
            </Card>
          ) : (
            filteredSubmissions.map((item) => (
              <Card key={`${item.type}-${item.id}`} className="border border-border hover:border-primary/50 transition-colors">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <Badge variant={item.type === "join" ? "default" : "secondary"}>
                          {item.type === "join" ? "Aanmelding" : "Contact"}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {format(new Date(item.createdAt), "d MMMM yyyy HH:mm", { locale: nl })}
                        </span>
                      </div>

                      {item.type === "join" ? (
                        <div className="space-y-2">
                          <div>
                            <h3 className="font-display font-bold text-foreground">
                              {item.childName}
                            </h3>
                            <p className="text-sm text-muted-foreground">
                              Kind van {item.parentName}
                            </p>
                          </div>
                                              <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <Mail className="w-4 h-4" />
                              {item.parentEmail}
                            </div>
                            {item.parentPhone && (
                              <div className="flex items-center gap-1">
                                <Phone className="w-4 h-4" />
                                {item.parentPhone}
                              </div>
                            )}
                            {item.speltak && (
                              <div className="flex items-center gap-1">
                                <User className="w-4 h-4" />
                                {item.speltak}
                              </div>
                            )}
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <h3 className="font-display font-bold text-foreground">
                            {item.name}
                          </h3>
                          <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <Mail className="w-4 h-4" />
                              {item.email}
                            </div>
                            {item.subject && (
                              <div className="flex items-center gap-1">
                                <MapPin className="w-4 h-4" />
                                {item.subject}
                              </div>
                            )}
                          </div>
                          {item.message && (
                            <p className="text-sm text-muted-foreground line-clamp-2 mt-2">
                              {item.message}
                            </p>
                          )}
                        </div>
                      )}
                    </div>

                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedItem(item)}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => deleteSubmission(item.id, item.type)}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>

      {/* Detail Dialog */}
      <Dialog open={!!selectedItem} onOpenChange={(open) => !open && setSelectedItem(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {selectedItem?.type === "join" ? "Aanmelding Details" : "Contactformulier Details"}
            </DialogTitle>
          </DialogHeader>

          {selectedItem?.type === "join" ? (
            <div className="space-y-6">
              <div>
                <h3 className="font-display font-bold text-foreground mb-4">Kind</h3>
                <div className="space-y-2 text-sm">
                  <div>
                    <span className="text-muted-foreground">Naam:</span>
                    <p className="font-medium text-foreground">{selectedItem.childName}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Geboortedatum:</span>
                    <p className="font-medium text-foreground">
                      {selectedItem.childBirthDate && format(new Date(selectedItem.childBirthDate), "d MMMM yyyy", { locale: nl })}
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-display font-bold text-foreground mb-4">Ouder/Verzorger</h3>
                <div className="space-y-2 text-sm">
                  <div>
                    <span className="text-muted-foreground">Naam:</span>
                    <p className="font-medium text-foreground">{selectedItem.parentName}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Email:</span>
                    <p className="font-medium text-foreground">{selectedItem.parentEmail}</p>
                  </div>
                  {selectedItem.parentPhone && (
                    <div>
                      <span className="text-muted-foreground">Telefoon:</span>
                      <p className="font-medium text-foreground">{selectedItem.parentPhone}</p>
                    </div>
                  )}
                  {selectedItem.address && (
                    <div>
                      <span className="text-muted-foreground">Adres:</span>
                      <p className="font-medium text-foreground">{selectedItem.address}</p>
                    </div>
                  )}
                </div>
              </div>

              {selectedItem.speltak && (
                <div>
                  <h3 className="font-display font-bold text-foreground mb-4">Voorkeur</h3>
                  <Badge>{selectedItem.speltak}</Badge>
                </div>
              )}

              {selectedItem.message && (
                <div>
                  <h3 className="font-display font-bold text-foreground mb-4">Bericht</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {selectedItem.message}
                  </p>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-6">
              <div>
                <h3 className="font-display font-bold text-foreground mb-4">Contactgegevens</h3>
                <div className="space-y-2 text-sm">
                  <div>
                    <span className="text-muted-foreground">Naam:</span>
                    <p className="font-medium text-foreground">{selectedItem.name}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Email:</span>
                    <p className="font-medium text-foreground">{selectedItem.email}</p>
                  </div>
                </div>
              </div>

              {selectedItem.subject && (
                <div>
                  <h3 className="font-display font-bold text-foreground mb-4">Onderwerp</h3>
                  <p className="text-sm text-muted-foreground">{selectedItem.subject}</p>
                </div>
              )}

              {selectedItem.message && (
                <div>
                  <h3 className="font-display font-bold text-foreground mb-4">Bericht</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-wrap">
                    {selectedItem.message}
                  </p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </PortaalLayout>
  );
}
