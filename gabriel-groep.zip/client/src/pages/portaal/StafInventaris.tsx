import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Plus, Wrench, Search } from "lucide-react";
import { EQUIPMENT_CATEGORY_LABELS, EQUIPMENT_STATUS_LABELS } from "@/lib/constants";

const statusColors: Record<string, string> = {
  available: "bg-green-100 text-green-700 border-green-200",
  in_use: "bg-blue-100 text-blue-700 border-blue-200",
  maintenance: "bg-orange-100 text-orange-700 border-orange-200",
  retired: "bg-gray-100 text-gray-600 border-gray-200",
};

export default function StafInventaris() {
  const [search, setSearch] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [editingItem, setEditingItem] = useState<any | null>(null);
  const [form, setForm] = useState({
    name: "", category: "other" as any, description: "", serialNumber: "",
    status: "available" as any, location: "", notes: "",
  });

  const { data: equipment, isLoading, refetch } = trpc.equipment.list.useQuery();

  const createMutation = trpc.equipment.create.useMutation({
    onSuccess: () => { toast.success("Item aangemaakt"); refetch(); setShowCreate(false); },
    onError: (err: any) => toast.error(err.message),
  });

  const updateMutation = trpc.equipment.update.useMutation({
    onSuccess: () => { toast.success("Item bijgewerkt"); refetch(); setEditingItem(null); },
    onError: (err: any) => toast.error(err.message),
  });

  const filtered = equipment?.filter((e) =>
    e.name.toLowerCase().includes(search.toLowerCase()) ||
    (e.serialNumber ?? "").toLowerCase().includes(search.toLowerCase())
  ) ?? [];

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground mb-1">Inventaris</h1>
          <p className="text-muted-foreground">{equipment?.length ?? 0} items in inventaris</p>
        </div>
        <Button onClick={() => setShowCreate(true)}>
          <Plus className="w-4 h-4 mr-2" /> Nieuw Item
        </Button>
      </div>

      {/* Status summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {Object.entries(EQUIPMENT_STATUS_LABELS).map(([status, label]) => {
          const count = equipment?.filter((e) => e.status === status).length ?? 0;
          return (
            <div key={status} className={`p-3 rounded-xl border ${statusColors[status]} text-center`}>
              <div className="font-bold text-xl">{count}</div>
              <div className="text-xs">{label}</div>
            </div>
          );
        })}
      </div>

      {/* Search */}
      <div className="relative mb-5">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Zoek op naam of serienummer..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 rounded-xl bg-muted animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <Wrench className="w-10 h-10 mx-auto mb-3 opacity-40" />
          <p>Geen items gevonden</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((item) => (
            <Card key={item.id} className="border border-border hover:shadow-sm transition-shadow cursor-pointer"
              onClick={() => setEditingItem(item)}>
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center shrink-0">
                    <Wrench className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="font-medium text-foreground text-sm">{item.name}</span>
                      <Badge variant="outline" className="text-xs">
                        {EQUIPMENT_CATEGORY_LABELS[item.category] ?? item.category}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      {item.serialNumber && <span>S/N: {item.serialNumber}</span>}
                      {item.location && <span>📍 {item.location}</span>}
                    </div>
                  </div>
                  <span className={`text-xs px-2.5 py-1 rounded-full border font-medium ${statusColors[item.status]}`}>
                    {EQUIPMENT_STATUS_LABELS[item.status]}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Create Dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Nieuw Inventarisitem</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Naam *</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="mt-1.5" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Categorie</Label>
                <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                  <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(EQUIPMENT_CATEGORY_LABELS).map(([k, v]) => (
                      <SelectItem key={k} value={k}>{v}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Status</Label>
                <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                  <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(EQUIPMENT_STATUS_LABELS).map(([k, v]) => (
                      <SelectItem key={k} value={k}>{v}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label>Serienummer</Label>
              <Input value={form.serialNumber} onChange={(e) => setForm({ ...form, serialNumber: e.target.value })} className="mt-1.5" />
            </div>
            <div>
              <Label>Locatie</Label>
              <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} className="mt-1.5" />
            </div>
            <div>
              <Label>Notities</Label>
              <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="mt-1.5 resize-none" rows={3} />
            </div>
            <div className="flex gap-3 pt-2">
              <Button variant="outline" className="flex-1" onClick={() => setShowCreate(false)}>Annuleren</Button>
              <Button className="flex-1" onClick={() => createMutation.mutate(form)} disabled={createMutation.isPending}>
                Aanmaken
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={!!editingItem} onOpenChange={() => setEditingItem(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Item Bewerken</DialogTitle></DialogHeader>
          {editingItem && (
            <div className="space-y-4">
              <div>
                <Label>Status</Label>
                <Select
                  defaultValue={editingItem.status}
                  onValueChange={(v) => setEditingItem({ ...editingItem, status: v })}
                >
                  <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(EQUIPMENT_STATUS_LABELS).map(([k, v]) => (
                      <SelectItem key={k} value={k}>{v}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Notities</Label>
                <Textarea
                  defaultValue={editingItem.notes ?? ""}
                  onChange={(e) => setEditingItem({ ...editingItem, notes: e.target.value })}
                  className="mt-1.5 resize-none"
                  rows={3}
                />
              </div>
              <div className="flex gap-3 pt-2">
                <Button variant="outline" className="flex-1" onClick={() => setEditingItem(null)}>Annuleren</Button>
                <Button
                  className="flex-1"
                  disabled={updateMutation.isPending}
                  onClick={() => updateMutation.mutate({ id: editingItem.id, status: editingItem.status, notes: editingItem.notes })}
                >
                  Opslaan
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
