import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import { Calendar, FileText, Newspaper, ArrowRight, MapPin, CheckCircle2 } from "lucide-react";
import { SPELTAK_LABELS, SPELTAK_AGES } from "@/lib/constants";
import SpeltakBadge from "@/components/SpeltakBadge";

export default function PortaalDashboard() {
  const { user } = useAuth();
  const { data: events } = trpc.events.list.useQuery({ speltak: user?.speltak ?? undefined });
  const { data: news } = trpc.news.listAll.useQuery();
  const { data: myRegistrations } = trpc.events.myRegistrations.useQuery();

  const upcomingEvents = events?.filter((e) => new Date(e.startDate) >= new Date()).slice(0, 3) ?? [];
  const recentNews = news?.slice(0, 3) ?? [];
  const registeredEventIds = new Set(myRegistrations?.filter((r) => r.status === "registered").map((r) => r.eventId));

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Welcome */}
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold text-foreground mb-1">
          Welkom, {user?.name?.split(" ")[0] ?? "Scout"}!
        </h1>
        <div className="flex items-center gap-3">
          <p className="text-muted-foreground">
            {format(new Date(), "EEEE d MMMM yyyy", { locale: nl })}
          </p>
          {user?.speltak && (
            <SpeltakBadge speltak={user.speltak} />
          )}
        </div>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: "Aankomende activiteiten", value: upcomingEvents.length, icon: Calendar, color: "text-blue-600 bg-blue-50" },
          { label: "Ingeschreven", value: registeredEventIds.size, icon: CheckCircle2, color: "text-green-600 bg-green-50" },
          { label: "Nieuwsberichten", value: recentNews.length, icon: Newspaper, color: "text-purple-600 bg-purple-50" },
          { label: "Speltak", value: user?.speltak ? SPELTAK_LABELS[user.speltak] : "–", icon: FileText, color: "text-orange-600 bg-orange-50" },
        ].map((stat) => (
          <Card key={stat.label} className="border border-border">
            <CardContent className="p-4">
              <div className={`w-9 h-9 rounded-xl ${stat.color} flex items-center justify-center mb-3`}>
                <stat.icon className="w-4.5 h-4.5" />
              </div>
              <div className="font-display text-2xl font-bold text-foreground">{stat.value}</div>
              <div className="text-muted-foreground text-xs mt-0.5">{stat.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Events */}
        <Card className="border border-border">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="font-display text-lg">Aankomende Activiteiten</CardTitle>
              <Link href="/portaal/agenda">
                <Button variant="ghost" size="sm" className="text-primary">
                  Alle <ArrowRight className="w-3 h-3 ml-1" />
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {upcomingEvents.length === 0 ? (
              <p className="text-muted-foreground text-sm text-center py-6">Geen aankomende activiteiten</p>
            ) : (
              upcomingEvents.map((event) => (
                <div key={event.id} className="flex items-start gap-3 p-3 rounded-lg bg-muted/40 hover:bg-muted/70 transition-colors">
                  <div className="w-11 h-11 rounded-xl bg-primary/10 flex flex-col items-center justify-center shrink-0">
                    <span className="text-primary font-bold text-sm leading-none">
                      {format(new Date(event.startDate), "d")}
                    </span>
                    <span className="text-primary/70 text-xs uppercase">
                      {format(new Date(event.startDate), "MMM", { locale: nl })}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="font-medium text-sm text-foreground truncate">{event.title}</span>
                      {registeredEventIds.has(event.id) && (
                        <CheckCircle2 className="w-3.5 h-3.5 text-green-500 shrink-0" />
                      )}
                    </div>
                    {event.location && (
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <MapPin className="w-3 h-3" /> {event.location}
                      </div>
                    )}
                  </div>
                  <SpeltakBadge speltak={event.speltak} size="sm" />
                </div>
              ))
            )}
          </CardContent>
        </Card>

        {/* Latest News */}
        <Card className="border border-border">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="font-display text-lg">Nieuws</CardTitle>
              <Link href="/portaal/nieuws">
                <Button variant="ghost" size="sm" className="text-primary">
                  Alle <ArrowRight className="w-3 h-3 ml-1" />
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {recentNews.length === 0 ? (
              <p className="text-muted-foreground text-sm text-center py-6">Geen nieuws beschikbaar</p>
            ) : (
              recentNews.map((item) => (
                <div key={item.id} className="p-3 rounded-lg bg-muted/40 hover:bg-muted/70 transition-colors">
                  <div className="flex items-center gap-2 mb-1">
                    {item.speltak && item.speltak !== "all" && (
                      <SpeltakBadge speltak={item.speltak} size="sm" />
                    )}
                    <span className="text-xs text-muted-foreground">
                      {item.publishedAt ? format(new Date(item.publishedAt), "d MMM", { locale: nl }) : ""}
                    </span>
                  </div>
                  <h4 className="font-medium text-sm text-foreground line-clamp-2">{item.title}</h4>
                  {item.excerpt && (
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-1">{item.excerpt}</p>
                  )}
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      {/* Speltak info */}
      {user?.speltak && (
        <Card className="mt-6 border border-border">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="text-4xl">
                {user.speltak === "dolfijnen" ? "🐬" : user.speltak === "verkenners" ? "🧭" : user.speltak === "wilde_vaart" ? "⚓" : "⚓"}
              </div>
              <div>
                <h3 className="font-display text-xl font-bold text-foreground">
                  {SPELTAK_LABELS[user.speltak]}
                </h3>
                <p className="text-muted-foreground text-sm">{SPELTAK_AGES[user.speltak]}</p>
              </div>
              <div className="ml-auto">
                <Link href="/portaal/agenda">
                  <Button variant="outline" size="sm">
                    Agenda bekijken
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
