import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import { Users, Newspaper, Calendar, Settings, ArrowRight, ShieldCheck, Database, Image as ImageIcon } from "lucide-react";

export default function AdminDashboard() {
  const { data: members } = trpc.members.list.useQuery();
  const { data: events } = trpc.events.list.useQuery({});
  const { data: news } = trpc.news.listAll.useQuery();
  const { data: albums = [] } = trpc.photos.listAllAlbums.useQuery();

  const stats = [
    { label: "Totaal Leden", value: members?.length ?? 0, icon: Users, href: "/portaal/admin/gebruikers", color: "text-blue-600 bg-blue-50" },
    { label: "Activiteiten", value: events?.length ?? 0, icon: Calendar, href: "/portaal/staf/activiteiten", color: "text-green-600 bg-green-50" },
    { label: "Nieuwsberichten", value: news?.length ?? 0, icon: Newspaper, href: "/portaal/admin/nieuws", color: "text-purple-600 bg-purple-50" },
    { label: "Fotogalerijen", value: albums.length, icon: ImageIcon, href: "/portaal/admin/fotos", color: "text-orange-600 bg-orange-50" },
  ];

  const roleBreakdown = [
    { role: "admin", label: "Admin", count: members?.filter((m) => m.role === "admin").length ?? 0 },
    { role: "staff", label: "Staf", count: members?.filter((m) => m.role === "staff").length ?? 0 },
    { role: "user", label: "Lid", count: members?.filter((m) => m.role === "user").length ?? 0 },
  ];

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5 text-red-600" />
          </div>
          <div>
            <h1 className="font-display text-3xl font-bold text-foreground">Admin Panel</h1>
            <p className="text-muted-foreground text-sm">{format(new Date(), "EEEE d MMMM yyyy", { locale: nl })}</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {stats.map((stat) => (
          <Link key={stat.label} href={stat.href}>
            <Card className="border border-border hover:shadow-sm transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <div className={`w-9 h-9 rounded-xl ${stat.color} flex items-center justify-center mb-3`}>
                  <stat.icon className="w-4.5 h-4.5" />
                </div>
                <div className="font-display text-2xl font-bold text-foreground">{stat.value}</div>
                <div className="text-muted-foreground text-xs mt-0.5">{stat.label}</div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Role breakdown */}
        <Card className="border border-border">
          <CardHeader className="pb-3">
            <CardTitle className="font-display text-lg">Gebruikersrollen</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {roleBreakdown.map((r) => (
              <div key={r.role} className="flex items-center gap-3">
                <span className="text-sm text-muted-foreground w-12">{r.label}</span>
                <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary rounded-full"
                    style={{ width: (members?.length ?? 0) > 0 ? `${(r.count / (members?.length ?? 1)) * 100}%` : "0%" }}
                  />
                </div>
                <span className="text-sm font-medium text-foreground w-6 text-right">{r.count}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Quick actions */}
        <Card className="border border-border">
          <CardHeader className="pb-3">
            <CardTitle className="font-display text-lg">Snelle Acties</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {[
              { href: "/portaal/admin/nieuws", label: "Nieuwsbericht Publiceren", icon: Newspaper },
              { href: "/portaal/admin/gebruikers", label: "Gebruikers Beheren", icon: Users },
              { href: "/portaal/admin/fotos", label: "Fotogalerijen Beheren", icon: ImageIcon },
              { href: "/portaal/staf/activiteiten", label: "Activiteit Aanmaken", icon: Calendar },
            ].map((action) => (
              <Link key={action.href} href={action.href}>
                <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/60 transition-colors cursor-pointer">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                    <action.icon className="w-4 h-4 text-primary" />
                  </div>
                  <span className="text-sm font-medium text-foreground flex-1">{action.label}</span>
                  <ArrowRight className="w-4 h-4 text-muted-foreground" />
                </div>
              </Link>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
