import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isToday, addMonths, subMonths, startOfWeek, endOfWeek, isWithinInterval, startOfDay, endOfDay } from "date-fns";
import { nl } from "date-fns/locale";
import { ChevronLeft, ChevronRight, MapPin, Users, CheckCircle2, Clock, Info } from "lucide-react";
import SpeltakBadge from "@/components/SpeltakBadge";
import { EVENT_TYPE_LABELS } from "@/lib/constants";
import { toast } from "sonner";

export default function PortaalAgenda() {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<any | null>(null);
  const { user } = useAuth();

  const { data: events, refetch } = trpc.events.list.useQuery({
    speltak: user?.speltak ?? undefined,
  });

  const { data: myRegistrations, refetch: refetchRegs } = trpc.events.myRegistrations.useQuery();

  const registerMutation = trpc.events.register.useMutation({
    onSuccess: () => { toast.success("Ingeschreven!"); refetch(); refetchRegs(); },
     onError: (err: any) => toast.error(err.message),
  });
  const unregisterMutation = trpc.events.cancelRegistration.useMutation({
    onSuccess: () => { toast.success("Uitgeschreven"); refetch(); refetchRegs(); },
    onError: (err: any) => toast.error(err.message),
  });

  const registeredEventIds = new Set(myRegistrations?.filter((r) => r.status === "registered").map((r) => r.eventId));

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const calStart = startOfWeek(monthStart, { weekStartsOn: 1 });
  const calEnd = endOfWeek(monthEnd, { weekStartsOn: 1 });
  const days = eachDayOfInterval({ start: calStart, end: calEnd });

  const eventCoversDay = (event: any, day: Date): boolean => {
    const eventStart = startOfDay(new Date(event.startDate));
    const eventEnd = event.endDate ? endOfDay(new Date(event.endDate)) : endOfDay(new Date(event.startDate));
    const checkDay = startOfDay(day);
    return isWithinInterval(checkDay, { start: eventStart, end: eventEnd });
  };

  const getEventsForDay = (day: Date) =>
    (events ?? []).filter((e) => eventCoversDay(e, day));

  const selectedDayEvents = selectedDate
    ? (events ?? []).filter((e) => eventCoversDay(e, selectedDate))
    : (events ?? []).filter((e) => new Date(e.startDate) >= new Date()).slice(0, 10);

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="mb-6">
        <h1 className="font-display text-3xl font-bold text-foreground mb-1">Agenda</h1>
        <p className="text-muted-foreground">Activiteiten en evenementen voor jouw speltak</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar */}
        <div className="lg:col-span-2">
          <Card className="border border-border">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-5">
                <Button variant="ghost" size="icon" onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}>
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <h2 className="font-display text-xl font-bold text-foreground capitalize">
                  {format(currentMonth, "MMMM yyyy", { locale: nl })}
                </h2>
                <Button variant="ghost" size="icon" onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}>
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>

              <div className="grid grid-cols-7 mb-2">
                {["Ma", "Di", "Wo", "Do", "Vr", "Za", "Zo"].map((d) => (
                  <div key={d} className="text-center text-xs font-semibold text-muted-foreground py-2">{d}</div>
                ))}
              </div>

              <div className="grid grid-cols-7 gap-1">
                {days.map((day) => {
                  const dayEvents = getEventsForDay(day);
                  const isCurrentMonth = day.getMonth() === currentMonth.getMonth();
                  const isSelected = selectedDate && isSameDay(day, selectedDate);
                  const today = isToday(day);

                  return (
                    <button
                      key={day.toISOString()}
                      onClick={() => setSelectedDate(isSelected ? null : day)}
                      className={`relative p-1.5 rounded-lg text-center transition-all min-h-[52px] ${
                        !isCurrentMonth ? "opacity-30" : ""
                      } ${
                        isSelected ? "bg-primary text-primary-foreground"
                          : today ? "bg-accent/20" : "hover:bg-muted"
                      }`}
                    >
                      <span className={`text-sm font-medium block ${today && !isSelected ? "text-primary font-bold" : ""}`}>
                        {format(day, "d")}
                      </span>
                      {dayEvents.length > 0 && (
                        <div className="flex justify-center gap-0.5 mt-1 flex-wrap">
                          {dayEvents.slice(0, 3).map((e, i) => (
                            <div key={i} className={`w-1.5 h-1.5 rounded-full ${isSelected ? "bg-white/70" : "bg-primary"}`} />
                          ))}
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Event list */}
        <div>
          <h3 className="font-display text-lg font-bold text-foreground mb-4">
            {selectedDate ? format(selectedDate, "d MMMM", { locale: nl }) : "Aankomende activiteiten"}
          </h3>

          {selectedDayEvents.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground">
              <p className="text-sm">Geen activiteiten</p>
            </div>
          ) : (
            <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
              {selectedDayEvents.map((event) => {
                const isRegistered = registeredEventIds.has(event.id);
                return (
                  <Card key={event.id} className="border border-border cursor-pointer hover:shadow-sm transition-shadow"
                    onClick={() => setSelectedEvent(event)}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-semibold text-sm text-foreground flex-1 mr-2">{event.title}</h4>
                        {isRegistered && <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0" />}
                      </div>
                      <p className="text-xs text-muted-foreground mb-2">
                        {format(new Date(event.startDate), "d MMM · HH:mm", { locale: nl })}
                      </p>
                      <div className="flex items-center gap-2">
                        <SpeltakBadge speltak={event.speltak} size="sm" />
                        <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">
                          {EVENT_TYPE_LABELS[event.type] ?? event.type}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Event detail dialog */}
      <Dialog open={!!selectedEvent} onOpenChange={() => setSelectedEvent(null)}>
        <DialogContent className="max-w-lg">
          {selectedEvent && (
            <>
              <DialogHeader>
                <DialogTitle className="font-display text-xl">{selectedEvent.title}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  <SpeltakBadge speltak={selectedEvent.speltak} />
                  <Badge variant="outline">{EVENT_TYPE_LABELS[selectedEvent.type] ?? selectedEvent.type}</Badge>
                </div>

                <div className="space-y-2.5">
                  <div className="flex items-center gap-2.5 text-sm text-muted-foreground">
                    <Clock className="w-4 h-4 text-primary" />
                    {format(new Date(selectedEvent.startDate), "EEEE d MMMM yyyy · HH:mm", { locale: nl })}
                    {selectedEvent.endDate && ` – ${format(new Date(selectedEvent.endDate), "HH:mm", { locale: nl })}`}
                  </div>
                  {selectedEvent.location && (
                    <div className="flex items-center gap-2.5 text-sm text-muted-foreground">
                      <MapPin className="w-4 h-4 text-primary" />
                      {selectedEvent.location}
                    </div>
                  )}
                  {selectedEvent.maxParticipants && (
                    <div className="flex items-center gap-2.5 text-sm text-muted-foreground">
                      <Users className="w-4 h-4 text-primary" />
                      Max. {selectedEvent.maxParticipants} deelnemers
                    </div>
                  )}
                </div>

                {selectedEvent.description && (
                  <p className="text-sm text-muted-foreground leading-relaxed">{selectedEvent.description}</p>
                )}

                {selectedEvent.registrationRequired && (
                  <div className="pt-2">
                    {registeredEventIds.has(selectedEvent.id) ? (
                      <div className="space-y-3">
                        <div className="flex items-center gap-2 text-green-600 text-sm font-medium">
                          <CheckCircle2 className="w-4 h-4" /> Je bent ingeschreven
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => unregisterMutation.mutate({ eventId: selectedEvent.id })}
                          disabled={unregisterMutation.isPending}
                        >
                          Uitschrijven
                        </Button>
                      </div>
                    ) : (
                      <Button
                        onClick={() => registerMutation.mutate({ eventId: selectedEvent.id })}
                        disabled={registerMutation.isPending}
                        className="w-full"
                      >
                        Inschrijven voor deze activiteit
                      </Button>
                    )}
                  </div>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
