import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Switch } from "@/components/ui/switch";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import { Plus, Calendar, MapPin, Edit, Trash2, Users, Loader2, Building2 } from "lucide-react";
import PortaalLayout from "@/components/PortaalLayout";

const emptyForm = {
  title: "",
  description: "",
  location: "",
  startDate: "",
  endDate: "",
  isPublic: true,
  maxParticipants: "",
};

type FormState = typeof emptyForm;

// EventCard is defined OUTSIDE the parent component to avoid remounting on every render
function EventCard({ event, dimmed = false, onEdit, onDelete }: {
  event: any;
  dimmed?: boolean;
  onEdit?: (event: any) => void;
  onDelete?: (id: number) => void;
}) {
  return (
    <Card className={`border border-border transition-all ${dimmed ? "opacity-60" : "hover:border-primary/30"}`}>
      <CardContent className="p-4">
        <div className="flex items-center gap-4">
          {/* Date block */}
          <div className={`w-14 h-14 rounded-xl flex flex-col items-center justify-center shrink-0 ${dimmed ? "bg-muted" : "bg-primary/10"}`}>
            <span className={`font-bold text-base leading-none ${dimmed ? "text-muted-foreground" : "text-primary"}`}>
              {format(new Date(event.startDate), "d")}
            </span>
            <span className={`text-xs uppercase mt-0.5 ${dimmed ? "text-muted-foreground" : "text-primary/70"}`}>
              {format(new Date(event.startDate), "MMM", { locale: nl })}
            </span>
          </div>

          {/* Details */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="font-semibold text-foreground text-sm">{event.title}</span>
              <Badge variant="outline" className="text-xs">Verhuur</Badge>
              {!event.isPublic && (
                <Badge variant="secondary" className="text-xs">Prive</Badge>
              )}
            </div>
            <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
              <span className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                {format(new Date(event.startDate), "HH:mm")}
                {event.endDate && ` – ${format(new Date(event.endDate), "d MMM HH:mm", { locale: nl })}`}
              </span>
              {event.location && (
                <span className="flex items-center gap-1">
                  <MapPin className="w-3 h-3" /> {event.location}
                </span>
              )}
              {event.maxParticipants && (
                <span className="flex items-center gap-1">
                  <Users className="w-3 h-3" /> Max {event.maxParticipants}
                </span>
              )}
            </div>
            {event.description && (
              <p className="text-xs text-muted-foreground mt-1 line-clamp-1">{event.description}</p>
            )}
          </div>

          {/* Actions */}
          {!dimmed && onEdit && onDelete && (
            <div className="flex gap-1.5 shrink-0">
              <Button
                variant="ghost" size="icon" className="h-8 w-8"
                onClick={() => onEdit(event)}
                title="Bewerken"
              >
                <Edit className="w-3.5 h-3.5" />
              </Button>
              <Button
                variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive"
                onClick={() => onDelete(event.id)}
                title="Verwijderen"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// Inline form fields component defined OUTSIDE parent to prevent remounting
function VerhuurFormFields({ form, setForm }: { form: FormState; setForm: (f: FormState) => void }) {
  return (
    <div className="space-y-4">
      <div>
        <Label>Titel *</Label>
        <Input
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          placeholder="bijv. Vergadering buurtvereniging"
          className="mt-1.5"
        />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Startdatum & tijd *</Label>
          <Input
            type="datetime-local"
            value={form.startDate}
            onChange={(e) => setForm({ ...form, startDate: e.target.value })}
            className="mt-1.5"
          />
        </div>
        <div>
          <Label>Einddatum & tijd</Label>
          <Input
            type="datetime-local"
            value={form.endDate}
            onChange={(e) => setForm({ ...form, endDate: e.target.value })}
            className="mt-1.5"
          />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Locatie / Ruimte</Label>
          <Input
            value={form.location}
            onChange={(e) => setForm({ ...form, location: e.target.value })}
            placeholder="bijv. Ruimte 1"
            className="mt-1.5"
          />
        </div>
        <div>
          <Label>Max. personen</Label>
          <Input
            type="number"
            value={form.maxParticipants}
            onChange={(e) => setForm({ ...form, maxParticipants: e.target.value })}
            placeholder="bijv. 50"
            className="mt-1.5"
          />
        </div>
      </div>
      <div>
        <Label>Beschrijving</Label>
        <Textarea
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          placeholder="Optionele beschrijving van het verhuur event..."
          className="mt-1.5 resize-none"
          rows={3}
        />
      </div>
      <div className="flex items-center gap-3">
        <Switch
          checked={form.isPublic}
          onCheckedChange={(v) => setForm({ ...form, isPublic: v })}
        />
        <Label className="cursor-pointer">
          {form.isPublic ? "Publiek zichtbaar op verhuurpagina" : "Alleen intern zichtbaar"}
        </Label>
      </div>
    </div>
  );
}

export default function AdminVerhuurAgenda() {
  const utils = trpc.useUtils();

  const [showCreate, setShowCreate] = useState(false);
  const [editingEvent, setEditingEvent] = useState<any | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);

  // Fetch only rental events
  const { data: allEvents = [], isLoading } = trpc.events.list.useQuery({ type: "rental" });

  const createMutation = trpc.events.create.useMutation({
    onSuccess: () => {
      utils.events.list.invalidate();
      setShowCreate(false);
      setForm(emptyForm);
      toast.success("Verhuur event aangemaakt!");
    },
    onError: (err: any) => toast.error("Fout: " + err.message),
  });

  const updateMutation = trpc.events.update.useMutation({
    onSuccess: () => {
      utils.events.list.invalidate();
      setEditingEvent(null);
      toast.success("Verhuur event bijgewerkt!");
    },
    onError: (err: any) => toast.error("Fout: " + err.message),
  });

  const deleteMutation = trpc.events.delete.useMutation({
    onSuccess: () => {
      utils.events.list.invalidate();
      setDeleteConfirm(null);
      toast.success("Verhuur event verwijderd!");
    },
    onError: (err: any) => toast.error("Fout: " + err.message),
  });

  const handleCreate = () => {
    if (!form.title.trim() || !form.startDate) {
      toast.error("Vul de verplichte velden in (titel en startdatum)");
      return;
    }
    createMutation.mutate({
      title: form.title,
      description: form.description || undefined,
      location: form.location || undefined,
      startDate: new Date(form.startDate),
      endDate: form.endDate ? new Date(form.endDate) : undefined,
      speltak: "all",
      type: "rental",
      isPublic: form.isPublic,
      maxParticipants: form.maxParticipants ? parseInt(form.maxParticipants) : undefined,
    });
  };

  const openEdit = (event: any) => {
    setEditingEvent(event);
    setForm({
      title: event.title,
      description: event.description ?? "",
      location: event.location ?? "",
      startDate: format(new Date(event.startDate), "yyyy-MM-dd'T'HH:mm"),
      endDate: event.endDate ? format(new Date(event.endDate), "yyyy-MM-dd'T'HH:mm") : "",
      isPublic: event.isPublic,
      maxParticipants: event.maxParticipants?.toString() ?? "",
    });
  };

  const handleUpdate = () => {
    if (!form.title.trim() || !form.startDate || !editingEvent) return;
    updateMutation.mutate({
      id: editingEvent.id,
      title: form.title,
      description: form.description || undefined,
      location: form.location || undefined,
      startDate: new Date(form.startDate),
      endDate: form.endDate ? new Date(form.endDate) : undefined,
      isPublic: form.isPublic,
      maxParticipants: form.maxParticipants ? parseInt(form.maxParticipants) : undefined,
    });
  };

  const upcoming = allEvents.filter((e) => new Date(e.startDate) >= new Date());
  const past = allEvents.filter((e) => new Date(e.startDate) < new Date());

  return (
    <PortaalLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            <h1 className="font-display text-3xl font-bold text-foreground flex items-center gap-3">
              <Building2 className="w-8 h-8 text-primary" />
              Verhuur Agenda
            </h1>
            <p className="text-muted-foreground mt-0.5">
              Beheer alle verhuur reserveringen en events — {allEvents.length} totaal
            </p>
          </div>
          <Button onClick={() => { setForm(emptyForm); setShowCreate(true); }}>
            <Plus className="w-4 h-4 mr-2" /> Nieuw Verhuur Event
          </Button>
        </div>

        {/* Stats bar */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          <Card className="border border-border">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">{upcoming.length}</div>
              <div className="text-xs text-muted-foreground mt-0.5">Aankomend</div>
            </CardContent>
          </Card>
          <Card className="border border-border">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-foreground">{past.length}</div>
              <div className="text-xs text-muted-foreground mt-0.5">Verleden</div>
            </CardContent>
          </Card>
          <Card className="border border-border col-span-2 sm:col-span-1">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-foreground">{allEvents.length}</div>
              <div className="text-xs text-muted-foreground mt-0.5">Totaal</div>
            </CardContent>
          </Card>
        </div>

        {/* Loading */}
        {isLoading && (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
          </div>
        )}

        {/* Upcoming */}
        {!isLoading && (
          <div>
            <h2 className="font-display text-lg font-bold text-foreground mb-3">
              Aankomend ({upcoming.length})
            </h2>
            {upcoming.length === 0 ? (
              <Card className="border border-dashed border-border">
                <CardContent className="p-10 text-center">
                  <Building2 className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground font-medium">Geen aankomende verhuur events</p>
                  <p className="text-muted-foreground text-sm mt-1">Maak een nieuw verhuur event aan via de knop hierboven.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-2">
                {upcoming.map((event) => (
                  <EventCard
                    key={event.id}
                    event={event}
                    onEdit={openEdit}
                    onDelete={setDeleteConfirm}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Past */}
        {!isLoading && past.length > 0 && (
          <div>
            <h2 className="font-display text-lg font-bold text-muted-foreground mb-3">
              Verleden ({past.length})
            </h2>
            <div className="space-y-2">
              {past.slice(0, 10).map((event) => (
                <EventCard key={event.id} event={event} dimmed />
              ))}
              {past.length > 10 && (
                <p className="text-xs text-muted-foreground text-center py-2">
                  + {past.length - 10} oudere events
                </p>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Create Dialog */}
      <Dialog open={showCreate} onOpenChange={(o) => { if (!o) setShowCreate(false); }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Nieuw Verhuur Event</DialogTitle>
          </DialogHeader>
          <VerhuurFormFields form={form} setForm={setForm} />
          <DialogFooter className="mt-2">
            <Button variant="outline" onClick={() => setShowCreate(false)}>Annuleren</Button>
            <Button onClick={handleCreate} disabled={createMutation.isPending}>
              {createMutation.isPending && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
              Aanmaken
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={!!editingEvent} onOpenChange={(o) => { if (!o) setEditingEvent(null); }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Verhuur Event Bewerken</DialogTitle>
          </DialogHeader>
          <VerhuurFormFields form={form} setForm={setForm} />
          <DialogFooter className="mt-2">
            <Button variant="outline" onClick={() => setEditingEvent(null)}>Annuleren</Button>
            <Button onClick={handleUpdate} disabled={updateMutation.isPending}>
              {updateMutation.isPending && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
              Opslaan
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <AlertDialog open={deleteConfirm !== null} onOpenChange={(o) => { if (!o) setDeleteConfirm(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Verhuur event verwijderen?</AlertDialogTitle>
            <AlertDialogDescription>
              Dit event wordt permanent verwijderd. Dit kan niet ongedaan worden gemaakt.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuleren</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive hover:bg-destructive/90"
              onClick={() => deleteConfirm !== null && deleteMutation.mutate({ id: deleteConfirm })}
            >
              Verwijderen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </PortaalLayout>
  );
}
