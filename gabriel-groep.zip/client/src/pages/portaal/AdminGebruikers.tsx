import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import { Search, Users, Edit, ShieldCheck } from "lucide-react";
import SpeltakBadge from "@/components/SpeltakBadge";
import { SPELTAK_LABELS } from "@/lib/constants";

export default function AdminGebruikers() {
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [editingUser, setEditingUser] = useState<any | null>(null);

  const { data: members, isLoading, refetch } = trpc.members.list.useQuery();

  const updateMutation = trpc.members.update.useMutation({
    onSuccess: () => { toast.success("Gebruiker bijgewerkt"); refetch(); setEditingUser(null); },
    onError: (err: any) => toast.error(err.message),
  });

  const filtered = members?.filter((m) => {
    const matchSearch = (m.name ?? "").toLowerCase().includes(search.toLowerCase()) ||
      (m.email ?? "").toLowerCase().includes(search.toLowerCase());
    const matchRole = roleFilter === "all" || m.role === roleFilter;
    return matchSearch && matchRole;
  }) ?? [];

  const roleBadge = (role: string) => {
    if (role === "admin") return <Badge className="bg-red-100 text-red-700 border-red-200 text-xs">Admin</Badge>;
    if (role === "staff") return <Badge className="bg-blue-100 text-blue-700 border-blue-200 text-xs">Staf</Badge>;
    return <Badge variant="outline" className="text-xs">Lid</Badge>;
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="mb-6">
        <h1 className="font-display text-3xl font-bold text-foreground mb-1">Gebruikersbeheer</h1>
        <p className="text-muted-foreground">{members?.length ?? 0} geregistreerde gebruikers</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Zoek op naam of e-mail..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex gap-2">
          {["all", "admin", "staff", "user"].map((r) => (
            <Button
              key={r}
              variant={roleFilter === r ? "default" : "outline"}
              size="sm"
              onClick={() => setRoleFilter(r)}
            >
              {r === "all" ? "Alle" : r === "admin" ? "Admin" : r === "staff" ? "Staf" : "Leden"}
            </Button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 rounded-xl bg-muted animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <Users className="w-10 h-10 mx-auto mb-3 opacity-40" />
          <p>Geen gebruikers gevonden</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((user) => (
            <Card key={user.id} className="border border-border hover:shadow-sm transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <Avatar className="w-10 h-10">
                    <AvatarFallback className="bg-primary/10 text-primary font-semibold text-sm">
                      {(user.name ?? "?").charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                      <span className="font-medium text-foreground text-sm">{user.name ?? "Onbekend"}</span>
                      {roleBadge(user.role)}
                      {user.speltak && <SpeltakBadge speltak={user.speltak} size="sm" />}
                    </div>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      {user.email && <span>{user.email}</span>}
                      <span>Lid sinds {format(new Date(user.createdAt), "d MMM yyyy", { locale: nl })}</span>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => setEditingUser(user)}>
                    <Edit className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Edit Dialog */}
      <Dialog open={!!editingUser} onOpenChange={() => setEditingUser(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-primary" />
              Gebruiker Bewerken
            </DialogTitle>
          </DialogHeader>
          {editingUser && (
            <div className="space-y-4">
              <div className="p-3 bg-muted/50 rounded-lg">
                <div className="font-medium text-sm">{editingUser.name}</div>
                <div className="text-xs text-muted-foreground">{editingUser.email}</div>
              </div>
              <div>
                <Label>Rol</Label>
                <Select
                  defaultValue={editingUser.role}
                  onValueChange={(v) => setEditingUser({ ...editingUser, role: v })}
                >
                  <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="user">Lid</SelectItem>
                    <SelectItem value="staff">Staf</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Speltak</Label>
                <Select
                  defaultValue={editingUser.speltak ?? ""}
                  onValueChange={(v) => setEditingUser({ ...editingUser, speltak: v || null })}
                >
                  <SelectTrigger className="mt-1.5"><SelectValue placeholder="Geen speltak" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dolfijnen">Dolfijnen</SelectItem>
                    <SelectItem value="verkenners">Verkenners</SelectItem>
                    <SelectItem value="wilde_vaart">Wilde Vaart</SelectItem>
                    <SelectItem value="staf">Staf</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                <p className="text-xs text-amber-700">
                  <strong>Let op:</strong> Het wijzigen van de rol geeft direct toegang tot de bijbehorende functies.
                </p>
              </div>
              <div className="flex gap-3 pt-2">
                <Button variant="outline" className="flex-1" onClick={() => setEditingUser(null)}>Annuleren</Button>
                <Button
                  className="flex-1"
                  disabled={updateMutation.isPending}
                  onClick={() => updateMutation.mutate({
                    id: editingUser.id,
                    role: editingUser.role,
                    speltak: editingUser.speltak,
                  })}
                >
                  Opslaan
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
