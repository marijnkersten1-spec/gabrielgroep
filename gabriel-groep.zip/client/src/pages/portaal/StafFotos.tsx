import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { Upload, Trash2, Image as ImageIcon, Loader2 } from "lucide-react";
import { toast } from "sonner";
import PortaalLayout from "@/components/PortaalLayout";

export default function StafFotos() {
  const [selectedGallery, setSelectedGallery] = useState<"activities" | "vloot" | "verhuur">("activities");
  const [uploadDialog, setUploadDialog] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [photoTitle, setPhotoTitle] = useState("");
  const [uploading, setUploading] = useState(false);

  // Fetch albums
  const { data: albums = [] } = trpc.photos.listAllAlbums.useQuery();
  const currentAlbum = albums.find((a: any) => a.title.toLowerCase().includes(selectedGallery));
  const { data: photos = [], refetch } = trpc.photos.getPhotos.useQuery(
    { albumId: currentAlbum?.id || 0 },
    { enabled: !!currentAlbum }
  );

  // Upload mutation
  const uploadMutation = trpc.photos.uploadPhoto.useMutation({
    onSuccess: () => {
      toast.success("Foto geupload!");
      setUploadDialog(false);
      setSelectedFile(null);
      setPhotoTitle("");
      setUploading(false);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Fout bij uploaden");
      setUploading(false);
    },
  });

  // Delete mutation
  const deleteMutation = trpc.photos.deletePhoto.useMutation({
    onSuccess: () => {
      toast.success("Foto verwijderd");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Fout bij verwijderen");
    },
  });

  const handleUpload = async () => {
    if (!selectedFile || !photoTitle || !currentAlbum) {
      toast.error("Selecteer een foto en voer een titel in");
      return;
    }

    setUploading(true);
    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64 = e.target?.result as string;
      const base64Data = base64.split(",")[1] || base64;
      uploadMutation.mutate({
        albumId: currentAlbum.id,
        title: photoTitle,
        fileData: base64Data,
        fileName: selectedFile.name,
        mimeType: selectedFile.type,
        isPublic: true,
      });
    };
    reader.readAsDataURL(selectedFile);
  };

  const galleryLabels = {
    activities: "Activiteiten",
    vloot: "De Vloot",
    verhuur: "Verhuur",
  };

  return (
    <PortaalLayout>
      <div className="space-y-6">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground mb-2">
            Fotogalerijen Beheren
          </h1>
          <p className="text-muted-foreground">
            Upload en beheer foto's voor de verschillende galerijen
          </p>
        </div>

        {/* Gallery Selection */}
        <div className="flex gap-3">
          {(["activities", "vloot", "verhuur"] as const).map((gallery) => (
            <Button
              key={gallery}
              variant={selectedGallery === gallery ? "default" : "outline"}
              onClick={() => setSelectedGallery(gallery)}
            >
              {galleryLabels[gallery]}
            </Button>
          ))}
        </div>

        {/* Upload Button */}
        <Button
          onClick={() => setUploadDialog(true)}
          className="w-full md:w-auto"
        >
          <Upload className="w-4 h-4 mr-2" />
          Foto Uploaden
        </Button>

        {/* Photos Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {photos.length === 0 ? (
            <div className="col-span-full text-center py-12">
              <ImageIcon className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-display text-lg font-bold text-foreground mb-2">
                Geen foto's
              </h3>
              <p className="text-muted-foreground">
                Voeg foto's toe aan deze galerij
              </p>
            </div>
          ) : (
            photos.map((photo: any) => (
              <Card key={photo.id} className="border border-border overflow-hidden group">
                <div className="aspect-video bg-muted overflow-hidden relative">
                  {photo.url ? (
                    <img
                      src={photo.url}
                      alt={photo.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-muted">
                      <ImageIcon className="w-8 h-8 text-muted-foreground" />
                    </div>
                  )}
                  <Button
                    variant="destructive"
                    size="sm"
                    className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => {
                if (photo.id) deleteMutation.mutate(photo.id);
              }}
                    disabled={deleteMutation.isPending}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
                <CardContent className="p-4">
                  <h3 className="font-display font-bold text-foreground truncate">
                    {photo.title}
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1">
                    {new Date(photo.createdAt).toLocaleDateString("nl-NL")}
                  </p>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>

      {/* Upload Dialog */}
      <Dialog open={uploadDialog} onOpenChange={setUploadDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Foto Uploaden naar {galleryLabels[selectedGallery]}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="photo-title">Titel</Label>
              <Input
                id="photo-title"
                placeholder="Bijv. Zeiltraining mei 2026"
                value={photoTitle}
                onChange={(e) => setPhotoTitle(e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="photo-file">Foto</Label>
              <div className="border-2 border-dashed border-border rounded-lg p-6 text-center cursor-pointer hover:border-primary transition-colors"
                onClick={() => document.getElementById("photo-file")?.click()}
              >
                {selectedFile ? (
                  <div>
                    <ImageIcon className="w-8 h-8 text-primary mx-auto mb-2" />
                    <p className="font-medium text-foreground">{selectedFile.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                ) : (
                  <div>
                    <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                    <p className="font-medium text-foreground">Klik om foto te selecteren</p>
                    <p className="text-xs text-muted-foreground">PNG, JPG, GIF tot 10MB</p>
                  </div>
                )}
                <input
                  id="photo-file"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                />
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => {
                  setUploadDialog(false);
                  setSelectedFile(null);
                  setPhotoTitle("");
                }}
              >
                Annuleren
              </Button>
              <Button
                onClick={handleUpload}
                disabled={uploading || !selectedFile || !photoTitle}
                className="flex-1"
              >
                {uploading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Uploaden...
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4 mr-2" />
                    Uploaden
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </PortaalLayout>
  );
}
