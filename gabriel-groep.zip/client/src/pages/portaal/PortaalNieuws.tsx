import { Card, CardContent } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import { Newspaper } from "lucide-react";
import SpeltakBadge from "@/components/SpeltakBadge";

export default function PortaalNieuws() {
  const { data: newsItems, isLoading } = trpc.news.listAll.useQuery();

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="font-display text-3xl font-bold text-foreground mb-1">Nieuws</h1>
        <p className="text-muted-foreground">Berichten en aankondigingen voor leden</p>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-32 rounded-xl bg-muted animate-pulse" />
          ))}
        </div>
      ) : !newsItems?.length ? (
        <div className="text-center py-16 text-muted-foreground">
          <Newspaper className="w-10 h-10 mx-auto mb-3 opacity-40" />
          <h3 className="font-display text-lg font-bold text-foreground mb-1">Geen nieuws</h3>
          <p className="text-sm">Er zijn momenteel geen nieuwsberichten.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {newsItems.map((item) => (
            <Card key={item.id} className="border border-border hover:shadow-sm transition-shadow">
              <CardContent className="p-5">
                <div className="flex items-start gap-4">
                  {item.coverImageUrl && (
                    <div className="w-24 h-20 rounded-lg overflow-hidden shrink-0">
                      <img src={item.coverImageUrl} alt={item.title} className="w-full h-full object-cover" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      {item.speltak && item.speltak !== "all" && (
                        <SpeltakBadge speltak={item.speltak} size="sm" />
                      )}
                      <span className="text-xs text-muted-foreground">
                        {item.publishedAt ? format(new Date(item.publishedAt), "d MMMM yyyy", { locale: nl }) : ""}
                      </span>
                    </div>
                    <h3 className="font-semibold text-foreground mb-1">{item.title}</h3>
                    {item.excerpt && (
                      <p className="text-sm text-muted-foreground line-clamp-2">{item.excerpt}</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
