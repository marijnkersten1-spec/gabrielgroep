import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import { Plus, Calendar, MapPin, Edit, Trash2, Users } from "lucide-react";
import SpeltakBadge from "@/components/SpeltakBadge";
import { EVENT_TYPE_LABELS } from "@/lib/constants";

export default function StafActiviteiten() {
  const [showCreate, setShowCreate] = useState(false);
  const [editingEvent, setEditingEvent] = useState<any | null>(null);
  const [form, setForm] = useState({
    title: "", description: "", location: "", startDate: "", endDate: "",
    speltak: "all" as any, type: "activity" as any, isPublic: true,
    maxParticipants: "", registrationRequired: false,
  });

  const { data: events, refetch } = trpc.events.list.useQuery({});

  const createMutation = trpc.events.create.useMutation({
    onSuccess: () => { toast.success("Activiteit aangemaakt"); refetch(); setShowCreate(false); resetForm(); },
    onError: (err: any) => toast.error(err.message),
  });

  const deleteMutation = trpc.events.delete.useMutation({
    onSuccess: () => { toast.success("Activiteit verwijderd"); refetch(); },
    onError: (err: any) => toast.error(err.message),
  });

  const resetForm = () => setForm({
    title: "", description: "", location: "", startDate: "", endDate: "",
    speltak: "all", type: "activity", isPublic: true, maxParticipants: "", registrationRequired: false,
  });

  const handleCreate = () => {
    if (!form.title || !form.startDate) {
      toast.error("Vul de verplichte velden in");
      return;
    }
    createMutation.mutate({
      title: form.title,
      description: form.description || undefined,
      location: form.location || undefined,
      startDate: new Date(form.startDate),
      endDate: form.endDate ? new Date(form.endDate) : undefined,
      speltak: form.speltak,
      type: form.type,
      isPublic: form.isPublic,
      maxParticipants: form.maxParticipants ? parseInt(form.maxParticipants) : undefined,
    });
  };

  const upcoming = events?.filter((e) => new Date(e.startDate) >= new Date()) ?? [];
  const past = events?.filter((e) => new Date(e.startDate) < new Date()) ?? [];

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground mb-1">Activiteiten</h1>
          <p className="text-muted-foreground">{events?.length ?? 0} activiteiten totaal</p>
        </div>
        <Button onClick={() => setShowCreate(true)}>
          <Plus className="w-4 h-4 mr-2" /> Nieuwe Activiteit
        </Button>
      </div>

      {/* Upcoming */}
      <div className="mb-8">
        <h2 className="font-display text-lg font-bold text-foreground mb-4">Aankomend ({upcoming.length})</h2>
        {upcoming.length === 0 ? (
          <p className="text-muted-foreground text-sm">Geen aankomende activiteiten</p>
        ) : (
          <div className="space-y-2">
            {upcoming.map((event) => (
              <Card key={event.id} className="border border-border">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex flex-col items-center justify-center shrink-0">
                      <span className="text-primary font-bold text-sm leading-none">
                        {format(new Date(event.startDate), "d")}
                      </span>
                      <span className="text-primary/70 text-xs uppercase">
                        {format(new Date(event.startDate), "MMM", { locale: nl })}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="font-medium text-foreground text-sm">{event.title}</span>
                        <SpeltakBadge speltak={event.speltak} size="sm" />
                        <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">
                          {EVENT_TYPE_LABELS[event.type]}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {format(new Date(event.startDate), "HH:mm", { locale: nl })}
                        </span>
                        {event.location && (
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" /> {event.location}
                          </span>
                        )}
                        {event.maxParticipants && (
                          <span className="flex items-center gap-1">
                            <Users className="w-3 h-3" /> Max {event.maxParticipants}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteMutation.mutate({ id: event.id })}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Past */}
      {past.length > 0 && (
        <div>
          <h2 className="font-display text-lg font-bold text-foreground mb-4 text-muted-foreground">
            Verleden ({past.length})
          </h2>
          <div className="space-y-2 opacity-60">
            {past.slice(0, 5).map((event) => (
              <Card key={event.id} className="border border-border">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-muted flex flex-col items-center justify-center shrink-0">
                      <span className="font-bold text-sm leading-none text-muted-foreground">
                        {format(new Date(event.startDate), "d")}
                      </span>
                      <span className="text-muted-foreground text-xs uppercase">
                        {format(new Date(event.startDate), "MMM", { locale: nl })}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="font-medium text-foreground text-sm">{event.title}</span>
                    </div>
                    <SpeltakBadge speltak={event.speltak} size="sm" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Create Dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Nieuwe Activiteit</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Titel *</Label>
              <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="mt-1.5" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Speltak</Label>
                <Select value={form.speltak} onValueChange={(v) => setForm({ ...form, speltak: v })}>
                  <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Iedereen</SelectItem>
                    <SelectItem value="dolfijnen">Dolfijnen</SelectItem>
                    <SelectItem value="verkenners">Verkenners</SelectItem>
                    <SelectItem value="wilde_vaart">Wilde Vaart</SelectItem>
                    <SelectItem value="staf">Staf</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Type</Label>
                <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                  <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(EVENT_TYPE_LABELS).map(([k, v]) => (
                      <SelectItem key={k} value={k}>{v}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Startdatum *</Label>
                <Input type="datetime-local" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} className="mt-1.5" />
              </div>
              <div>
                <Label>Einddatum</Label>
                <Input type="datetime-local" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} className="mt-1.5" />
              </div>
            </div>
            <div>
              <Label>Locatie</Label>
              <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} className="mt-1.5" />
            </div>
            <div>
              <Label>Max. deelnemers</Label>
              <Input type="number" value={form.maxParticipants} onChange={(e) => setForm({ ...form, maxParticipants: e.target.value })} className="mt-1.5" />
            </div>
            <div>
              <Label>Beschrijving</Label>
              <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="mt-1.5 resize-none" rows={3} />
            </div>
            <div className="flex items-center gap-3">
              <Switch checked={form.isPublic} onCheckedChange={(v) => setForm({ ...form, isPublic: v })} />
              <Label>Publiek zichtbaar</Label>
            </div>
            <div className="flex gap-3 pt-2">
              <Button variant="outline" className="flex-1" onClick={() => setShowCreate(false)}>Annuleren</Button>
              <Button className="flex-1" onClick={handleCreate} disabled={createMutation.isPending}>
                {createMutation.isPending ? "Aanmaken..." : "Aanmaken"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
