import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogHeader, AlertDialogTitle, AlertDialogFooter } from "@/components/ui/alert-dialog";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import { CheckCircle2, XCircle, Eye, Mail, User, Calendar, MapPin, Phone } from "lucide-react";
import { toast } from "sonner";
import PortaalLayout from "@/components/PortaalLayout";
import { SPELTAK_LABELS } from "@/lib/constants";

export default function StafAanmeldingen() {
  const [selectedRequest, setSelectedRequest] = useState<any>(null);
  const [actionDialog, setActionDialog] = useState<{ type: "approve" | "reject"; id: number } | null>(null);
  const [rejectionReason, setRejectionReason] = useState("");

  // Fetch pending join requests
  const { data: joinRequests = [], refetch } = trpc.join.list.useQuery();
  const pendingRequests = joinRequests.filter((req: any) => req.status === "pending");

  // Approve mutation
  const approveMutation = trpc.join.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("Aanmelding goedgekeurd!");
      setActionDialog(null);
      setSelectedRequest(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Fout bij goedkeuren");
    },
  });

  // Reject mutation
  const rejectMutation = trpc.join.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("Aanmelding afgewezen");
      setActionDialog(null);
      setRejectionReason("");
      setSelectedRequest(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Fout bij afwijzen");
    },
  });

  const handleApprove = (id: number) => {
    approveMutation.mutate({ id, status: "approved" });
  };

  const handleReject = (id: number) => {
    rejectMutation.mutate({ id, status: "rejected" });
  };

  return (
    <PortaalLayout>
      <div className="space-y-6">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground mb-2">
            Aanmeldingen Beoordelen
          </h1>
          <p className="text-muted-foreground">
            Controleer en keur nieuwe aanmeldingen goed of af
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="border border-border">
            <CardContent className="p-6">
              <div className="text-sm text-muted-foreground mb-1">In afwachting</div>
              <div className="text-3xl font-bold text-foreground">{pendingRequests.length}</div>
            </CardContent>
          </Card>
          <Card className="border border-border">
            <CardContent className="p-6">
              <div className="text-sm text-muted-foreground mb-1">Totaal aanmeldingen</div>
              <div className="text-3xl font-bold text-foreground">{joinRequests.length}</div>
            </CardContent>
          </Card>
          <Card className="border border-border">
            <CardContent className="p-6">
              <div className="text-sm text-muted-foreground mb-1">Goedgekeurd</div>
              <div className="text-3xl font-bold text-green-600">
                {joinRequests.filter((r: any) => r.status === "approved").length}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Pending Requests List */}
        <div className="space-y-4">
          {pendingRequests.length === 0 ? (
            <Card className="border border-border">
              <CardContent className="p-12 text-center">
                <CheckCircle2 className="w-12 h-12 text-green-600 mx-auto mb-4" />
                <h3 className="font-display text-lg font-bold text-foreground mb-2">
                  Geen aanmeldingen in afwachting
                </h3>
                <p className="text-muted-foreground">
                  Alle aanmeldingen zijn verwerkt!
                </p>
              </CardContent>
            </Card>
          ) : (
            pendingRequests.map((request: any) => (
              <Card key={request.id} className="border border-border hover:border-primary/50 transition-colors">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="mb-4">
                        <h3 className="font-display font-bold text-foreground text-lg mb-1">
                          {request.childName}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          Kind van {request.parentName}
                        </p>
                      </div>

                      <div className="space-y-2 text-sm mb-4">
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Calendar className="w-4 h-4" />
                          {format(new Date(request.childBirthDate), "d MMMM yyyy", { locale: nl })}
                        </div>
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Mail className="w-4 h-4" />
                          {request.parentEmail}
                        </div>
                        {request.parentPhone && (
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Phone className="w-4 h-4" />
                            {request.parentPhone}
                          </div>
                        )}
                        {request.address && (
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <MapPin className="w-4 h-4" />
                            {request.address}
                          </div>
                        )}
                      </div>

                      {request.speltak && (
                        <div className="mb-4">
                          <Badge variant="secondary">
                            {SPELTAK_LABELS[request.speltak as keyof typeof SPELTAK_LABELS] || request.speltak}
                          </Badge>
                        </div>
                      )}

                      {request.message && (
                        <div className="bg-muted/50 p-3 rounded-lg mb-4">
                          <p className="text-xs text-muted-foreground font-semibold mb-1">Bericht van ouder:</p>
                          <p className="text-sm text-foreground leading-relaxed">
                            {request.message}
                          </p>
                        </div>
                      )}
                    </div>

                    <div className="flex gap-2 flex-shrink-0">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedRequest(request)}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => setActionDialog({ type: "approve", id: request.id })}
                        disabled={approveMutation.isPending}
                      >
                        <CheckCircle2 className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => setActionDialog({ type: "reject", id: request.id })}
                        disabled={rejectMutation.isPending}
                      >
                        <XCircle className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>

      {/* Detail Dialog */}
      <Dialog open={!!selectedRequest} onOpenChange={(open) => !open && setSelectedRequest(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Aanmeldingsdetails</DialogTitle>
          </DialogHeader>

          {selectedRequest && (
            <div className="space-y-6">
              <div>
                <h3 className="font-display font-bold text-foreground mb-4">Kind</h3>
                <div className="space-y-2 text-sm">
                  <div>
                    <span className="text-muted-foreground">Naam:</span>
                    <p className="font-medium text-foreground">{selectedRequest.childName}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Geboortedatum:</span>
                    <p className="font-medium text-foreground">
                      {format(new Date(selectedRequest.childBirthDate), "d MMMM yyyy", { locale: nl })}
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-display font-bold text-foreground mb-4">Ouder/Verzorger</h3>
                <div className="space-y-2 text-sm">
                  <div>
                    <span className="text-muted-foreground">Naam:</span>
                    <p className="font-medium text-foreground">{selectedRequest.parentName}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Email:</span>
                    <p className="font-medium text-foreground">{selectedRequest.parentEmail}</p>
                  </div>
                  {selectedRequest.parentPhone && (
                    <div>
                      <span className="text-muted-foreground">Telefoon:</span>
                      <p className="font-medium text-foreground">{selectedRequest.parentPhone}</p>
                    </div>
                  )}
                  {selectedRequest.address && (
                    <div>
                      <span className="text-muted-foreground">Adres:</span>
                      <p className="font-medium text-foreground">{selectedRequest.address}</p>
                    </div>
                  )}
                </div>
              </div>

              {selectedRequest.speltak && (
                <div>
                  <h3 className="font-display font-bold text-foreground mb-4">Voorkeur</h3>
                  <Badge>
                    {SPELTAK_LABELS[selectedRequest.speltak as keyof typeof SPELTAK_LABELS] || selectedRequest.speltak}
                  </Badge>
                </div>
              )}

              {selectedRequest.message && (
                <div>
                  <h3 className="font-display font-bold text-foreground mb-4">Bericht</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {selectedRequest.message}
                  </p>
                </div>
              )}

              <div className="flex gap-3">
                <Button
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  onClick={() => {
                    setSelectedRequest(null);
                    setActionDialog({ type: "approve", id: selectedRequest.id });
                  }}
                >
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  Goedkeuren
                </Button>
                <Button
                  variant="destructive"
                  className="flex-1"
                  onClick={() => {
                    setSelectedRequest(null);
                    setActionDialog({ type: "reject", id: selectedRequest.id });
                  }}
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Afwijzen
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Approve Confirmation Dialog */}
      <AlertDialog open={actionDialog?.type === "approve"} onOpenChange={(open) => !open && setActionDialog(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Aanmelding goedkeuren?</AlertDialogTitle>
            <AlertDialogDescription>
              Deze aanmelding zal worden goedgekeurd. De ouder ontvangt een bevestigingsmail.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="flex gap-3 justify-end">
            <AlertDialogCancel>Annuleren</AlertDialogCancel>
            <AlertDialogAction
              className="bg-green-600 hover:bg-green-700"
              onClick={() => {
                if (actionDialog?.id) {
                  handleApprove(actionDialog.id);
                }
              }}
            >
              Goedkeuren
            </AlertDialogAction>
          </div>
        </AlertDialogContent>
      </AlertDialog>

      {/* Reject Dialog */}
      <Dialog open={actionDialog?.type === "reject"} onOpenChange={(open) => !open && setActionDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Aanmelding afwijzen</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Wil je deze aanmelding afwijzen? De ouder ontvangt een bericht.
            </p>
            <Textarea
              placeholder="Optioneel: voeg een reden toe voor afwijzing..."
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              className="min-h-24"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setActionDialog(null)}>
              Annuleren
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                if (actionDialog?.id) {
                  handleReject(actionDialog.id);
                }
              }}
              disabled={rejectMutation.isPending}
            >
              Afwijzen
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PortaalLayout>
  );
}
