import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Anchor, Users, Zap, AlertCircle, ChevronDown } from "lucide-react";
import PublicLayout from "@/components/PublicLayout";
import AdminPhotoUpload from "@/components/AdminPhotoUpload";
import { useState } from "react";

const VLOOT_ALBUMS = {
  SEXTANT: 3,
  KLIPKRUIPER: 4,
  THOR: 5,
  KONTIKI: 6,
  CELSIUS: 7,
  BOEIBONKER: 8,
};

interface BoatInfo {
  id: string;
  name: string;
  number: string;
  description: string;
  technicalSpecs?: {
    motor?: string;
    keerbak?: string;
    length?: string;
    width?: string;
    draft?: string;
    height?: string;
    electra?: string;
  };
  albumId: number;
}

const boats: BoatInfo[] = [
  {
    id: "sextant",
    name: "Sextant",
    number: "",
    description: "Deze 10.80 meter lange, voormalige Rijkswaterstaat peil-vlet, is sinds 2019 het trotse bezit van de Gabriël. Dit is de 2e sleepboot die de groep in eigendom heeft gehad. De boot is oorspronkelijk ontworpen en gebouwd door de firma Damen te Hardinxveld-Giessendam en was uitgerust met een luchtgekoelde 2 cilinder Deutz motor. De vorige eigenaar heeft de boot vaar technisch opgeknapt, het dichte achterdek vervangen voor een open kuip, en er een zo goed als nieuwe DAF motor met bijpassende keerkoppeling in laten bouwen.",
    technicalSpecs: {
      motor: "DAF 615M",
      keerbak: "Hurth HSW450",
      length: "10.80 meter",
      draft: "+/- 1,10 m",
      height: "2,45 m",
      electra: "24V",
    },
    albumId: VLOOT_ALBUMS.SEXTANT,
  },
  {
    id: "klipkruiper",
    name: "Klipkruiper",
    number: "381",
    description: "De Klipkruiper is de oudste vlet van de Gabriël en het is geen toeval dat deze boot de 'Klipkruiper' heet. Deze vlet heeft deze naam eerlijk verdient doordat deze in het verleden met een sleep achter een jachtje over een strekdam in de maas heen 'gekropen' is. Ondanks dat deze boot al aan de oude kant is kan hij nog steeds heel wat jaren mee, de boot heeft in 2015 een nieuwe bodem en zwaardkast gekregen.",
    albumId: VLOOT_ALBUMS.KLIPKRUIPER,
  },
  {
    id: "thor",
    name: "Thor",
    number: "422",
    description: "De Thor is de vlet waarvan altijd gezegd dat deze niet heel goed zeilt en dat hij erg traag is. Dit zou zogenaamd komen doordat de bodem van de boot uit veel dikker staal gemaakt is dan bij de andere vletten. Deze vlet heeft in 2011 een nieuwe bodem en zwaardkast gekregen die inderdaad 1 mm dikker is dan gebruikelijk.",
    albumId: VLOOT_ALBUMS.THOR,
  },
  {
    id: "kontiki",
    name: "Kontiki",
    number: "466",
    description: "De Kontiki is de WV vlet van de groep. Op deze vlet zijn door de jaren heen veel boegsprieten en andere attributen gemaakt. In de huidige vorm zit er een mast verlenging (steng) en boegspriet op de boot. De bodem en zwaardkast van deze vlet zijn in 2015 samen met die van de Klipkruiper vervangen.",
    albumId: VLOOT_ALBUMS.KONTIKI,
  },
  {
    id: "celsius",
    name: "Celsius",
    number: "1742",
    description: "De Celsius is in 2016 bij de groep gekomen als extra vlet om de verwachte groei van de groep op te kunnen vangen. Deze vlet is gloednieuw met nieuwe uitrusting gekocht met hulp van de Rabobank (en de spaarrekening van de Gabriël). De naam Celsius is ook niet uit de lucht komen vallen, in het jaar 1742 is de Celsius schaal uitgevonden.",
    albumId: VLOOT_ALBUMS.CELSIUS,
  },
  {
    id: "boeibonker",
    name: "Boeibonker II",
    number: "1779",
    description: "De Boeibonker II is de meest recente aanwinst van de Gabriël. De vlet is in 2017 aangekocht met hulp van de Loodsen. Dit is een moderne en goed uitgeruste vlet die perfect aansluit bij de groep.",
    albumId: VLOOT_ALBUMS.BOEIBONKER,
  },
];

export default function DeVloot() {
  const [expandedBoat, setExpandedBoat] = useState<string | null>(null);
  const { data: vlootPhotos, refetch: refetchVlootPhotos } = trpc.photos.getPhotos.useQuery({ albumId: VLOOT_ALBUMS.SEXTANT });

  return (
    <PublicLayout>
      {/* Hero */}
      <section className="relative pt-32 pb-16 bg-primary overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-white transform translate-x-1/3 -translate-y-1/3" />
        </div>
        <div className="relative container">
          <Badge className="bg-white/20 text-white border-white/30 mb-5">De Vloot</Badge>
          <h1 className="font-display text-5xl font-bold text-white mb-4">Onze Vloot</h1>
          <p className="text-white/80 text-xl max-w-xl">
            Ontdek onze collectie boten en zeiltechnieken. Van kleine dinghies tot grote zeilboten.
          </p>
        </div>
      </section>

      {/* Boats Section */}
      <section className="py-16 bg-background">
        <div className="container">
          <div className="max-w-4xl mx-auto space-y-6">
            {boats.map((boat) => {
              const { data: boatPhotos, refetch: refetchBoatPhotos } = trpc.photos.getPhotos.useQuery({ albumId: boat.albumId });
              const isExpanded = expandedBoat === boat.id;

              return (
                <Card key={boat.id} className="border border-border overflow-hidden">
                  <div
                    className="cursor-pointer p-6 hover:bg-muted/50 transition-colors"
                    onClick={() => setExpandedBoat(isExpanded ? null : boat.id)}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h2 className="font-display text-2xl font-bold text-foreground">{boat.name}</h2>
                          {boat.number && (
                            <Badge variant="secondary" className="text-sm">
                              #{boat.number}
                            </Badge>
                          )}
                        </div>
                        <p className="text-muted-foreground line-clamp-2">{boat.description}</p>
                      </div>
                      <ChevronDown
                        className={`w-6 h-6 text-muted-foreground transition-transform flex-shrink-0 ${
                          isExpanded ? "rotate-180" : ""
                        }`}
                      />
                    </div>
                  </div>

                  {isExpanded && (
                    <div className="border-t border-border px-6 py-6 space-y-6">
                      {/* Description */}
                      <div>
                        <p className="text-muted-foreground leading-relaxed">{boat.description}</p>
                      </div>

                      {/* Technical Specs */}
                      {boat.technicalSpecs && Object.values(boat.technicalSpecs).some((v) => v) && (
                        <div>
                          <h4 className="font-semibold text-foreground mb-3">Technische gegevens:</h4>
                          <div className="grid grid-cols-2 gap-3 text-sm">
                            {boat.technicalSpecs.motor && (
                              <div>
                                <span className="text-muted-foreground">Motor:</span>
                                <p className="font-medium text-foreground">{boat.technicalSpecs.motor}</p>
                              </div>
                            )}
                            {boat.technicalSpecs.keerbak && (
                              <div>
                                <span className="text-muted-foreground">Keerbak:</span>
                                <p className="font-medium text-foreground">{boat.technicalSpecs.keerbak}</p>
                              </div>
                            )}
                            {boat.technicalSpecs.length && (
                              <div>
                                <span className="text-muted-foreground">Lengte:</span>
                                <p className="font-medium text-foreground">{boat.technicalSpecs.length}</p>
                              </div>
                            )}
                            {boat.technicalSpecs.width && (
                              <div>
                                <span className="text-muted-foreground">Breedte:</span>
                                <p className="font-medium text-foreground">{boat.technicalSpecs.width}</p>
                              </div>
                            )}
                            {boat.technicalSpecs.draft && (
                              <div>
                                <span className="text-muted-foreground">Diepgang:</span>
                                <p className="font-medium text-foreground">{boat.technicalSpecs.draft}</p>
                              </div>
                            )}
                            {boat.technicalSpecs.height && (
                              <div>
                                <span className="text-muted-foreground">Doorvaarthoogte:</span>
                                <p className="font-medium text-foreground">{boat.technicalSpecs.height}</p>
                              </div>
                            )}
                            {boat.technicalSpecs.electra && (
                              <div>
                                <span className="text-muted-foreground">Electra:</span>
                                <p className="font-medium text-foreground">{boat.technicalSpecs.electra}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Photo Gallery */}
                      <div>
                        <div className="flex items-center justify-between mb-4">
                          <h4 className="font-semibold text-foreground">Foto's</h4>
                          <AdminPhotoUpload
                            albumId={boat.albumId}
                            albumTitle={boat.name}
                            onUploadSuccess={() => refetchBoatPhotos()}
                          />
                        </div>
                        {boatPhotos && boatPhotos.length > 0 ? (
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                            {boatPhotos.map((photo: any) => (
                              <div
                                key={photo.id}
                                className="aspect-square rounded-lg overflow-hidden bg-muted group cursor-pointer"
                              >
                                <img
                                  src={photo.url}
                                  alt={photo.title}
                                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                                />
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="text-center py-8 text-muted-foreground bg-muted/30 rounded-lg">
                            <Anchor className="w-8 h-8 mx-auto mb-2 opacity-40" />
                            <p className="text-sm">Nog geen foto's geupload</p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
