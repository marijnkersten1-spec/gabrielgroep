import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { CDN, SPELTAK_AGES } from "@/lib/constants";
import { Anchor, Heart, Shield, Users, Waves, ArrowRight, ChevronDown } from "lucide-react";
import PublicLayout from "@/components/PublicLayout";

const speltakken = [
  {
    id: "dolfijnen",
    name: "Dolfijnen",
    emoji: "🐬",
    ages: SPELTAK_AGES.dolfijnen,
    color: "bg-blue-50 border-blue-200",
    titleColor: "text-blue-700",
    desc: "De Dolfijnen zijn onze jongste avonturiers. In een speelse en veilige omgeving maken ze kennis met het water, leren ze eenvoudige zeiltechnieken en ontdekken ze de natuur rondom Middelaar. Activiteiten zijn gericht op samenwerken, creativiteit en plezier.",
    activities: ["Kanoën", "Stranddagen", "Natuur verkennen", "Knutselen", "Spelletjes op het water"],
  },
  {
    id: "verkenners",
    name: "Verkenners",
    emoji: "🧭",
    ages: SPELTAK_AGES.verkenners,
    color: "bg-green-50 border-green-200",
    titleColor: "text-green-700",
    desc: "De Verkenners zijn echte avonturiers die klaar zijn voor grotere uitdagingen. Ze leren zeilen op sloepen, plannen meerdaagse kampen en ontwikkelen leiderschapsvaardigheden. Dit is de leeftijdsgroep waar echte vriendschappen voor het leven worden gesmeed.",
    activities: ["Zeilen op sloepen", "Meerdaagse kampen", "Navigatie", "Eerste hulp", "Koken in de natuur"],
  },
  {
    id: "wilde_vaart",
    name: "Wilde Vaart",
    emoji: "⚓",
    ages: SPELTAK_AGES.wilde_vaart,
    color: "bg-orange-50 border-orange-200",
    titleColor: "text-orange-700",
    desc: "De Wilde Vaart zijn onze oudste scouts die zelfstandig grote tochten ondernemen. Ze varen op open water, organiseren eigen activiteiten en bereiden zich voor op de stap naar de staf. Dit is de ultieme scoutingervaring.",
    activities: ["Zeezeilen", "Lange vaarreis", "Leiderschap", "Zelfstandig plannen", "Stafbegeleiding"],
  },
];

const values = [
  { icon: Waves, title: "Avontuur", desc: "We geloven dat avontuur op het water kinderen vormt en inspireert." },
  { icon: Users, title: "Gemeenschap", desc: "Samen zijn we sterker. Vriendschappen en teamwork staan centraal." },
  { icon: Shield, title: "Veiligheid", desc: "Alle activiteiten worden begeleid door gecertificeerde vrijwilligers." },
  { icon: Heart, title: "Inclusiviteit", desc: "Iedereen is welkom, ongeacht achtergrond of ervaring." },
];

export default function OverOns() {
  const [privacyOpen, setPrivacyOpen] = useState(false);

  return (
    <PublicLayout>
      {/* Hero */}
      <section className="relative pt-32 pb-20 bg-primary overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-white transform translate-x-1/3 -translate-y-1/3" />
        </div>
        <div className="relative container">
          <Badge className="bg-white/20 text-white border-white/30 mb-5">Over Ons</Badge>
          <h1 className="font-display text-5xl md:text-6xl font-bold text-white mb-5">
            Gabriël Groep
          </h1>
          <p className="text-white/80 text-xl max-w-2xl leading-relaxed">
            Al meer dan 20 jaar brengen wij kinderen en jongeren samen op het water. Zeeverkenners Gabriël is een plek waar avontuur, vriendschap en persoonlijke groei samenkomen.
          </p>
        </div>
      </section>

      {/* Mission */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <Badge variant="outline" className="mb-4 text-primary border-primary/30">Onze Missie</Badge>
              <h2 className="font-display text-4xl font-bold text-foreground mb-6">
                Meer dan een scoutinggroep
              </h2>
              <p className="text-muted-foreground text-lg leading-relaxed mb-6">
                Gabriël Groep is opgericht met de missie om kinderen en jongeren te laten groeien door avontuur op het water. We geloven dat zeilen en scouting niet alleen leuke activiteiten zijn, maar ook waardevolle levenslessen bieden.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-8">
                Onze vrijwilligers — allemaal oud-scouts — geven hun tijd en kennis om de volgende generatie te inspireren. We zijn aangesloten bij Scouting Nederland en volgen alle richtlijnen voor veiligheid en kwaliteit.
              </p>
              <div className="flex items-center gap-3 p-4 bg-primary/5 rounded-xl border border-primary/15">
                <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center shrink-0">
                  <Anchor className="w-5 h-5 text-primary-foreground" />
                </div>
                <div>
                  <div className="font-semibold text-foreground text-sm">Locatie</div>
                  <div className="text-muted-foreground text-sm">Witteweg 23M, 6587 AJ Middelaar</div>
                </div>
              </div>
            </div>
            <div className="rounded-2xl overflow-hidden shadow-xl">
              <img
                src={CDN.sailingYouth}
                alt="Zeeverkenners op het water"
                className="w-full h-96 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-muted/40">
        <div className="container">
          <div className="text-center mb-14">
            <Badge variant="outline" className="mb-4 text-primary border-primary/30">Onze Waarden</Badge>
            <h2 className="font-display text-4xl font-bold text-foreground mb-4">
              Waar wij voor staan
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((v) => (
              <Card key={v.title} className="text-center border border-border card-hover">
                <CardContent className="p-7">
                  <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <v.icon className="w-7 h-7 text-primary" />
                  </div>
                  <h3 className="font-display font-bold text-lg text-foreground mb-2">{v.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{v.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Speltakken */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="text-center mb-14">
            <Badge variant="outline" className="mb-4 text-primary border-primary/30">Speltakken</Badge>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
              Voor elke leeftijd een avontuur
            </h2>
            <p className="text-muted-foreground text-lg max-w-xl mx-auto">
              Onze drie speltakken bieden een op maat gemaakt programma voor elke leeftijdsgroep.
            </p>
          </div>

          <div className="space-y-10">
            {speltakken.map((speltak, i) => (
              <Card
                key={speltak.id}
                id={speltak.id === "wilde_vaart" ? "wilde-vaart" : speltak.id}
                className={`border-2 ${speltak.color} overflow-hidden`}
              >
                <CardContent className="p-0">
                  <div className={`grid grid-cols-1 lg:grid-cols-3 ${i % 2 === 1 ? "lg:grid-flow-dense" : ""}`}>
                    <div className={`p-8 lg:col-span-2 ${i % 2 === 1 ? "lg:col-start-2" : ""}`}>
                      <div className="flex items-center gap-3 mb-4">
                        <span className="text-4xl">{speltak.emoji}</span>
                        <div>
                          <h3 className={`font-display text-3xl font-bold ${speltak.titleColor}`}>
                            {speltak.name}
                          </h3>
                          <p className="text-muted-foreground text-sm">{speltak.ages}</p>
                        </div>
                      </div>
                      <p className="text-muted-foreground leading-relaxed mb-6">{speltak.desc}</p>
                      <div>
                        <h4 className="font-semibold text-foreground text-sm mb-3">Activiteiten</h4>
                        <div className="flex flex-wrap gap-2">
                          {speltak.activities.map((act) => (
                            <span key={act} className="bg-white border border-border text-foreground text-xs px-3 py-1 rounded-full">
                              {act}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className={`p-8 flex items-center justify-center ${i % 2 === 1 ? "lg:col-start-1 lg:row-start-1" : ""}`}>
                      <div className="text-center">
                        <div className="text-7xl mb-3">{speltak.emoji}</div>
                        <div className={`font-display text-xl font-bold ${speltak.titleColor}`}>{speltak.name}</div>
                        <div className="text-muted-foreground text-sm">{speltak.ages}</div>
                        <Link href="/lid-worden">
                          <Button className="mt-5" size="sm">
                            Aanmelden <ArrowRight className="w-4 h-4 ml-1" />
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Privacyverklaring */}
      <section className="py-12 bg-muted/30">
        <div className="container max-w-4xl">
          <button
            onClick={() => setPrivacyOpen((v) => !v)}
            className="w-full flex items-center justify-between p-6 bg-background border border-border rounded-xl hover:border-primary/40 transition-colors group"
            aria-expanded={privacyOpen}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Shield className="w-5 h-5 text-primary" />
              </div>
              <div className="text-left">
                <h2 className="font-display text-xl font-bold text-foreground">Privacyverklaring</h2>
                <p className="text-muted-foreground text-sm">Zeeverkenners Gabrielgroep Mook</p>
              </div>
            </div>
            <ChevronDown
              className={`w-5 h-5 text-muted-foreground transition-transform duration-200 ${
                privacyOpen ? "rotate-180" : ""
              }`}
            />
          </button>

          {privacyOpen && (
            <div className="mt-2 p-8 bg-background border border-border rounded-xl space-y-6 text-sm text-muted-foreground leading-relaxed">
              <p>
                Zeeverkenners Gabrielgroep Mook verwerkt persoonsgegevens. Wij willen je hierover graag duidelijk en transparant informeren.
              </p>

              <div>
                <h3 className="font-display font-bold text-foreground mb-2">Privacystatement</h3>
                <p>
                  In het privacystatement geven wij je antwoord op de belangrijkste vragen over de verwerking van persoonsgegevens door Zeeverkenners Gabrielgroep Mook via ledenadministratiesysteem Scouts Online van Scouting Nederland. Het privacystatement is terug te vinden op{" "}
                  <a href="https://www.scouting.nl/privacy" target="_blank" rel="noopener noreferrer" className="text-primary underline hover:text-primary/80">www.scouting.nl/privacy</a>.
                </p>
              </div>

              <div>
                <h3 className="font-display font-bold text-foreground mb-2">Lidmaatschapsregistratie</h3>
                <p>
                  De lidmaatschapsregistratie verloopt via het inschrijfformulier dat u ingescand toestuurt aan het op het formulier aangeduide emailadres. De ledenadministratie (gegevensbeheerder) en webmasters hebben enkel inzicht in deze gegevens. Zodra het lidmaatschap effectief wordt, worden de gegevens geregistreerd in Scouts Online en wordt het inschrijfformulier verwijderd. Voor Scouts Online zie het privacystatement op{" "}
                  <a href="https://www.scouting.nl/privacy" target="_blank" rel="noopener noreferrer" className="text-primary underline hover:text-primary/80">www.scouting.nl/privacy</a>.
                </p>
              </div>

              <div>
                <h3 className="font-display font-bold text-foreground mb-2">Gezondheidsformulieren activiteiten en kampen</h3>
                <p>
                  Zeeverkenners Gabrielgroep Mook hecht veel waarde aan een veilige speelomgeving. Toch zit een ongeluk in een klein hoekje en kan het soms nodig zijn om een arts te raadplegen. Ook is het voor activiteiten die langer duren dan een reguliere opkomst, zoals een overnachting of kamp, noodzakelijk dat de (bege)leiding van de jeugdleden beschikt over informatie over de gezondheid van uw kind. Denk hierbij aan voedselallergieën of medicijngebruik. Voor deze gelegenheden wordt gebruikgemaakt van een gezondheidsformulier / -vragenlijst die per activiteit op papier/hardcopy dient te worden ingevuld en ingeleverd door de ouders/verzorgers. De ingeleverde vragenlijsten worden zorgvuldig bewaard in een afgesloten ruimte en niet digitaal bewaard. De vragenlijsten zijn alleen inzichtelijk voor het leidingteam van de betreffende speltak als genoemd op het formulier. Het formulier wordt direct na afloop van de activiteit vernietigd.
                </p>
              </div>

              <div>
                <h3 className="font-display font-bold text-foreground mb-2">Relevante gezondheidsinformatie opkomsten</h3>
                <p>
                  In sommige situaties is het noodzakelijk dat de (bege)leiding van de jeugdleden op de hoogte is van bepaalde medische informatie of informatie met betrekking tot de gezondheidssituatie zoals allergieën of medicijngebruik. Zeeverkenners Gabrielgroep Mook mag deze 'bijzondere persoonsgegevens' niet registreren, maar wijst ouders/verzorgers bij lidmaatschapsregistratie op het belang van het verstrekken van deze informatie aan het leidingteam. Het verstrekken van de juiste informatie is de verantwoordelijkheid van de ouder/verzorger.
                </p>
              </div>

              <div>
                <h3 className="font-display font-bold text-foreground mb-2">Registratie activiteiten</h3>
                <p>
                  Voor (groeps)activiteiten en kampen wordt gebruikgemaakt van een papieren registratieformulier van Zeeverkenners Gabrielgroep Mook. De gegevens worden na de activiteit vernietigd. Er worden geen herleidbare persoonsgegevens geregistreerd.
                </p>
              </div>

              <div>
                <h3 className="font-display font-bold text-foreground mb-2">Financiële gegevens</h3>
                <p>
                  Om de financiële administratie te voeren maken wij gebruik van Scouts Online. Voor Scouts Online zie het privacystatement op{" "}
                  <a href="https://www.scouting.nl/privacy" target="_blank" rel="noopener noreferrer" className="text-primary underline hover:text-primary/80">www.scouting.nl/privacy</a>. De penningmeester van de Gabrielgroep heeft inzicht in de financiële gegevens.
                </p>
              </div>

              <div>
                <h3 className="font-display font-bold text-foreground mb-2">Online media</h3>
                <p>
                  Zeeverkenners Gabrielgroep Mook maakt gebruik van een e-mailnieuwsbrief waarin relevante lidmaatschapsinformatie wordt gedeeld. Alle leden ontvangen deze nieuwsbrief op het opgegeven e-mailadres bij lidmaatschapsregistratie. Er is mogelijkheid voor een OPT-Out.
                </p>
                <p className="mt-2">
                  Op www.gabrielgroep.nl worden cookies gebruikt voor het functioneren van de website en het meten van bezoekersstromen (analytics). Hiervoor is een melding met meer informatie beschikbaar op de website.
                </p>
              </div>

              <div>
                <h3 className="font-display font-bold text-foreground mb-2">Beeldmateriaal</h3>
                <p>
                  Zeeverkenners Gabrielgroep Mook maakt foto's en video's van diverse activiteiten ten behoeve van de promotie van Zeeverkenners Gabrielgroep Mook en als herinnering. Bij lidmaatschapsregistratie wordt expliciet toestemming gevraagd voor het maken van beeldmateriaal van het betreffende jeugdlid. Toestemming is altijd in te trekken.
                </p>
              </div>

              <div>
                <h3 className="font-display font-bold text-foreground mb-2">Communicatie</h3>
                <p>
                  Het privacybeleid van Zeeverkenners Gabrielgroep Mook is terug te vinden via www.gabrielgroep.nl en op te vragen via het secretariaat op{" "}
                  <a href="mailto:bestuur@gabrielgroep.nl" className="text-primary underline hover:text-primary/80">bestuur@gabrielgroep.nl</a>.
                </p>
              </div>

              <div>
                <h3 className="font-display font-bold text-foreground mb-2">Datalekken</h3>
                <p>
                  Indien er sprake is van (een vermoeden van) een datalek wordt dit conform het 'protocol datalekken verwerkers' gemeld bij Scouting Nederland via{" "}
                  <a href="mailto:privacy@scouting.nl" className="text-primary underline hover:text-primary/80">privacy@scouting.nl</a>. Na melding van een datalek heeft Scouting Nederland een informatieplicht die voorschrijft dat leden worden geïnformeerd over wat er met hun persoonsgegevens is gebeurd.
                </p>
              </div>

              <div>
                <h3 className="font-display font-bold text-foreground mb-2">Recht op vergetelheid (RTBF) en inzage in gegevens (SAR)</h3>
                <p>
                  Indien een lid een beroep doet op het recht op vergetelheid (RTBF) of inzage in gegevens (SAR) reageert Zeeverkenners Gabrielgroep Mook binnen één maand op dit verzoek. Dit verzoek dient schriftelijk gedaan te worden via het secretariaat ({" "}
                  <a href="mailto:bestuur@gabrielgroep.nl" className="text-primary underline hover:text-primary/80">bestuur@gabrielgroep.nl</a>). Conform het privacybeleid van Scouting Nederland wordt dit verzoek in overleg met de afdeling Juridische zaken van Scouting Nederland in behandeling genomen.
                </p>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-primary">
        <div className="container text-center">
          <h2 className="font-display text-4xl font-bold text-white mb-5">
            Wil je meer weten?
          </h2>
          <p className="text-white/75 text-lg mb-8 max-w-lg mx-auto">
            Neem contact op of meld je direct aan. We heten je van harte welkom bij Gabriël Groep!
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/lid-worden">
              <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
                Lid Worden <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
            <Link href="/contact">
              <Button size="lg" variant="outline" className="border-white/40 text-white hover:bg-white/10">
                Contact Opnemen
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
