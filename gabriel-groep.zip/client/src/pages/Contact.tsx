import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useState } from "react";
import { CheckCircle2, Mail, MapPin, Clock, Facebook, Instagram } from "lucide-react";
import { MapView } from "@/components/Map";
import PublicLayout from "@/components/PublicLayout";

const schema = z.object({
  name: z.string().min(2, "Vul uw naam in"),
  email: z.string().email("Vul een geldig e-mailadres in"),
  subject: z.string().optional(),
  message: z.string().min(10, "Uw bericht moet minimaal 10 tekens bevatten"),
});

type FormData = z.infer<typeof schema>;

const contactPersons = [
  {
    speltak: "Dolfijnen",
    name: "Stan de Groot",
    email: "dolfijnen@gabrielgroep.nl",
    photo: "https://d2xsxph8kpxj0f.cloudfront.net/310519663467900671/auFutdbkCM7YzmFQQVZLdc/contact_stan_1c50038d.jpg",
  },
  {
    speltak: "Verkenners",
    name: "Samuel de Haan",
    email: "verkenners@gabrielgroep.nl",
    photo: "https://d2xsxph8kpxj0f.cloudfront.net/310519663467900671/auFutdbkCM7YzmFQQVZLdc/contact_samuel_212f9e9c.jpg",
  },
  {
    speltak: "Wilde Vaart",
    name: "Quirijn Boot",
    email: "wildevaart@gabrielgroep.nl",
    photo: "https://d2xsxph8kpxj0f.cloudfront.net/310519663467900671/auFutdbkCM7YzmFQQVZLdc/contact_quirijn_6f1285bb.jpg",
  },
  {
    speltak: "Verhuur",
    name: "Jurrit Rodenhuis",
    email: "verhuur@gabrielgroep.nl",
    photo: null,
  },
];

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);

  const { register, handleSubmit, reset, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  const submitMutation = trpc.contact.submit.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      reset();
    },
    onError: (err) => toast.error(err.message),
  });

  const onSubmit = (data: FormData) => submitMutation.mutate(data);

  return (
    <PublicLayout>
      {/* Hero */}
      <section className="relative pt-32 pb-16 bg-primary overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-white transform translate-x-1/3 -translate-y-1/3" />
        </div>
        <div className="relative container">
          <Badge className="bg-white/20 text-white border-white/30 mb-5">Contact</Badge>
          <h1 className="font-display text-5xl font-bold text-white mb-4">Neem Contact Op</h1>
          <p className="text-white/80 text-xl max-w-xl">
            Heeft u vragen? We horen graag van u. Stuur ons een bericht of kom langs bij onze locatie.
          </p>
        </div>
      </section>

      {/* Contact persons per speltak */}
      <section className="py-16 bg-background">
        <div className="container">
          <h2 className="font-display text-3xl font-bold text-foreground mb-10 text-center">
            Contactpersonen per Speltak
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {contactPersons.map((person) => (
              <Card key={person.speltak} className="border border-border overflow-hidden">
                {person.photo ? (
                  <div className="h-56 overflow-hidden bg-muted">
                    <img
                      src={person.photo}
                      alt={person.name}
                      className="w-full h-full object-cover object-top"
                    />
                  </div>
                ) : (
                  <div className="h-56 bg-primary/10 flex items-center justify-center">
                    <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center">
                      <span className="text-primary font-display font-bold text-2xl">
                        {person.name.charAt(0)}
                      </span>
                    </div>
                  </div>
                )}
                <CardContent className="p-5">
                  <Badge className="mb-2 bg-primary/10 text-primary border-primary/20 text-xs">
                    {person.speltak}
                  </Badge>
                  <h3 className="font-display font-bold text-foreground mb-1">{person.name}</h3>
                  <a
                    href={`mailto:${person.email}`}
                    className="text-sm text-primary hover:underline flex items-center gap-1.5"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    {person.email}
                  </a>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Social media */}
          <div className="mt-12 text-center">
            <p className="text-muted-foreground mb-4 text-lg">
              Volg onze groep ook op Facebook en Instagram!
            </p>
            <div className="flex justify-center gap-4">
              <a
                href="https://www.facebook.com/GabrielGroep/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#1877F2] text-white font-medium hover:bg-[#1877F2]/90 transition-colors"
              >
                <Facebook className="w-4 h-4" />
                Facebook
              </a>
              <a
                href="https://www.instagram.com/gabrielzeeverkenners/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#FCB045] text-white font-medium hover:opacity-90 transition-opacity"
              >
                <Instagram className="w-4 h-4" />
                Instagram
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Location + Form */}
      <section className="py-16 bg-muted/30">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            {/* Contact Info */}
            <div className="space-y-6">
              <div>
                <h2 className="font-display text-2xl font-bold text-foreground mb-6">Locatie & Info</h2>
                <div className="space-y-4">
                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                      <MapPin className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <div className="font-semibold text-sm text-foreground">Adres</div>
                      <div className="text-muted-foreground text-sm">
                        Witteweg 23M<br />
                        6587 AJ Middelaar
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                      <Mail className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <div className="font-semibold text-sm text-foreground">E-mail</div>
                      <a href="mailto:info@gabrielgroep.nl" className="text-muted-foreground text-sm hover:text-primary transition-colors">
                        info@gabrielgroep.nl
                      </a>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                      <Clock className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <div className="font-semibold text-sm text-foreground">Beschikbaarheid</div>
                      <div className="text-muted-foreground text-sm">
                        Zaterdag: 10:00 – 17:00
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Map */}
              <div className="rounded-xl overflow-hidden border border-border h-64">
                <MapView
                  onMapReady={(map) => {
                    // Witteweg 23M, 6587 AJ Middelaar
                    const locatie = { lat: 51.7289, lng: 5.9179 };
                    map.setCenter(locatie);
                    map.setZoom(15);
                    new google.maps.Marker({
                      position: locatie,
                      map,
                      title: "Gabriël Groep – Witteweg 23M, Middelaar",
                    });
                  }}
                />
              </div>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2">
              <Card className="border border-border shadow-sm">
                <CardContent className="p-8">
                  {submitted ? (
                    <div className="text-center py-10">
                      <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                        <CheckCircle2 className="w-8 h-8 text-green-600" />
                      </div>
                      <h3 className="font-display text-2xl font-bold text-foreground mb-3">
                        Bericht Ontvangen!
                      </h3>
                      <p className="text-muted-foreground mb-6">
                        Bedankt voor uw bericht. We nemen zo snel mogelijk contact met u op.
                      </p>
                      <Button onClick={() => setSubmitted(false)} variant="outline">
                        Nieuw bericht sturen
                      </Button>
                    </div>
                  ) : (
                    <>
                      <h2 className="font-display text-2xl font-bold text-foreground mb-6">
                        Stuur ons een bericht
                      </h2>
                      <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                          <div>
                            <Label htmlFor="name">Naam *</Label>
                            <Input id="name" {...register("name")} placeholder="Uw naam" className="mt-1.5" />
                            {errors.name && <p className="text-destructive text-xs mt-1">{errors.name.message}</p>}
                          </div>
                          <div>
                            <Label htmlFor="email">E-mailadres *</Label>
                            <Input id="email" type="email" {...register("email")} placeholder="naam@voorbeeld.nl" className="mt-1.5" />
                            {errors.email && <p className="text-destructive text-xs mt-1">{errors.email.message}</p>}
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="subject">Onderwerp</Label>
                          <Input id="subject" {...register("subject")} placeholder="Waar gaat uw bericht over?" className="mt-1.5" />
                        </div>
                        <div>
                          <Label htmlFor="message">Bericht *</Label>
                          <Textarea
                            id="message"
                            {...register("message")}
                            placeholder="Schrijf hier uw bericht..."
                            className="mt-1.5 resize-none"
                            rows={6}
                          />
                          {errors.message && <p className="text-destructive text-xs mt-1">{errors.message.message}</p>}
                        </div>
                        <div className="p-3 bg-muted/50 rounded-lg">
                          <p className="text-xs text-muted-foreground">
                            Door dit formulier te verzenden gaat u akkoord met onze{" "}
                            <a href="/over-ons" className="text-primary underline">privacyverklaring</a>.
                            Uw gegevens worden uitsluitend gebruikt om uw vraag te beantwoorden.
                          </p>
                        </div>
                        <Button type="submit" className="w-full" size="lg" disabled={submitMutation.isPending}>
                          {submitMutation.isPending ? "Versturen..." : "Bericht Versturen"}
                        </Button>
                      </form>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
