import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { Calendar, MapPin, Users, Waves, Award } from "lucide-react";
import PublicLayout from "@/components/PublicLayout";
import AdminPhotoUpload from "@/components/AdminPhotoUpload";
import { trpc } from "@/lib/trpc";

const MOOKSE_ALBUM_ID = 9;

export default function MookseZeilweek() {
  const { data: photos, refetch: refetchPhotos } = trpc.photos.getPhotos.useQuery({ albumId: MOOKSE_ALBUM_ID });
  const [lightboxSrc, setLightboxSrc] = useState<string | null>(null);

  const highlights = [
    {
      icon: Waves,
      title: "Zeezeilen",
      desc: "Vier dagen intensief zeezeilen op de Waddenzee met ervaren instructeurs.",
    },
    {
      icon: Users,
      title: "Groepsgeest",
      desc: "Sterke teambuilding en vriendschappen die een leven lang meegaan.",
    },
    {
      icon: Award,
      title: "Vaardigheden",
      desc: "Leer geavanceerde zeilvaardigheden en seamanship in een veilige omgeving.",
    },
    {
      icon: MapPin,
      title: "Avontuur",
      desc: "Verken de Waddenzee en ontdek nieuwe plaatsen met je groep.",
    },
  ];

  const schedule = [
    {
      day: "Dag 1",
      title: "Aankomst & Voorbereiding",
      desc: "Aankomst op de haven, boot voorbereiding en eerste instructie.",
    },
    {
      day: "Dag 2",
      title: "Zeezeilen",
      desc: "Eerste dag op open water. Leer de basis van zeezeilen.",
    },
    {
      day: "Dag 3",
      title: "Avontuur",
      desc: "Langere tocht met meer geavanceerde technieken.",
    },
    {
      day: "Dag 4",
      title: "Afsluiting",
      desc: "Laatste dag op het water en groepsfeest ter afsluiting.",
    },
  ];

  return (
    <PublicLayout>
      {/* Hero */}
      <section className="relative pt-32 pb-20 bg-gradient-to-br from-primary via-primary to-accent overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-white transform translate-x-1/3 -translate-y-1/3" />
          <div className="absolute bottom-0 left-0 w-96 h-96 rounded-full bg-white transform -translate-x-1/3 translate-y-1/3" />
        </div>
        <div className="relative container">
          <Badge className="bg-white/20 text-white border-white/30 mb-5">Jaarlijkse Hoogtepunt</Badge>
          <h1 className="font-display text-6xl font-bold text-white mb-6 max-w-2xl">
            Mookse Zeilweek
          </h1>
          <p className="text-white/90 text-xl max-w-xl mb-8 leading-relaxed">
            De ultieme zeilervaring voor onze Wilde Vaart. Vier dagen intensief zeezeilen op de Waddenzee met vrienden en instructeurs.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link href="/lid-worden">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90">
                Meld je aan
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
              Meer informatie
            </Button>
          </div>
        </div>
      </section>

      {/* Key Info */}
      <section className="py-16 bg-background">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-8 h-8 text-primary" />
              </div>
              <h3 className="font-display font-bold text-foreground mb-2">Wanneer</h3>
              <p className="text-muted-foreground">Jaarlijks in juli</p>
              <p className="text-sm text-muted-foreground">4 dagen intensief zeilen</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-8 h-8 text-accent" />
              </div>
              <h3 className="font-display font-bold text-foreground mb-2">Waar</h3>
              <p className="text-muted-foreground">Waddenzee</p>
              <p className="text-sm text-muted-foreground">Harlingen / Den Helder</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-primary" />
              </div>
              <h3 className="font-display font-bold text-foreground mb-2">Voor wie</h3>
              <p className="text-muted-foreground">Wilde Vaart (16-18 jaar)</p>
              <p className="text-sm text-muted-foreground">Minimaal 1 jaar ervaring</p>
            </div>
          </div>
        </div>
      </section>

      {/* Highlights */}
      <section className="py-16 bg-muted/30">
        <div className="container">
          <h2 className="font-display text-4xl font-bold text-foreground mb-12 text-center">
            Wat je kan verwachten
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {highlights.map((item, i) => {
              const Icon = item.icon;
              return (
                <Card key={i} className="card-hover border border-border">
                  <CardContent className="p-6">
                    <div className="flex gap-4">
                      <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Icon className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-display font-bold text-foreground mb-2">
                          {item.title}
                        </h3>
                        <p className="text-muted-foreground text-sm leading-relaxed">
                          {item.desc}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Schedule */}
      <section className="py-16 bg-background">
        <div className="container">
          <h2 className="font-display text-4xl font-bold text-foreground mb-12 text-center">
            Programma
          </h2>
          <div className="max-w-3xl mx-auto">
            <div className="space-y-6">
              {schedule.map((item, i) => (
                <div key={i} className="flex gap-6">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="font-display font-bold text-primary text-sm">
                        {i + 1}
                      </span>
                    </div>
                  </div>
                  <div className="flex-1 pt-1">
                    <h3 className="font-display font-bold text-foreground mb-1">
                      {item.day}: {item.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {item.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Photos Gallery */}
      <section className="py-16 bg-muted/30">
        <div className="container">
          <div className="flex items-center justify-between mb-12">
            <h2 className="font-display text-4xl font-bold text-foreground">
              Foto's van vorige jaren
            </h2>
            <AdminPhotoUpload
              albumId={MOOKSE_ALBUM_ID}
              albumTitle="Mookse Zeilweek"
              onUploadSuccess={() => refetchPhotos()}
            />
          </div>
          {photos && photos.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {photos.map((photo: any) => (
                <div
                  key={photo.id}
                  className="aspect-video bg-muted rounded-lg overflow-hidden group cursor-pointer"
                  onClick={() => setLightboxSrc(photo.url)}
                >
                  <img
                    src={photo.url}
                    alt={photo.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 text-muted-foreground">
              <p className="text-lg">Nog geen foto's toegevoegd.</p>
              <p className="text-sm mt-1">Log in als admin om foto's te uploaden.</p>
            </div>
          )}
        </div>
      </section>

      {/* Lightbox */}
      {lightboxSrc && (
        <div
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          onClick={() => setLightboxSrc(null)}
        >
          <img
            src={lightboxSrc}
            alt="Foto"
            className="max-w-full max-h-full rounded-lg shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}

      {/* CTA */}
      <section className="py-20 bg-primary overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-white transform translate-x-1/3 -translate-y-1/3" />
        </div>
        <div className="relative container text-center">
          <h2 className="font-display text-4xl font-bold text-white mb-4">
            Klaar voor het avontuur?
          </h2>
          <p className="text-white/80 text-lg mb-8 max-w-xl mx-auto">
            Meld je aan voor de Mookse Zeilweek en maak deel uit van een onvergetelijke ervaring.
          </p>
          <Link href="/lid-worden">
            <Button size="lg" className="bg-white text-primary hover:bg-white/90">
              Aanmelden
            </Button>
          </Link>
        </div>
      </section>
    </PublicLayout>
  );
}
