import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

// Public pages
import Home from "./pages/Home";
import OverOns from "./pages/OverOns";
import LidWorden from "./pages/LidWorden";
import Nieuws from "./pages/Nieuws";
import Contact from "./pages/Contact";
import Agenda from "./pages/Agenda";
import Fotos from "./pages/Fotos";
import Verhuur from "./pages/Verhuur";
import DeVloot from "./pages/DeVloot";
import MookseZeilweek from "./pages/MookseZeilweek";
import Vertrouwenspersoon from "./pages/Vertrouwenspersoon";
import AdminInzendingen from "./pages/portaal/AdminInzendingen";
import StafAanmeldingen from "./pages/portaal/StafAanmeldingen";
import StafFotos from "./pages/portaal/StafFotos";
import AdminFotos from "./pages/portaal/AdminFotos";
import AdminVerhuurAgenda from "./pages/portaal/AdminVerhuurAgenda";

// Portal layout + pages
import PortaalLayout from "./components/PortaalLayout";
import PortaalDashboard from "./pages/portaal/PortaalDashboard";
import PortaalAgenda from "./pages/portaal/PortaalAgenda";
import PortaalDocumenten from "./pages/portaal/PortaalDocumenten";
import PortaalNieuws from "./pages/portaal/PortaalNieuws";

// Staff pages
import StafDashboard from "./pages/portaal/StafDashboard";
import StafLeden from "./pages/portaal/StafLeden";
import StafActiviteiten from "./pages/portaal/StafActiviteiten";
import StafInventaris from "./pages/portaal/StafInventaris";

// Admin pages
import AdminDashboard from "./pages/portaal/AdminDashboard";
import AdminNieuws from "./pages/portaal/AdminNieuws";
import AdminGebruikers from "./pages/portaal/AdminGebruikers";

function PortaalRoute({ component: Component }: { component: React.ComponentType }) {
  return (
    <PortaalLayout>
      <Component />
    </PortaalLayout>
  );
}

function Router() {
  return (
    <Switch>
      {/* Public website */}
      <Route path="/" component={Home} />
      <Route path="/over-ons" component={OverOns} />
      <Route path="/lid-worden" component={LidWorden} />
      <Route path="/nieuws" component={Nieuws} />
      <Route path="/contact" component={Contact} />
      <Route path="/agenda" component={Agenda} />
      <Route path="/fotos" component={Fotos} />
      <Route path="/verhuur" component={Verhuur} />
      <Route path="/de-vloot" component={DeVloot} />
      <Route path="/mookse-zeilweek" component={MookseZeilweek} />
      <Route path="/vertrouwenspersoon" component={Vertrouwenspersoon} />

      {/* Member portal */}
      <Route path="/portaal">
        {() => <PortaalRoute component={PortaalDashboard} />}
      </Route>
      <Route path="/portaal/agenda">
        {() => <PortaalRoute component={PortaalAgenda} />}
      </Route>
      <Route path="/portaal/documenten">
        {() => <PortaalRoute component={PortaalDocumenten} />}
      </Route>
      <Route path="/portaal/nieuws">
        {() => <PortaalRoute component={PortaalNieuws} />}
      </Route>

      {/* Staff portal */}
      <Route path="/portaal/staf">
        {() => <PortaalRoute component={StafDashboard} />}
      </Route>
      <Route path="/portaal/staf/leden">
        {() => <PortaalRoute component={StafLeden} />}
      </Route>
      <Route path="/portaal/staf/activiteiten">
        {() => <PortaalRoute component={StafActiviteiten} />}
      </Route>
      <Route path="/portaal/staf/inventaris">
        {() => <PortaalRoute component={StafInventaris} />}
      </Route>
      <Route path="/portaal/staf/aanmeldingen">
        {() => <PortaalRoute component={StafAanmeldingen} />}
      </Route>
      <Route path="/portaal/staf/fotos">
        {() => <PortaalRoute component={StafFotos} />}
      </Route>

      {/* Admin portal */}
      <Route path="/portaal/admin">
        {() => <PortaalRoute component={AdminDashboard} />}
      </Route>
      <Route path="/portaal/admin/nieuws">
        {() => <PortaalRoute component={AdminNieuws} />}
      </Route>
      <Route path="/portaal/admin/gebruikers">
        {() => <PortaalRoute component={AdminGebruikers} />}
      </Route>
      <Route path="/portaal/admin/inzendingen">
        {() => <PortaalRoute component={AdminInzendingen} />}
      </Route>
      <Route path="/portaal/admin/fotos">
        {() => <PortaalRoute component={AdminFotos} />}
      </Route>
      <Route path="/portaal/admin/verhuur-agenda">
        {() => <PortaalRoute component={AdminVerhuurAgenda} />}
      </Route>
      <Route path="/404" component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
