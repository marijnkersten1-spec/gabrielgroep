export const SPELTAK_LABELS: Record<string, string> = {
  dolfijnen: "Dolfijnen",
  verkenners: "Verkenners",
  wilde_vaart: "Wilde Vaart",
  staf: "Staf",
  all: "Alle speltakken",
};

export const SPELTAK_AGES: Record<string, string> = {
  dolfijnen: "7–10 jaar",
  verkenners: "11–15 jaar",
  wilde_vaart: "16–18 jaar",
  staf: "18+ jaar",
};

export const SPELTAK_COLORS: Record<string, string> = {
  dolfijnen: "badge-dolfijnen",
  verkenners: "badge-verkenners",
  wilde_vaart: "badge-wilde-vaart",
  staf: "badge-staf",
  all: "badge-all",
};

export const SPELTAK_DESCRIPTIONS: Record<string, string> = {
  dolfijnen: "Onze jongste zeilers leren de basis van het water en scouting.",
  verkenners: "Avontuurlijke tieners die zeilen, kamperen en de natuur verkennen.",
  wilde_vaart: "Oudere scouts die zelfstandig varen en grote avonturen beleven.",
  staf: "Onze gedreven vrijwilligers die alles mogelijk maken.",
};

export const EVENT_TYPE_LABELS: Record<string, string> = {
  activity: "Activiteit",
  camp: "Kamp",
  meeting: "Vergadering",
  training: "Training",
  rental: "Verhuur",
  other: "Overig",
};

export const EQUIPMENT_CATEGORY_LABELS: Record<string, string> = {
  boat: "Boot",
  sail: "Zeil",
  safety: "Veiligheid",
  camping: "Kampeer",
  navigation: "Navigatie",
  other: "Overig",
};

export const EQUIPMENT_STATUS_LABELS: Record<string, string> = {
  available: "Beschikbaar",
  in_use: "In gebruik",
  maintenance: "Onderhoud",
  retired: "Afgeschreven",
};

export const DOCUMENT_CATEGORY_LABELS: Record<string, string> = {
  form: "Formulier",
  medical: "Medisch",
  activity_plan: "Activiteitenplan",
  boat_maintenance: "Bootsonderhoud",
  general: "Algemeen",
};

export const CDN = {
  heroSailing: "https://tse4.mm.bing.net/th/id/OIP.yFCBHYqhBv3XdrKEOhQS6gHaDa?rs=1&pid=ImgDetMain&o=7&rm=3",
  sailingYouth: "https://d2xsxph8kpxj0f.cloudfront.net/310519663467900671/auFutdbkCM7YzmFQQVZLdc/sailing-youth_847f691e.jpg",
  scoutSailing: "https://www.gabrielgroep.nl/wp-content/uploads/elementor/thumbs/dolfijnen-foto-6-1-pvh4hmi1a4c7yq7yxhvh5mn959qzppcueo2rn0u9zs.jpeg",
};
