import { Link } from "wouter";
import { Anchor, Mail, MapPin, Facebook, Instagram } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-9 h-9 rounded-full bg-white/15 flex items-center justify-center">
                <Anchor className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="font-display font-bold text-white text-base leading-none">Gabriël Groep</div>
                <div className="text-white/60 text-xs mt-0.5">Zeeverkenners</div>
              </div>
            </div>
            <p className="text-white/70 text-sm leading-relaxed">
              Een waterscoutinggroep in Middelaar, Nederland. Zeilen, kamperen en avontuur voor jeugd van 7 tot 18 jaar.
            </p>
            <div className="flex gap-3 mt-5">
              <a href="https://www.facebook.com/GabrielGroep/?ref=NONE_xav_ig_profile_page_web#" target="_blank" rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
                <Facebook className="w-4 h-4 text-white" />
              </a>
              <a href="https://www.instagram.com/gabrielzeeverkenners/" target="_blank" rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
                <Instagram className="w-4 h-4 text-white" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-display font-semibold text-white mb-4">Navigatie</h4>
            <ul className="space-y-2.5">
              {[
                { href: "/", label: "Home" },
                { href: "/over-ons", label: "Over Ons" },
                { href: "/agenda", label: "Agenda" },
                { href: "/nieuws", label: "Nieuws" },
                { href: "/fotos", label: "Foto's" },
                { href: "/contact", label: "Contact" },
              ].map((link) => (
                <li key={link.href}>
                  <Link href={link.href}>
                    <span className="text-white/70 hover:text-white text-sm transition-colors cursor-pointer">
                      {link.label}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Speltakken */}
          <div>
            <h4 className="font-display font-semibold text-white mb-4">Speltakken</h4>
            <ul className="space-y-2.5">
              <li>
                <Link href="/over-ons#dolfijnen">
                  <span className="text-white/70 hover:text-white text-sm transition-colors cursor-pointer">
                    🐬 Dolfijnen (7–10 jaar)
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/over-ons#verkenners">
                  <span className="text-white/70 hover:text-white text-sm transition-colors cursor-pointer">
                    🧭 Verkenners (11–15 jaar)
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/over-ons#wilde-vaart">
                  <span className="text-white/70 hover:text-white text-sm transition-colors cursor-pointer">
                    ⚓ Wilde Vaart (16–18 jaar)
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/lid-worden">
                  <span className="text-white/70 hover:text-white text-sm transition-colors cursor-pointer">
                    Lid Worden
                  </span>
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display font-semibold text-white mb-4">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-accent mt-0.5 shrink-0" />
                <span className="text-white/70 text-sm">Witteweg 23M<br />6587 AJ Middelaar</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-accent shrink-0" />
                <a href="mailto:info@gabrielgroep.nl" className="text-white/70 hover:text-white text-sm transition-colors">
                  info@gabrielgroep.nl
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/10">
        <div className="container py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-white/50 text-xs">
            © {new Date().getFullYear()} Gabriël Groep Zeeverkenners. Alle rechten voorbehouden.
          </p>
          <div className="flex gap-4">
            <Link href="/over-ons">
              <span className="text-white/50 hover:text-white/80 text-xs transition-colors cursor-pointer">Privacyverklaring</span>
            </Link>
            <Link href="/vertrouwenspersoon">
              <span className="text-white/50 hover:text-white/80 text-xs transition-colors cursor-pointer">Vertrouwenspersoon</span>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
