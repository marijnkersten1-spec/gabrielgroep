import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, Anchor, X } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";

const navLinks = [
  { href: "/", label: "Home" },
  { href: "/over-ons", label: "Over Ons" },
  { href: "/agenda", label: "Agenda" },
  { href: "/nieuws", label: "Nieuws" },
  { href: "/fotos", label: "Foto's" },
  { href: "/verhuur", label: "Verhuur" },
  { href: "/de-vloot", label: "De Vloot" },
  { href: "/mookse-zeilweek", label: "Mookse Zeilweek" },
  { href: "/vertrouwenspersoon", label: "Vertrouwenspersoon" },
  { href: "/contact", label: "Contact" },
];

export default function Navbar() {
  const [location] = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const { user, isAuthenticated } = useAuth();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const isHome = location === "/";
  const transparent = isHome && !scrolled;

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        transparent
          ? "bg-transparent"
          : "bg-white/95 backdrop-blur-md shadow-sm border-b border-border"
      }`}
    >
      <div className="container">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2.5 group">
            <div className={`w-9 h-9 rounded-full flex items-center justify-center transition-colors ${
              transparent ? "bg-white/20" : "bg-primary"
            }`}>
              <Anchor className={`w-5 h-5 ${transparent ? "text-white" : "text-primary-foreground"}`} />
            </div>
            <div className="leading-tight">
              <div className={`font-display font-bold text-base leading-none ${transparent ? "text-white" : "text-primary"}`}>
                Gabriël Groep
              </div>
              <div className={`text-xs leading-none mt-0.5 ${transparent ? "text-white/70" : "text-muted-foreground"}`}>
                Zeeverkenners
              </div>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <span
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors cursor-pointer ${
                    location === link.href
                      ? transparent
                        ? "bg-white/20 text-white"
                        : "bg-primary/10 text-primary"
                      : transparent
                      ? "text-white/90 hover:text-white hover:bg-white/10"
                      : "text-foreground/70 hover:text-foreground hover:bg-muted"
                  }`}
                >
                  {link.label}
                </span>
              </Link>
            ))}
          </nav>

          {/* CTA */}
          <div className="hidden md:flex items-center gap-3">
            {isAuthenticated ? (
              <Link href="/portaal">
                <Button
                  size="sm"
                  variant={transparent ? "outline" : "default"}
                  className={transparent ? "border-white text-white hover:bg-white hover:text-primary" : ""}
                >
                  Mijn Portaal
                </Button>
              </Link>
            ) : (
              <>
                <a href={getLoginUrl()}>
                  <Button
                    size="sm"
                    variant="ghost"
                    className={transparent ? "text-white hover:bg-white/10" : ""}
                  >
                    Inloggen
                  </Button>
                </a>
                <Link href="/lid-worden">
                  <Button
                    size="sm"
                    className={transparent ? "bg-white text-primary hover:bg-white/90" : "bg-accent text-accent-foreground hover:bg-accent/90"}
                  >
                    Lid Worden
                  </Button>
                </Link>
              </>
            )}
          </div>

          {/* Mobile Menu */}
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className={`md:hidden ${transparent ? "text-white hover:bg-white/10" : ""}`}
              >
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72 p-0">
              <div className="flex flex-col h-full">
                <div className="flex items-center justify-between p-5 border-b">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
                      <Anchor className="w-4 h-4 text-primary-foreground" />
                    </div>
                    <span className="font-display font-bold text-primary">Gabriël Groep</span>
                  </div>
                </div>
                <nav className="flex-1 p-4 space-y-1">
                  {navLinks.map((link) => (
                    <Link key={link.href} href={link.href}>
                      <span
                        onClick={() => setMobileOpen(false)}
                        className={`flex items-center px-4 py-3 rounded-lg text-sm font-medium cursor-pointer transition-colors ${
                          location === link.href
                            ? "bg-primary/10 text-primary"
                            : "text-foreground/70 hover:text-foreground hover:bg-muted"
                        }`}
                      >
                        {link.label}
                      </span>
                    </Link>
                  ))}
                </nav>
                <div className="p-4 border-t space-y-2">
                  {isAuthenticated ? (
                    <Link href="/portaal">
                      <Button className="w-full" onClick={() => setMobileOpen(false)}>
                        Mijn Portaal
                      </Button>
                    </Link>
                  ) : (
                    <>
                      <a href={getLoginUrl()} className="block">
                        <Button variant="outline" className="w-full">Inloggen</Button>
                      </a>
                      <Link href="/lid-worden">
                        <Button className="w-full bg-accent text-accent-foreground hover:bg-accent/90" onClick={() => setMobileOpen(false)}>
                          Lid Worden
                        </Button>
                      </Link>
                    </>
                  )}
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
