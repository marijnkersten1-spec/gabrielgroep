import { SPELTAK_LABELS, SPELTAK_COLORS } from "@/lib/constants";

interface SpeltakBadgeProps {
  speltak: string;
  size?: "sm" | "md";
}

export default function SpeltakBadge({ speltak, size = "md" }: SpeltakBadgeProps) {
  const label = SPELTAK_LABELS[speltak] ?? speltak;
  const colorClass = SPELTAK_COLORS[speltak] ?? "badge-all";

  return (
    <span
      className={`inline-flex items-center rounded-full font-medium ${colorClass} ${
        size === "sm" ? "px-2 py-0.5 text-xs" : "px-3 py-1 text-xs"
      }`}
    >
      {label}
    </span>
  );
}
