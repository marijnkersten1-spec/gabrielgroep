import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  Anchor, LayoutDashboard, Calendar, FileText, Newspaper, Settings,
  LogOut, Menu, X, Users, Wrench, ShieldCheck, ChevronRight, Image, ClipboardList, Mail, Building2
} from "lucide-react";
import { SPELTAK_LABELS } from "@/lib/constants";

interface NavItem {
  href: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  roles?: string[];
}

const memberNav: NavItem[] = [
  { href: "/portaal", label: "Dashboard", icon: LayoutDashboard },
  { href: "/portaal/agenda", label: "Agenda", icon: Calendar },
  { href: "/portaal/documenten", label: "Documenten", icon: FileText },
  { href: "/portaal/nieuws", label: "Nieuws", icon: Newspaper },
];

const staffNav: NavItem[] = [
  { href: "/portaal/staf", label: "Staf Dashboard", icon: Wrench, roles: ["staff", "admin"] },
  { href: "/portaal/staf/leden", label: "Leden", icon: Users, roles: ["staff", "admin"] },
  { href: "/portaal/staf/activiteiten", label: "Activiteiten", icon: Calendar, roles: ["staff", "admin"] },
  { href: "/portaal/staf/inventaris", label: "Inventaris", icon: Wrench, roles: ["staff", "admin"] },
  { href: "/portaal/staf/aanmeldingen", label: "Aanmeldingen", icon: ClipboardList, roles: ["staff", "admin"] },
  { href: "/portaal/staf/fotos", label: "Foto's Beheer", icon: Image, roles: ["staff", "admin"] },
];

const adminNav: NavItem[] = [
  { href: "/portaal/admin", label: "Admin Panel", icon: ShieldCheck, roles: ["admin"] },
  { href: "/portaal/admin/nieuws", label: "Nieuws Beheer", icon: Newspaper, roles: ["admin"] },
  { href: "/portaal/admin/gebruikers", label: "Gebruikers", icon: Users, roles: ["admin"] },
  { href: "/portaal/admin/inzendingen", label: "Inzendingen", icon: Mail, roles: ["admin"] },
  { href: "/portaal/admin/fotos", label: "Foto Albums", icon: Image, roles: ["admin"] },
  { href: "/portaal/admin/verhuur-agenda", label: "Verhuur Agenda", icon: Building2, roles: ["admin"] },
];

interface PortaalLayoutProps {
  children: React.ReactNode;
}

export default function PortaalLayout({ children }: PortaalLayoutProps) {
  const [location] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user } = useAuth();
  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => { window.location.href = "/"; },
    onError: () => toast.error("Uitloggen mislukt"),
  });

  const isStaff = user?.role === "staff" || user?.role === "admin";
  const isAdmin = user?.role === "admin";

  const navSections = [
    { title: "Mijn Portaal", items: memberNav },
    ...(isStaff ? [{ title: "Staf", items: staffNav }] : []),
    ...(isAdmin ? [{ title: "Admin", items: adminNav }] : []),
  ];

  const Sidebar = () => (
    <div className="flex flex-col h-full bg-sidebar text-sidebar-foreground">
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-5 py-5 border-b border-sidebar-border">
        <div className="w-8 h-8 rounded-full bg-white/15 flex items-center justify-center">
          <Anchor className="w-4 h-4 text-white" />
        </div>
        <div>
          <div className="font-display font-bold text-white text-sm leading-none">Gabriël Groep</div>
          <div className="text-white/50 text-xs mt-0.5">Portaal</div>
        </div>
      </div>

      {/* User info */}
      <div className="px-4 py-4 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <Avatar className="w-9 h-9">
            <AvatarFallback className="bg-white/15 text-white text-sm">
              {user?.name?.charAt(0)?.toUpperCase() ?? "?"}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <div className="text-white text-sm font-medium truncate">{user?.name ?? "Gebruiker"}</div>
            <div className="text-white/50 text-xs truncate">
              {user?.speltak ? SPELTAK_LABELS[user.speltak] : user?.role === "admin" ? "Admin" : user?.role === "staff" ? "Staf" : "Lid"}
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-5">
        {navSections.map((section) => (
          <div key={section.title}>
            <div className="text-white/40 text-xs font-semibold uppercase tracking-wider px-3 mb-2">
              {section.title}
            </div>
            <div className="space-y-0.5">
              {section.items.map((item) => {
                const active = location === item.href || (item.href !== "/portaal" && location.startsWith(item.href));
                return (
                  <Link key={item.href} href={item.href}>
                    <span
                      onClick={() => setSidebarOpen(false)}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm cursor-pointer transition-colors ${
                        active
                          ? "bg-sidebar-accent text-white font-medium"
                          : "text-white/70 hover:text-white hover:bg-white/10"
                      }`}
                    >
                      <item.icon className="w-4 h-4 shrink-0" />
                      {item.label}
                      {active && <ChevronRight className="w-3 h-3 ml-auto opacity-60" />}
                    </span>
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-sidebar-border space-y-1">
        <Link href="/">
          <span className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-white/60 hover:text-white hover:bg-white/10 cursor-pointer transition-colors">
            <Anchor className="w-4 h-4" />
            Publieke Website
          </span>
        </Link>
        <button
          onClick={() => logoutMutation.mutate()}
          className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-white/60 hover:text-white hover:bg-white/10 cursor-pointer transition-colors w-full text-left"
        >
          <LogOut className="w-4 h-4" />
          Uitloggen
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 shrink-0 flex-col border-r border-border">
        <Sidebar />
      </aside>

      {/* Mobile Sidebar */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
          <aside className="absolute left-0 top-0 bottom-0 w-64 flex flex-col">
            <Sidebar />
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile header */}
        <header className="lg:hidden flex items-center gap-3 px-4 py-3 border-b border-border bg-white">
          <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(true)}>
            <Menu className="w-5 h-5" />
          </Button>
          <div className="flex items-center gap-2">
            <Anchor className="w-4 h-4 text-primary" />
            <span className="font-display font-bold text-primary text-sm">Gabriël Groep Portaal</span>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
