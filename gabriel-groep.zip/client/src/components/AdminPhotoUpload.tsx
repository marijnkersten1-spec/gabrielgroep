import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { Upload, Loader2, Plus } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";

interface AdminPhotoUploadProps {
  albumId: number;
  albumTitle: string;
  onUploadSuccess?: () => void;
}

export default function AdminPhotoUpload({
  albumId,
  albumTitle,
  onUploadSuccess,
}: AdminPhotoUploadProps) {
  const { user } = useAuth();
  const [uploadDialog, setUploadDialog] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [photoTitle, setPhotoTitle] = useState("");
  const [uploading, setUploading] = useState(false);

  // Only show upload button if user is admin
  const isAdmin = user?.role === "admin";

  const uploadMutation = trpc.photos.uploadPhoto.useMutation({
    onSuccess: () => {
      toast.success("Foto geupload!");
      setUploadDialog(false);
      setSelectedFile(null);
      setPhotoTitle("");
      setUploading(false);
      onUploadSuccess?.();
    },
    onError: (error) => {
      toast.error(error.message || "Fout bij uploaden");
      setUploading(false);
    },
  });

  const handleUpload = async () => {
    if (!selectedFile || !photoTitle) {
      toast.error("Selecteer een foto en voer een titel in");
      return;
    }

    setUploading(true);
    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64 = e.target?.result as string;
      const base64Data = base64.split(",")[1] || base64;
      uploadMutation.mutate({
        albumId,
        title: photoTitle,
        fileData: base64Data,
        fileName: selectedFile.name,
        mimeType: selectedFile.type,
        isPublic: true,
      });
    };
    reader.readAsDataURL(selectedFile);
  };

  if (!isAdmin) return null;

  return (
    <>
      <Button
        onClick={() => setUploadDialog(true)}
        size="sm"
        className="bg-green-600 hover:bg-green-700"
      >
        <Plus className="w-4 h-4 mr-2" />
        Foto Toevoegen
      </Button>

      <Dialog open={uploadDialog} onOpenChange={setUploadDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Foto Uploaden naar {albumTitle}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="photo-title">Titel</Label>
              <Input
                id="photo-title"
                placeholder="Bijv. Groepsfoto"
                value={photoTitle}
                onChange={(e) => setPhotoTitle(e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="photo-file">Foto</Label>
              <div
                className="border-2 border-dashed border-border rounded-lg p-6 text-center cursor-pointer hover:border-primary transition-colors"
                onClick={() => document.getElementById("photo-file")?.click()}
              >
                {selectedFile ? (
                  <div>
                    <Upload className="w-8 h-8 text-primary mx-auto mb-2" />
                    <p className="font-medium text-foreground">{selectedFile.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                ) : (
                  <div>
                    <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                    <p className="font-medium text-foreground">Klik om foto te selecteren</p>
                    <p className="text-xs text-muted-foreground">PNG, JPG, GIF tot 10MB</p>
                  </div>
                )}
                <input
                  id="photo-file"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                />
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => {
                  setUploadDialog(false);
                  setSelectedFile(null);
                  setPhotoTitle("");
                }}
              >
                Annuleren
              </Button>
              <Button
                onClick={handleUpload}
                disabled={uploading || !selectedFile || !photoTitle}
                className="flex-1"
              >
                {uploading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Uploaden...
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4 mr-2" />
                    Uploaden
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
