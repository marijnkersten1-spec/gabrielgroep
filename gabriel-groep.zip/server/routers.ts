import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { notifyOwner } from "./_core/notification";
import { storagePut } from "./storage";
import * as db from "./db";

// ─── Admin guard ─────────────────────────────────────────────────────────────

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  return next({ ctx });
});

const staffProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin" && ctx.user.role !== "staff") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Staff access required" });
  }
  return next({ ctx });
});

// ─── App Router ───────────────────────────────────────────────────────────────

export const appRouter = router({
  system: systemRouter,

  // ── Auth ──────────────────────────────────────────────────────────────────
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ── Events ────────────────────────────────────────────────────────────────
  events: router({
    listPublic: publicProcedure
      .input(z.object({ from: z.date().optional(), to: z.date().optional() }).optional())
      .query(({ input }) => db.getPublicEvents(input?.from, input?.to)),

    list: protectedProcedure
      .input(z.object({ speltak: z.string().optional(), type: z.string().optional() }).optional())
      .query(({ input }) => db.getAllEvents(input?.speltak, input?.type)),

    get: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => db.getEventById(input.id)),

    create: staffProcedure
      .input(z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        location: z.string().optional(),
        startDate: z.date(),
        endDate: z.date().optional(),
        isAllDay: z.boolean().default(false),
        speltak: z.enum(["dolfijnen", "verkenners", "wilde_vaart", "staf", "all"]).default("all"),
        type: z.enum(["activity", "camp", "meeting", "training", "rental", "other"]).default("activity"),
        isPublic: z.boolean().default(true),
        maxParticipants: z.number().optional(),
        registrationDeadline: z.date().optional(),
      }))
      .mutation(({ input, ctx }) => db.createEvent({ ...input, createdBy: ctx.user.id })),

    update: staffProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        location: z.string().optional(),
        startDate: z.date().optional(),
        endDate: z.date().optional(),
        speltak: z.enum(["dolfijnen", "verkenners", "wilde_vaart", "staf", "all"]).optional(),
        type: z.enum(["activity", "camp", "meeting", "training", "rental", "other"]).optional(),
        isPublic: z.boolean().optional(),
        maxParticipants: z.number().optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return db.updateEvent(id, data);
      }),

    delete: staffProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deleteEvent(input.id)),

    register: protectedProcedure
      .input(z.object({ eventId: z.number(), notes: z.string().optional() }))
      .mutation(({ input, ctx }) => db.registerForEvent(input.eventId, ctx.user.id, input.notes)),

    cancelRegistration: protectedProcedure
      .input(z.object({ eventId: z.number() }))
      .mutation(({ input, ctx }) => db.cancelRegistration(input.eventId, ctx.user.id)),

    myRegistrations: protectedProcedure
      .query(({ ctx }) => db.getUserRegistrations(ctx.user.id)),

    getRegistrations: staffProcedure
      .input(z.object({ eventId: z.number() }))
      .query(({ input }) => db.getEventRegistrations(input.eventId)),
  }),

  // ── Attendance ────────────────────────────────────────────────────────────
  attendance: router({
    mark: staffProcedure
      .input(z.object({
        eventId: z.number(),
        userId: z.number(),
        present: z.boolean(),
        notes: z.string().optional(),
      }))
      .mutation(({ input, ctx }) =>
        db.markAttendance(input.eventId, input.userId, input.present, ctx.user.id, input.notes)
      ),

    getForEvent: staffProcedure
      .input(z.object({ eventId: z.number() }))
      .query(({ input }) => db.getEventAttendance(input.eventId)),
  }),

  // ── News ──────────────────────────────────────────────────────────────────
  news: router({
    listPublic: publicProcedure.query(() => db.getPublishedNews(true)),

    listAll: protectedProcedure.query(() => db.getPublishedNews()),

    listAdmin: staffProcedure.query(() => db.getAllNews()),

    getBySlug: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(({ input }) => db.getNewsBySlug(input.slug)),

    create: staffProcedure
      .input(z.object({
        title: z.string().min(1),
        slug: z.string().min(1),
        excerpt: z.string().optional(),
        content: z.string().min(1),
        coverImageUrl: z.string().optional(),
        isPublished: z.boolean().default(false),
        isPublic: z.boolean().default(true),
        speltak: z.enum(["dolfijnen", "verkenners", "wilde_vaart", "staf", "all"]).default("all"),
      }))
      .mutation(({ input, ctx }) =>
        db.createNews({
          ...input,
          authorId: ctx.user.id,
          publishedAt: input.isPublished ? new Date() : undefined,
        })
      ),

    update: staffProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        excerpt: z.string().optional(),
        content: z.string().optional(),
        coverImageUrl: z.string().optional(),
        isPublished: z.boolean().optional(),
        isPublic: z.boolean().optional(),
        speltak: z.enum(["dolfijnen", "verkenners", "wilde_vaart", "staf", "all"]).optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...data } = input;
        const updateData: any = { ...data };
        if (data.isPublished) updateData.publishedAt = new Date();
        return db.updateNews(id, updateData);
      }),

    delete: staffProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deleteNews(input.id)),
  }),

  // ── Photos ────────────────────────────────────────────────────────────────
  photos: router({
    listPublicAlbums: publicProcedure.query(() => db.getPublicAlbums()),

    listAllAlbums: protectedProcedure.query(() => db.getAllAlbums()),

    createAlbum: staffProcedure
      .input(z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        isPublic: z.boolean().default(true),
        speltak: z.enum(["dolfijnen", "verkenners", "wilde_vaart", "staf", "all"]).default("all"),
      }))
      .mutation(({ input, ctx }) => db.createAlbum({ ...input, createdBy: ctx.user.id })),

    getPhotos: publicProcedure
      .input(z.object({ albumId: z.number() }))
      .query(({ input }) => db.getPhotosByAlbum(input.albumId)),

    uploadPhoto: staffProcedure
      .input(z.object({
        albumId: z.number().optional(),
        title: z.string().optional(),
        fileData: z.string(), // base64
        fileName: z.string(),
        mimeType: z.string(),
        isPublic: z.boolean().default(true),
      }))
      .mutation(async ({ input, ctx }) => {
        const buffer = Buffer.from(input.fileData, "base64");
        const key = `photos/${Date.now()}-${input.fileName}`;
        const { url } = await storagePut(key, buffer, input.mimeType);
        await db.addPhoto({
          albumId: input.albumId,
          title: input.title,
          url,
          fileKey: key,
          isPublic: input.isPublic,
          uploadedBy: ctx.user.id,
        });
        return { url };
      }),

    deletePhoto: staffProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deletePhoto(input.id)),

    updatePhoto: staffProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        isPublic: z.boolean().optional(),
        albumId: z.number().nullable().optional(),
      }))
      .mutation(({ input }) => db.updatePhoto(input.id, {
        title: input.title,
        isPublic: input.isPublic,
        albumId: input.albumId,
      })),

    updateAlbum: staffProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        isPublic: z.boolean().optional(),
        speltak: z.enum(["dolfijnen", "verkenners", "wilde_vaart", "staf", "all"]).optional(),
        coverPhotoId: z.number().nullable().optional(),
      }))
      .mutation(({ input }) => db.updateAlbum(input.id, {
        title: input.title,
        description: input.description,
        isPublic: input.isPublic,
        speltak: input.speltak,
        coverPhotoId: input.coverPhotoId,
      })),

    deleteAlbum: staffProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deleteAlbum(input.id)),

    listAllPhotos: staffProcedure.query(() => db.getAllPhotos()),
  }),

  // ── Documents ─────────────────────────────────────────────────────────────
  documents: router({
    list: protectedProcedure
      .input(z.object({ speltak: z.string().optional(), category: z.string().optional() }).optional())
      .query(({ input, ctx }) => {
        const speltak = ctx.user.speltak ?? undefined;
        return db.getDocuments(input?.speltak ?? speltak, input?.category);
      }),

    listAll: staffProcedure
      .input(z.object({ speltak: z.string().optional(), category: z.string().optional() }).optional())
      .query(({ input }) => db.getDocuments(input?.speltak, input?.category)),

    upload: staffProcedure
      .input(z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        fileData: z.string(), // base64
        fileName: z.string(),
        mimeType: z.string(),
        fileSize: z.number().optional(),
        category: z.enum(["form", "medical", "activity_plan", "boat_maintenance", "general"]).default("general"),
        speltak: z.enum(["dolfijnen", "verkenners", "wilde_vaart", "staf", "all"]).default("all"),
        isPublic: z.boolean().default(false),
      }))
      .mutation(async ({ input, ctx }) => {
        const buffer = Buffer.from(input.fileData, "base64");
        const key = `documents/${Date.now()}-${input.fileName}`;
        const { url } = await storagePut(key, buffer, input.mimeType);
        await db.addDocument({
          title: input.title,
          description: input.description,
          url,
          fileKey: key,
          mimeType: input.mimeType,
          fileSize: input.fileSize,
          category: input.category,
          speltak: input.speltak,
          isPublic: input.isPublic,
          uploadedBy: ctx.user.id,
        });
        return { url };
      }),

    delete: staffProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deleteDocument(input.id)),
  }),

  // ── Equipment ─────────────────────────────────────────────────────────────
  equipment: router({
    list: staffProcedure.query(() => db.getAllEquipment()),

    create: staffProcedure
      .input(z.object({
        name: z.string().min(1),
        category: z.enum(["boat", "sail", "safety", "camping", "navigation", "other"]).default("other"),
        description: z.string().optional(),
        serialNumber: z.string().optional(),
        status: z.enum(["available", "in_use", "maintenance", "retired"]).default("available"),
        location: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(({ input }) => db.createEquipment(input)),

    update: staffProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        status: z.enum(["available", "in_use", "maintenance", "retired"]).optional(),
        location: z.string().optional(),
        notes: z.string().optional(),
        lastMaintenanceDate: z.date().optional(),
        nextMaintenanceDate: z.date().optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return db.updateEquipment(id, data);
      }),

    delete: staffProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deleteEquipment(input.id)),
  }),

  // ── Contact ───────────────────────────────────────────────────────────────
  contact: router({
    submit: publicProcedure
      .input(z.object({
        name: z.string().min(1),
        email: z.string().email(),
        subject: z.string().optional(),
        message: z.string().min(10),
      }))
      .mutation(async ({ input }) => {
        await db.createContactSubmission(input);
        return { success: true };
      }),

    list: staffProcedure.query(() => db.getAllContactSubmissions()),

    markRead: staffProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.markContactRead(input.id)),
  }),

  // ── Join Requests ─────────────────────────────────────────────────────────
  join: router({
    submit: publicProcedure
      .input(z.object({
        childName: z.string().min(1),
        childBirthDate: z.string().min(1),
        parentName: z.string().min(1),
        parentEmail: z.string().email(),
        parentPhone: z.string().optional(),
        address: z.string().optional(),
        speltak: z.enum(["dolfijnen", "verkenners", "wilde_vaart"]).optional(),
        message: z.string().optional(),
        gdprConsent: z.boolean().refine((v) => v === true, { message: "GDPR toestemming is verplicht" }),
      }))
      .mutation(async ({ input }) => {
        await db.createJoinRequest(input);
        return { success: true };
      }),

    list: staffProcedure.query(() => db.getAllJoinRequests()),

    updateStatus: staffProcedure
      .input(z.object({ id: z.number(), status: z.enum(["approved", "rejected"]) }))
      .mutation(({ input }) => db.updateJoinRequestStatus(input.id, input.status)),
  }),

  // ── Members (admin/staff) ─────────────────────────────────────────────────
  members: router({
    list: staffProcedure.query(() => db.getAllUsers()),

    update: staffProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        email: z.string().optional(),
        role: z.enum(["user", "staff", "admin"]).optional(),
        speltak: z.enum(["dolfijnen", "verkenners", "wilde_vaart", "staf"]).optional(),
        phone: z.string().optional(),
        isActive: z.boolean().optional(),
        parentName: z.string().optional(),
        parentEmail: z.string().optional(),
        parentPhone: z.string().optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return db.updateUser(id, data as any);
      }),

    updateProfile: protectedProcedure
      .input(z.object({
        phone: z.string().optional(),
        address: z.string().optional(),
        parentName: z.string().optional(),
        parentEmail: z.string().optional(),
        parentPhone: z.string().optional(),
        gdprConsent: z.boolean().optional(),
      }))
      .mutation(({ input, ctx }) => {
        const updateData: any = { ...input };
        if (input.gdprConsent) updateData.gdprConsentDate = new Date();
        return db.updateUser(ctx.user.id, updateData);
      }),
  }),

  // ── CMS ───────────────────────────────────────────────────────────────────
  cms: router({
    get: publicProcedure
      .input(z.object({ key: z.string() }))
      .query(({ input }) => db.getCmsContent(input.key)),

    getAll: adminProcedure.query(() => db.getAllCmsContent()),

    upsert: adminProcedure
      .input(z.object({
        key: z.string().min(1),
        title: z.string().min(1),
        content: z.string(),
        metadata: z.record(z.string(), z.unknown()).optional(),
      }))
      .mutation(({ input, ctx }) =>
        db.upsertCmsContent(input.key, input.title, input.content, ctx.user.id, input.metadata)
      ),
  }),
});

export type AppRouter = typeof appRouter;
