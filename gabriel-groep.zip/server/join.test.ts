import { describe, it, expect } from "vitest";
import { appRouter } from "./routers";

describe("join.submit", () => {
  it("should accept valid join request data", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: { protocol: "https", headers: {} } as any,
      res: {} as any,
    });

    const result = await caller.join.submit({
      childName: "Jan Jansen",
      childBirthDate: "2015-05-20",
      parentName: "Maria Jansen",
      parentEmail: "maria@example.com",
      parentPhone: "+31612345678",
      address: "Straat 1, 1234 AB Mook",
      speltak: "dolfijnen",
      message: "Ons kind wil graag zeilen",
      gdprConsent: true,
    });

    expect(result).toEqual({ success: true });
  });

  it("should reject invalid email", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: { protocol: "https", headers: {} } as any,
      res: {} as any,
    });

    try {
      await caller.join.submit({
        childName: "Jan Jansen",
        childBirthDate: "2015-05-20",
        parentName: "Maria Jansen",
        parentEmail: "invalid-email",
        speltak: "dolfijnen",
        gdprConsent: true,
      });
      expect.fail("Should have thrown error");
    } catch (err: any) {
      expect(err.message).toContain("email");
    }
  });

  it("should reject missing GDPR consent", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: { protocol: "https", headers: {} } as any,
      res: {} as any,
    });

    try {
      await caller.join.submit({
        childName: "Jan Jansen",
        childBirthDate: "2015-05-20",
        parentName: "Maria Jansen",
        parentEmail: "maria@example.com",
        speltak: "dolfijnen",
        gdprConsent: false,
      });
      expect.fail("Should have thrown error");
    } catch (err: any) {
      expect(err.message).toContain("GDPR");
    }
  });
});
