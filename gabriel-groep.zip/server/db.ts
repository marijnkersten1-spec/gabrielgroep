import { and, desc, eq, gte, like, lte, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  attendance,
  cmsContent,
  contactSubmissions,
  documents,
  equipment,
  eventRegistrations,
  events,
  joinRequests,
  news,
  photoAlbums,
  photos,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};

  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    const value = user[field];
    if (value === undefined) continue;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  }

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }

  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).orderBy(desc(users.createdAt));
}

export async function updateUser(id: number, data: Partial<InsertUser>) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set(data).where(eq(users.id, id));
}

// ─── Events ───────────────────────────────────────────────────────────────────

export async function getPublicEvents(from?: Date, to?: Date) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(events.isPublic, true)];
  if (from) conditions.push(gte(events.startDate, from));
  if (to) conditions.push(lte(events.startDate, to));
  return db.select().from(events).where(and(...conditions)).orderBy(events.startDate);
}

export async function getAllEvents(speltak?: string, type?: string) {
  const db = await getDb();
  if (!db) return [];
  const conditions: any[] = [];
  if (speltak && speltak !== "all") {
    conditions.push(or(eq(events.speltak, speltak as any), eq(events.speltak, "all")));
  }
  if (type) {
    conditions.push(eq(events.type, type as any));
  }
  if (conditions.length > 0) {
    return db.select().from(events).where(and(...conditions)).orderBy(events.startDate);
  }
  return db.select().from(events).orderBy(events.startDate);
}

export async function createEvent(data: typeof events.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  const [result] = await db.insert(events).values(data);
  return result;
}

export async function updateEvent(id: number, data: Partial<typeof events.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(events).set(data).where(eq(events.id, id));
}

export async function deleteEvent(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(events).where(eq(events.id, id));
}

export async function getEventById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(events).where(eq(events.id, id)).limit(1);
  return result[0];
}

// ─── Event Registrations ─────────────────────────────────────────────────────

export async function registerForEvent(eventId: number, userId: number, notes?: string) {
  const db = await getDb();
  if (!db) return null;
  const existing = await db
    .select()
    .from(eventRegistrations)
    .where(and(eq(eventRegistrations.eventId, eventId), eq(eventRegistrations.userId, userId)))
    .limit(1);
  if (existing[0]) return existing[0];
  await db.insert(eventRegistrations).values({ eventId, userId, notes });
  return { eventId, userId };
}

export async function getUserRegistrations(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(eventRegistrations).where(eq(eventRegistrations.userId, userId));
}

export async function getEventRegistrations(eventId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(eventRegistrations).where(eq(eventRegistrations.eventId, eventId));
}

export async function cancelRegistration(eventId: number, userId: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(eventRegistrations)
    .set({ status: "cancelled" })
    .where(and(eq(eventRegistrations.eventId, eventId), eq(eventRegistrations.userId, userId)));
}

// ─── Attendance ───────────────────────────────────────────────────────────────

export async function markAttendance(eventId: number, userId: number, present: boolean, markedBy: number, notes?: string) {
  const db = await getDb();
  if (!db) return;
  const existing = await db
    .select()
    .from(attendance)
    .where(and(eq(attendance.eventId, eventId), eq(attendance.userId, userId)))
    .limit(1);
  if (existing[0]) {
    await db.update(attendance).set({ present, notes, markedBy }).where(eq(attendance.id, existing[0].id));
  } else {
    await db.insert(attendance).values({ eventId, userId, present, notes, markedBy });
  }
}

export async function getEventAttendance(eventId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(attendance).where(eq(attendance.eventId, eventId));
}

// ─── News ─────────────────────────────────────────────────────────────────────

export async function getPublishedNews(isPublic?: boolean) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(news.isPublished, true)];
  if (isPublic !== undefined) conditions.push(eq(news.isPublic, isPublic));
  return db.select().from(news).where(and(...conditions)).orderBy(desc(news.publishedAt));
}

export async function getAllNews() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(news).orderBy(desc(news.createdAt));
}

export async function getNewsBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(news).where(eq(news.slug, slug)).limit(1);
  return result[0];
}

export async function createNews(data: typeof news.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(news).values(data);
}

export async function updateNews(id: number, data: Partial<typeof news.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(news).set(data).where(eq(news.id, id));
}

export async function deleteNews(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(news).where(eq(news.id, id));
}

// ─── Photos ───────────────────────────────────────────────────────────────────

export async function getPublicAlbums() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(photoAlbums).where(eq(photoAlbums.isPublic, true)).orderBy(desc(photoAlbums.createdAt));
}

export async function getAllAlbums() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(photoAlbums).orderBy(desc(photoAlbums.createdAt));
}

export async function createAlbum(data: typeof photoAlbums.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  const [result] = await db.insert(photoAlbums).values(data);
  return result;
}

export async function getPhotosByAlbum(albumId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(photos).where(eq(photos.albumId, albumId)).orderBy(desc(photos.createdAt));
}

export async function addPhoto(data: typeof photos.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(photos).values(data);
}

export async function deletePhoto(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(photos).where(eq(photos.id, id));
}

export async function updatePhoto(id: number, data: { title?: string; isPublic?: boolean; albumId?: number | null }) {
  const db = await getDb();
  if (!db) return;
  await db.update(photos).set(data).where(eq(photos.id, id));
}

export async function updateAlbum(id: number, data: { title?: string; description?: string; isPublic?: boolean; speltak?: "dolfijnen" | "verkenners" | "wilde_vaart" | "staf" | "all"; coverPhotoId?: number | null }) {
  const db = await getDb();
  if (!db) return;
  await db.update(photoAlbums).set(data).where(eq(photoAlbums.id, id));
}

export async function deleteAlbum(id: number) {
  const db = await getDb();
  if (!db) return;
  // Delete all photos in album first, then the album
  await db.delete(photos).where(eq(photos.albumId, id));
  await db.delete(photoAlbums).where(eq(photoAlbums.id, id));
}

export async function getAllPhotos() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(photos).orderBy(desc(photos.createdAt));
}

// ─── Documents ────────────────────────────────────────────────────────────────

export async function getDocuments(speltak?: string, category?: string) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (speltak && speltak !== "all") {
    conditions.push(or(eq(documents.speltak, speltak as any), eq(documents.speltak, "all")));
  }
  if (category) conditions.push(eq(documents.category, category as any));
  if (conditions.length > 0) {
    return db.select().from(documents).where(and(...conditions)).orderBy(desc(documents.createdAt));
  }
  return db.select().from(documents).orderBy(desc(documents.createdAt));
}

export async function addDocument(data: typeof documents.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(documents).values(data);
}

export async function deleteDocument(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(documents).where(eq(documents.id, id));
}

// ─── Equipment ────────────────────────────────────────────────────────────────

export async function getAllEquipment() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(equipment).orderBy(equipment.name);
}

export async function createEquipment(data: typeof equipment.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(equipment).values(data);
}

export async function updateEquipment(id: number, data: Partial<typeof equipment.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(equipment).set(data).where(eq(equipment.id, id));
}

export async function deleteEquipment(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(equipment).where(eq(equipment.id, id));
}

// ─── Contact ──────────────────────────────────────────────────────────────────

export async function createContactSubmission(data: typeof contactSubmissions.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(contactSubmissions).values(data);
}

export async function getAllContactSubmissions() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(contactSubmissions).orderBy(desc(contactSubmissions.createdAt));
}

export async function markContactRead(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(contactSubmissions).set({ isRead: true }).where(eq(contactSubmissions.id, id));
}

// ─── Join Requests ────────────────────────────────────────────────────────────

export async function createJoinRequest(data: typeof joinRequests.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(joinRequests).values(data);
}

export async function getAllJoinRequests() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(joinRequests).orderBy(desc(joinRequests.createdAt));
}

export async function updateJoinRequestStatus(id: number, status: "approved" | "rejected") {
  const db = await getDb();
  if (!db) return;
  await db.update(joinRequests).set({ status }).where(eq(joinRequests.id, id));
}

// ─── CMS ─────────────────────────────────────────────────────────────────────

export async function getCmsContent(key: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(cmsContent).where(eq(cmsContent.key, key)).limit(1);
  return result[0];
}

export async function upsertCmsContent(key: string, title: string, content: string, updatedBy: number, metadata?: object) {
  const db = await getDb();
  if (!db) return;
  await db
    .insert(cmsContent)
    .values({ key, title, content, updatedBy, metadata: metadata ?? null })
    .onDuplicateKeyUpdate({ set: { title, content, updatedBy, metadata: metadata ?? null } });
}

export async function getAllCmsContent() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(cmsContent);
}
