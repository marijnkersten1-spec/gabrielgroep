import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ── Helpers ────────────────────────────────────────────────────────────────

function makeCtx(role: "user" | "staff" | "admin" = "user"): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      name: "Test User",
      email: "test@example.com",
      loginMethod: "manus",
      role,
      speltak: null,
      phone: null,
      parentName: null,
      parentEmail: null,
      parentPhone: null,
      dateOfBirth: null,
      isActive: true,
      gdprConsent: false,
      gdprConsentDate: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    } as any,
    req: { protocol: "https", headers: {} } as any,
    res: { clearCookie: () => {} } as any,
  };
}

// ── Auth ───────────────────────────────────────────────────────────────────

describe("auth.me", () => {
  it("returns the current user when authenticated", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.me();
    expect(result?.id).toBe(1);
    expect(result?.email).toBe("test@example.com");
  });

  it("returns null when not authenticated", async () => {
    const ctx: TrpcContext = {
      user: null,
      req: { protocol: "https", headers: {} } as any,
      res: { clearCookie: () => {} } as any,
    };
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.me();
    expect(result).toBeNull();
  });
});

describe("auth.logout", () => {
  it("returns success and clears cookie", async () => {
    const cleared: string[] = [];
    const ctx: TrpcContext = {
      user: null,
      req: { protocol: "https", headers: {} } as any,
      res: {
        clearCookie: (name: string) => { cleared.push(name); },
      } as any,
    };
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result.success).toBe(true);
    expect(cleared.length).toBe(1);
  });
});

// ── Role-based access ──────────────────────────────────────────────────────

describe("role-based access", () => {
  it("rejects non-staff users from accessing members.list", async () => {
    const ctx = makeCtx("user");
    const caller = appRouter.createCaller(ctx);
    await expect(caller.members.list()).rejects.toThrow();
  });

  it("allows staff to access members.list procedure (procedure exists)", async () => {
    // In tRPC v11, procedures are functions
    expect(appRouter._def.procedures["members.list"]).toBeDefined();
  });

  it("allows admin to access admin-level procedures", async () => {
    expect(appRouter._def.procedures["members.update"]).toBeDefined();
  });
});

// ── Events router ──────────────────────────────────────────────────────────

describe("events router", () => {
  it("exposes listPublic as a public procedure", async () => {
    expect(appRouter._def.procedures["events.listPublic"]).toBeDefined();
  });

  it("exposes register as a protected procedure", async () => {
    expect(appRouter._def.procedures["events.register"]).toBeDefined();
  });

  it("exposes cancelRegistration as a protected procedure", async () => {
    expect(appRouter._def.procedures["events.cancelRegistration"]).toBeDefined();
  });
});

// ── News router ────────────────────────────────────────────────────────────

describe("news router", () => {
  it("exposes listPublic as a public procedure", async () => {
    expect(appRouter._def.procedures["news.listPublic"]).toBeDefined();
  });

  it("exposes create as a staff procedure", async () => {
    expect(appRouter._def.procedures["news.create"]).toBeDefined();
  });

  it("exposes delete as a staff procedure", async () => {
    expect(appRouter._def.procedures["news.delete"]).toBeDefined();
  });
});

// ── Equipment router ───────────────────────────────────────────────────────

describe("equipment router", () => {
  it("exposes list, create, and update procedures", async () => {
    expect(appRouter._def.procedures["equipment.list"]).toBeDefined();
    expect(appRouter._def.procedures["equipment.create"]).toBeDefined();
    expect(appRouter._def.procedures["equipment.update"]).toBeDefined();
  });
});

// ── Documents router ───────────────────────────────────────────────────────

describe("documents router", () => {
  it("exposes list and upload procedures", async () => {
    expect(appRouter._def.procedures["documents.list"]).toBeDefined();
    expect(appRouter._def.procedures["documents.upload"]).toBeDefined();
  });
});

// ── Photos router ──────────────────────────────────────────────────────────

describe("photos router", () => {
  it("exposes listPublicAlbums and createAlbum procedures", async () => {
    expect(appRouter._def.procedures["photos.listPublicAlbums"]).toBeDefined();
    expect(appRouter._def.procedures["photos.createAlbum"]).toBeDefined();
  });
});
