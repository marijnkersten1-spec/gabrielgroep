CREATE TABLE `attendance` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`userId` int NOT NULL,
	`present` boolean NOT NULL DEFAULT false,
	`notes` text,
	`markedAt` timestamp NOT NULL DEFAULT (now()),
	`markedBy` int,
	CONSTRAINT `attendance_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cms_content` (
	`id` int AUTO_INCREMENT NOT NULL,
	`key` varchar(128) NOT NULL,
	`title` varchar(255),
	`content` text,
	`metadata` json,
	`updatedBy` int,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cms_content_id` PRIMARY KEY(`id`),
	CONSTRAINT `cms_content_key_unique` UNIQUE(`key`)
);
--> statement-breakpoint
CREATE TABLE `contact_submissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`email` varchar(320) NOT NULL,
	`subject` varchar(255),
	`message` text NOT NULL,
	`isRead` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `contact_submissions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `documents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`url` text NOT NULL,
	`fileKey` text NOT NULL,
	`mimeType` varchar(128),
	`fileSize` int,
	`category` enum('form','medical','activity_plan','boat_maintenance','general') NOT NULL DEFAULT 'general',
	`speltak` enum('dolfijnen','verkenners','wilde_vaart','staf','all') DEFAULT 'all',
	`isPublic` boolean NOT NULL DEFAULT false,
	`uploadedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `documents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `equipment` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`category` enum('boat','sail','safety','camping','navigation','other') NOT NULL DEFAULT 'other',
	`description` text,
	`serialNumber` varchar(128),
	`status` enum('available','in_use','maintenance','retired') NOT NULL DEFAULT 'available',
	`location` varchar(255),
	`lastMaintenanceDate` timestamp,
	`nextMaintenanceDate` timestamp,
	`notes` text,
	`imageUrl` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `equipment_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `event_registrations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`userId` int NOT NULL,
	`status` enum('registered','waitlist','cancelled') NOT NULL DEFAULT 'registered',
	`notes` text,
	`registeredAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `event_registrations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`location` varchar(255),
	`startDate` timestamp NOT NULL,
	`endDate` timestamp,
	`isAllDay` boolean NOT NULL DEFAULT false,
	`speltak` enum('dolfijnen','verkenners','wilde_vaart','staf','all') NOT NULL DEFAULT 'all',
	`type` enum('activity','camp','meeting','training','other') NOT NULL DEFAULT 'activity',
	`isPublic` boolean NOT NULL DEFAULT true,
	`maxParticipants` int,
	`registrationDeadline` timestamp,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `join_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`childName` varchar(255) NOT NULL,
	`childBirthDate` varchar(16) NOT NULL,
	`parentName` varchar(255) NOT NULL,
	`parentEmail` varchar(320) NOT NULL,
	`parentPhone` varchar(32),
	`address` text,
	`speltak` enum('dolfijnen','verkenners','wilde_vaart'),
	`message` text,
	`gdprConsent` boolean NOT NULL DEFAULT false,
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `join_requests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `news` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`slug` varchar(255) NOT NULL,
	`excerpt` text,
	`content` text NOT NULL,
	`coverImageUrl` text,
	`isPublished` boolean NOT NULL DEFAULT false,
	`isPublic` boolean NOT NULL DEFAULT true,
	`publishedAt` timestamp,
	`authorId` int,
	`speltak` enum('dolfijnen','verkenners','wilde_vaart','staf','all') DEFAULT 'all',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `news_id` PRIMARY KEY(`id`),
	CONSTRAINT `news_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `photo_albums` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`coverPhotoId` int,
	`isPublic` boolean NOT NULL DEFAULT true,
	`speltak` enum('dolfijnen','verkenners','wilde_vaart','staf','all') DEFAULT 'all',
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `photo_albums_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `photos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`albumId` int,
	`title` varchar(255),
	`url` text NOT NULL,
	`thumbnailUrl` text,
	`fileKey` text NOT NULL,
	`isPublic` boolean NOT NULL DEFAULT true,
	`uploadedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `photos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','staff','admin') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `users` ADD `speltak` enum('dolfijnen','verkenners','wilde_vaart','staf');--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(32);--> statement-breakpoint
ALTER TABLE `users` ADD `birthDate` varchar(16);--> statement-breakpoint
ALTER TABLE `users` ADD `address` text;--> statement-breakpoint
ALTER TABLE `users` ADD `parentName` text;--> statement-breakpoint
ALTER TABLE `users` ADD `parentEmail` varchar(320);--> statement-breakpoint
ALTER TABLE `users` ADD `parentPhone` varchar(32);--> statement-breakpoint
ALTER TABLE `users` ADD `medicalInfo` text;--> statement-breakpoint
ALTER TABLE `users` ADD `memberSince` timestamp DEFAULT (now());--> statement-breakpoint
ALTER TABLE `users` ADD `isActive` boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `gdprConsent` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `gdprConsentDate` timestamp;--> statement-breakpoint
ALTER TABLE `users` ADD `avatarUrl` text;