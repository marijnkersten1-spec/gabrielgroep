import {
  boolean,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  json,
} from "drizzle-orm/mysql-core";

// ─── Users ────────────────────────────────────────────────────────────────────

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "staff", "admin"]).default("user").notNull(),
  // Scouting-specific fields
  speltak: mysqlEnum("speltak", ["dolfijnen", "verkenners", "wilde_vaart", "staf"]),
  phone: varchar("phone", { length: 32 }),
  birthDate: varchar("birthDate", { length: 16 }),
  address: text("address"),
  parentName: text("parentName"),
  parentEmail: varchar("parentEmail", { length: 320 }),
  parentPhone: varchar("parentPhone", { length: 32 }),
  medicalInfo: text("medicalInfo"),
  memberSince: timestamp("memberSince").defaultNow(),
  isActive: boolean("isActive").default(true).notNull(),
  gdprConsent: boolean("gdprConsent").default(false).notNull(),
  gdprConsentDate: timestamp("gdprConsentDate"),
  avatarUrl: text("avatarUrl"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Events / Agenda ─────────────────────────────────────────────────────────

export const events = mysqlTable("events", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  location: varchar("location", { length: 255 }),
  startDate: timestamp("startDate").notNull(),
  endDate: timestamp("endDate"),
  isAllDay: boolean("isAllDay").default(false).notNull(),
  speltak: mysqlEnum("speltak", ["dolfijnen", "verkenners", "wilde_vaart", "staf", "all"]).default("all").notNull(),
  type: mysqlEnum("type", ["activity", "camp", "meeting", "training", "rental", "other"]).default("activity").notNull(),
  isPublic: boolean("isPublic").default(true).notNull(),
  maxParticipants: int("maxParticipants"),
  registrationDeadline: timestamp("registrationDeadline"),
  createdBy: int("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Event = typeof events.$inferSelect;
export type InsertEvent = typeof events.$inferInsert;

// ─── Event Registrations ─────────────────────────────────────────────────────

export const eventRegistrations = mysqlTable("event_registrations", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  userId: int("userId").notNull(),
  status: mysqlEnum("status", ["registered", "waitlist", "cancelled"]).default("registered").notNull(),
  notes: text("notes"),
  registeredAt: timestamp("registeredAt").defaultNow().notNull(),
});

export type EventRegistration = typeof eventRegistrations.$inferSelect;

// ─── Attendance ───────────────────────────────────────────────────────────────

export const attendance = mysqlTable("attendance", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  userId: int("userId").notNull(),
  present: boolean("present").default(false).notNull(),
  notes: text("notes"),
  markedAt: timestamp("markedAt").defaultNow().notNull(),
  markedBy: int("markedBy"),
});

export type Attendance = typeof attendance.$inferSelect;

// ─── News ─────────────────────────────────────────────────────────────────────

export const news = mysqlTable("news", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  excerpt: text("excerpt"),
  content: text("content").notNull(),
  coverImageUrl: text("coverImageUrl"),
  isPublished: boolean("isPublished").default(false).notNull(),
  isPublic: boolean("isPublic").default(true).notNull(),
  publishedAt: timestamp("publishedAt"),
  authorId: int("authorId"),
  speltak: mysqlEnum("speltak", ["dolfijnen", "verkenners", "wilde_vaart", "staf", "all"]).default("all"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type News = typeof news.$inferSelect;
export type InsertNews = typeof news.$inferInsert;

// ─── Photos ───────────────────────────────────────────────────────────────────

export const photos = mysqlTable("photos", {
  id: int("id").autoincrement().primaryKey(),
  albumId: int("albumId"),
  title: varchar("title", { length: 255 }),
  url: text("url").notNull(),
  thumbnailUrl: text("thumbnailUrl"),
  fileKey: text("fileKey").notNull(),
  isPublic: boolean("isPublic").default(true).notNull(),
  uploadedBy: int("uploadedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Photo = typeof photos.$inferSelect;

// ─── Photo Albums ─────────────────────────────────────────────────────────────

export const photoAlbums = mysqlTable("photo_albums", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  coverPhotoId: int("coverPhotoId"),
  isPublic: boolean("isPublic").default(true).notNull(),
  speltak: mysqlEnum("speltak", ["dolfijnen", "verkenners", "wilde_vaart", "staf", "all"]).default("all"),
  createdBy: int("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PhotoAlbum = typeof photoAlbums.$inferSelect;

// ─── Documents ────────────────────────────────────────────────────────────────

export const documents = mysqlTable("documents", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  url: text("url").notNull(),
  fileKey: text("fileKey").notNull(),
  mimeType: varchar("mimeType", { length: 128 }),
  fileSize: int("fileSize"),
  category: mysqlEnum("category", ["form", "medical", "activity_plan", "boat_maintenance", "general"]).default("general").notNull(),
  speltak: mysqlEnum("speltak", ["dolfijnen", "verkenners", "wilde_vaart", "staf", "all"]).default("all"),
  isPublic: boolean("isPublic").default(false).notNull(),
  uploadedBy: int("uploadedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Document = typeof documents.$inferSelect;

// ─── Equipment / Inventory ────────────────────────────────────────────────────

export const equipment = mysqlTable("equipment", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  category: mysqlEnum("category", ["boat", "sail", "safety", "camping", "navigation", "other"]).default("other").notNull(),
  description: text("description"),
  serialNumber: varchar("serialNumber", { length: 128 }),
  status: mysqlEnum("status", ["available", "in_use", "maintenance", "retired"]).default("available").notNull(),
  location: varchar("location", { length: 255 }),
  lastMaintenanceDate: timestamp("lastMaintenanceDate"),
  nextMaintenanceDate: timestamp("nextMaintenanceDate"),
  notes: text("notes"),
  imageUrl: text("imageUrl"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Equipment = typeof equipment.$inferSelect;
export type InsertEquipment = typeof equipment.$inferInsert;

// ─── Contact Form Submissions ─────────────────────────────────────────────────

export const contactSubmissions = mysqlTable("contact_submissions", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  subject: varchar("subject", { length: 255 }),
  message: text("message").notNull(),
  isRead: boolean("isRead").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ContactSubmission = typeof contactSubmissions.$inferSelect;

// ─── Join Requests ────────────────────────────────────────────────────────────

export const joinRequests = mysqlTable("join_requests", {
  id: int("id").autoincrement().primaryKey(),
  childName: varchar("childName", { length: 255 }).notNull(),
  childBirthDate: varchar("childBirthDate", { length: 16 }).notNull(),
  parentName: varchar("parentName", { length: 255 }).notNull(),
  parentEmail: varchar("parentEmail", { length: 320 }).notNull(),
  parentPhone: varchar("parentPhone", { length: 32 }),
  address: text("address"),
  speltak: mysqlEnum("speltak", ["dolfijnen", "verkenners", "wilde_vaart"]),
  message: text("message"),
  gdprConsent: boolean("gdprConsent").default(false).notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type JoinRequest = typeof joinRequests.$inferSelect;

// ─── CMS Content ──────────────────────────────────────────────────────────────

export const cmsContent = mysqlTable("cms_content", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 128 }).notNull().unique(),
  title: varchar("title", { length: 255 }),
  content: text("content"),
  metadata: json("metadata"),
  updatedBy: int("updatedBy"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CmsContent = typeof cmsContent.$inferSelect;
